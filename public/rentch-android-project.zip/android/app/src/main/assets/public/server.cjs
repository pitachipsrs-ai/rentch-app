var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_crypto = __toESM(require("crypto"), 1);
var import_child_process = require("child_process");
var import_vite = require("vite");
var import_jszip = __toESM(require("jszip"), 1);

// src/utils/phoneSanitizer.ts
function stripPhoneAndContactMentions(text = "") {
  if (!text) return "";
  let s = text;
  s = s.replace(/<br\s*\/?>/gi, "\n");
  s = s.replace(/(?:[☎📞📱]?\s*(?:тел(?:ефон)?|моб(?:ильный)?|номер|phone|tel|mob|cell|contact|whatsapp|viber|telegram|ватсап|вайбер|телеграм|тг)[\w\s\/\.:–—]*[:\-–—]?\s*)?(?:\+?995[\s\-]?)?(?:5\d{2}[- :.]?\d{2}[- :.]?\d{2}[- :.]?\d{2}|5\d{2}[- :.]?\d{3}[- :.]?\d{3}|5\d{8})/gi, "");
  s = s.replace(/(?:для\s+(?:уточнения|связи|просмотра|информации|видео)[^.,;!?\n]*?)?(?:звоните|звонить|пишите|свяжитесь|связывайтесь)[^.,;!?\n]*(?:[☎📞📱]|номерам?|телефону?|whatsapp|viber|telegram|ватсап|вайбер|смс|\+?995|\b5\d{2}\b)[^.,;!?\n]*(?:[.;!?]|\n|$)/gi, "");
  s = s.replace(/[☎📞📱]\s*(?:Моб|Тел|Whatsapp|Telegram|Viber|Телефон)[^\n.<]*/gi, "");
  s = s.replace(/(?:пишите|звоните)\s+(?:мне\s+)?в\s+(?:whatsapp|viber|telegram|ватсап|вайбер|тг)[^\n.<]*/gi, "");
  s = s.replace(/(?:не\s+звоните|звонить\s+не\s+надо)[^\n.<]*/gi, "");
  s = s.replace(/(?:телефон|тел\.?|номер для связи|контактный номер)\s*[:\-–—]\s*[^\n.<]*/gi, "");
  s = s.replace(/(?:\+?995[\s\-]?)?\b5\d{2}[\s\-.:]?\d{2}[\s\-.:]?\d{2}[\s\-.:]?\d{2}\b/g, "");
  s = s.replace(/(?:\+?995[\s\-]?)?\b5\d{2}[\s\-.:]?\d{3}[\s\-.:]?\d{3}\b/g, "");
  s = s.replace(/(?:\+?995[\s\-]?)?\b5\d{8}\b/g, "");
  s = s.replace(/\b(?:тел(?:ефон(?:а|у|ом)?)?|номер(?:а|у|ом)?\s+телефона|whatsapp|viber|ватсап|вайбер)\s*[:\-–—]?/gi, "");
  s = s.replace(/[☎📞📱]/g, "");
  s = s.replace(/[ \t]+/g, " ");
  s = s.replace(/\n\s*[:;,\-–—]\s*\n/g, "\n");
  s = s.replace(/([.,;!?])\s*([.,;!?])+/g, "$1");
  const lines = s.split("\n").map((l) => l.trim()).filter((l) => {
    if (!l) return false;
    if (/^[:;,\.\-–—\s•*]+$/.test(l)) return false;
    if (/^(?:тел|телефон|моб|phone|tel|whatsapp|viber|звоните)[:\s\-–—.]*$/i.test(l)) return false;
    return true;
  });
  return lines.join("\n").trim();
}
var DEFAULT_AGENT_PHONE = "+995 558 542 365";
function sanitizeApartmentPhones(apt, replacementPhone = DEFAULT_AGENT_PHONE) {
  if (!apt) return apt;
  return {
    ...apt,
    title: stripPhoneAndContactMentions(apt.title || ""),
    description: stripPhoneAndContactMentions(apt.description || ""),
    landlord: apt.landlord ? {
      ...apt.landlord,
      phone: replacementPhone || DEFAULT_AGENT_PHONE
    } : apt.landlord
  };
}

// src/utils/districtUtils.ts
var CITIES_CONFIG = {
  tbilisi: {
    id: "tbilisi",
    nameRu: "\u0422\u0431\u0438\u043B\u0438\u0441\u0438",
    nameInRu: "\u0432 \u0422\u0431\u0438\u043B\u0438\u0441\u0438",
    nameGenRu: "\u0422\u0431\u0438\u043B\u0438\u0441\u0438",
    flag: "\u{1F1EC}\u{1F1EA}",
    countryRu: "\u0413\u0440\u0443\u0437\u0438\u044F",
    centerLat: 41.7166,
    centerLng: 44.7833,
    zoom: 13,
    popularDistrictsLabel: "\u0412\u0430\u043A\u0435, \u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E, \u0421\u043E\u043B\u043E\u043B\u0430\u043A\u0438, \u0412\u0435\u0440\u0430, \u0427\u0443\u0433\u0443\u0440\u0435\u0442\u0438"
  },
  yerevan: {
    id: "yerevan",
    nameRu: "\u0415\u0440\u0435\u0432\u0430\u043D",
    nameInRu: "\u0432 \u0415\u0440\u0435\u0432\u0430\u043D\u0435",
    nameGenRu: "\u0415\u0440\u0435\u0432\u0430\u043D\u0430",
    flag: "\u{1F1E6}\u{1F1F2}",
    countryRu: "\u0410\u0440\u043C\u0435\u043D\u0438\u044F",
    centerLat: 40.1792,
    centerLng: 44.5152,
    zoom: 13,
    popularDistrictsLabel: "\u041A\u0435\u043D\u0442\u0440\u043E\u043D, \u0410\u0440\u0430\u0431\u043A\u0438\u0440, \u0414\u0430\u0432\u0442\u0430\u0448\u0435\u043D, \u0410\u0447\u0430\u043F\u043D\u044F\u043A, \u0417\u0435\u0439\u0442\u0443\u043D"
  },
  belgrade: {
    id: "belgrade",
    nameRu: "\u0411\u0435\u043B\u0433\u0440\u0430\u0434",
    nameInRu: "\u0432 \u0411\u0435\u043B\u0433\u0440\u0430\u0434\u0435",
    nameGenRu: "\u0411\u0435\u043B\u0433\u0440\u0430\u0434\u0430",
    flag: "\u{1F1F7}\u{1F1F8}",
    countryRu: "\u0421\u0435\u0440\u0431\u0438\u044F",
    centerLat: 44.8125,
    centerLng: 20.4612,
    zoom: 13,
    popularDistrictsLabel: "\u0412\u0440\u0430\u0447\u0430\u0440, \u0414\u043E\u0440\u0447\u043E\u043B, \u041D\u043E\u0432\u0438 \u0411\u0435\u043E\u0433\u0440\u0430\u0434, \u0417\u0435\u043C\u0443\u043D, Belgrade Waterfront"
  }
};
var RENTCH_CITIES = [
  CITIES_CONFIG.tbilisi,
  CITIES_CONFIG.yerevan,
  CITIES_CONFIG.belgrade
];
var YEREVAN_DISTRICT_LIST = [
  {
    name: "\u041A\u0435\u043D\u0442\u0440\u043E\u043D / \u0426\u0435\u043D\u0442\u0440 (Kentron)",
    shortRu: "\u041A\u0435\u043D\u0442\u0440\u043E\u043D (\u0426\u0435\u043D\u0442\u0440)",
    aliases: ["\u043A\u0435\u043D\u0442\u0440\u043E\u043D", "kentron", "\u0446\u0435\u043D\u0442\u0440 \u0435\u0440\u0435\u0432\u0430\u043D", "\u043A\u0430\u0441\u043A\u0430\u0434", "\u0441\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u043F\u0440\u043E\u0441\u043F\u0435\u043A\u0442", "\u043C\u0430\u043B\u044B\u0439 \u0446\u0435\u043D\u0442\u0440", "\u0442\u0443\u043C\u0430\u043D\u044F\u043D\u0430", "\u0430\u0431\u043E\u0432\u044F\u043D\u0430", "\u043C\u0430\u0448\u0442\u043E\u0446\u0430", "\u0441\u0430\u0440\u044F\u043D\u0430"],
    lat: 40.1811,
    lng: 44.5136,
    isCentral: true,
    city: "yerevan"
  },
  {
    name: "\u0410\u0440\u0430\u0431\u043A\u0438\u0440 (Arabkir)",
    shortRu: "\u0410\u0440\u0430\u0431\u043A\u0438\u0440",
    aliases: ["\u0430\u0440\u0430\u0431\u043A\u0438\u0440", "arabkir", "\u043A\u043E\u043C\u0438\u0442\u0430\u0441", "komitas", "\u0431\u0430\u0433\u0440\u0430\u043C\u044F\u043D\u0430", "\u043A\u0438\u0435\u0432\u0441\u043A\u0430\u044F \u0435\u0440\u0435\u0432\u0430\u043D"],
    lat: 40.2051,
    lng: 44.5042,
    isCentral: true,
    city: "yerevan"
  },
  {
    name: "\u0414\u0430\u0432\u0442\u0430\u0448\u0435\u043D (Davtashen)",
    shortRu: "\u0414\u0430\u0432\u0442\u0430\u0448\u0435\u043D",
    aliases: ["\u0434\u0430\u0432\u0442\u0430\u0448\u0435\u043D", "davtashen"],
    lat: 40.2194,
    lng: 44.4828,
    isCentral: false,
    city: "yerevan"
  },
  {
    name: "\u0410\u0447\u0430\u043F\u043D\u044F\u043A (Ajapnyak)",
    shortRu: "\u0410\u0447\u0430\u043F\u043D\u044F\u043A",
    aliases: ["\u0430\u0447\u0430\u043F\u043D\u044F\u043A", "ajapnyak", "\u0430\u043B\u0430\u0431\u044F\u043D\u0430", "\u0433\u0430\u043B\u0430\u0431\u044F\u043D\u0430"],
    lat: 40.1972,
    lng: 44.4694,
    isCentral: false,
    city: "yerevan"
  },
  {
    name: "\u0417\u0435\u0439\u0442\u0443\u043D / \u041A\u0430\u043D\u0430\u043A\u0435\u0440 (Kanaker-Zeytun)",
    shortRu: "\u0417\u0435\u0439\u0442\u0443\u043D",
    aliases: ["\u0437\u0435\u0439\u0442\u0443\u043D", "\u043A\u0430\u043D\u0430\u043A\u0435\u0440", "zeytun", "kanaker"],
    lat: 40.2078,
    lng: 44.5369,
    isCentral: false,
    city: "yerevan"
  },
  {
    name: "\u041D\u043E\u0440-\u041D\u043E\u0440\u043A (Nor Nork)",
    shortRu: "\u041D\u043E\u0440-\u041D\u043E\u0440\u043A",
    aliases: ["\u043D\u043E\u0440-\u043D\u043E\u0440\u043A", "\u043D\u043E\u0440 \u043D\u043E\u0440\u043A", "nor nork"],
    lat: 40.1967,
    lng: 44.5681,
    isCentral: false,
    city: "yerevan"
  },
  {
    name: "\u042D\u0440\u0435\u0431\u0443\u043D\u0438 (Erebuni)",
    shortRu: "\u042D\u0440\u0435\u0431\u0443\u043D\u0438",
    aliases: ["\u044D\u0440\u0435\u0431\u0443\u043D\u0438", "erebuni"],
    lat: 40.1464,
    lng: 44.5269,
    isCentral: false,
    city: "yerevan"
  },
  {
    name: "\u0428\u0435\u043D\u0433\u0430\u0432\u0438\u0442 (Shengavit)",
    shortRu: "\u0428\u0435\u043D\u0433\u0430\u0432\u0438\u0442",
    aliases: ["\u0448\u0435\u043D\u0433\u0430\u0432\u0438\u0442", "shengavit", "\u0433\u0430\u0440\u0435\u0433\u0438\u043D \u043D\u0436\u0434\u0435"],
    lat: 40.1453,
    lng: 44.4847,
    isCentral: false,
    city: "yerevan"
  },
  {
    name: "\u041C\u0430\u043B\u0430\u0442\u0438\u044F-\u0421\u0435\u0431\u0430\u0441\u0442\u0438\u044F (Malatia-Sebastia)",
    shortRu: "\u041C\u0430\u043B\u0430\u0442\u0438\u044F-\u0421\u0435\u0431\u0430\u0441\u0442\u0438\u044F",
    aliases: ["\u043C\u0430\u043B\u0430\u0442\u0438\u044F", "\u0441\u0435\u0431\u0430\u0441\u0442\u0438\u044F", "malatia", "sebastia"],
    lat: 40.1731,
    lng: 44.4489,
    isCentral: false,
    city: "yerevan"
  },
  {
    name: "\u0410\u0432\u0430\u043D (Avan)",
    shortRu: "\u0410\u0432\u0430\u043D",
    aliases: ["\u0430\u0432\u0430\u043D", "avan"],
    lat: 40.2186,
    lng: 44.5675,
    isCentral: false,
    city: "yerevan"
  }
];
var BELGRADE_DISTRICT_LIST = [
  {
    name: "\u0421\u0442\u0430\u0440\u0438 \u0413\u0440\u0430\u0434 / \u0414\u043E\u0440\u0447\u043E\u043B (Stari Grad / Dor\u0107ol)",
    shortRu: "\u0421\u0442\u0430\u0440\u0438 \u0413\u0440\u0430\u0434 / \u0414\u043E\u0440\u0447\u043E\u043B",
    aliases: [
      "\u0441\u0442\u0430\u0440\u0438 \u0433\u0440\u0430\u0434",
      "\u0434\u043E\u0440\u0447\u043E\u043B",
      "stari grad",
      "op\u0161tina stari grad",
      "opstina stari grad",
      "dorcol",
      "dor\u0107ol",
      "\u043A\u043D\u0435\u0437 \u043C\u0438\u0445\u0430\u0438\u043B\u043E\u0432\u0430",
      "knez mihailova",
      "\u0441\u043A\u0430\u0434\u0430\u0440\u043B\u0438\u044F",
      "skadarlija",
      "trg republike",
      "\u0442\u0440\u0433 \u0440\u0435\u043F\u0443\u0431\u043B\u0438\u043A\u0435",
      "zeleni venac",
      "\u0437\u0435\u043B\u0435\u043D\u0438 \u0432\u0435\u043D\u0430\u0446",
      "kosan\u010Di\u0107ev",
      "terazije",
      "\u0442\u0435\u0440\u0430\u0437\u0438\u0435",
      "studentski trg",
      "\u0441\u0442\u0443\u0434\u0435\u043D\u0442\u0441\u043A\u0438 \u0442\u0440\u0433",
      "gunduli\u0107ev",
      "francuska",
      "cara du\u0161ana"
    ],
    lat: 44.8206,
    lng: 20.4622,
    isCentral: true,
    city: "belgrade"
  },
  {
    name: "\u0412\u0440\u0430\u0447\u0430\u0440 (Vra\u010Dar)",
    shortRu: "\u0412\u0440\u0430\u0447\u0430\u0440",
    aliases: [
      "\u0432\u0440\u0430\u0447\u0430\u0440",
      "vracar",
      "vra\u010Dar",
      "op\u0161tina vra\u010Dar",
      "opstina vracar",
      "\u0445\u0440\u0430\u043C \u0441\u0432\u044F\u0442\u043E\u0433\u043E \u0441\u0430\u0432\u0432\u044B",
      "hram svetog save",
      "\u0441\u043B\u0430\u0432\u0438\u044F",
      "slavija",
      "\u043A\u0430\u043B\u0435\u043D\u0438\u0447",
      "kaleni\u0107",
      "kalenic",
      "crveni krst",
      "\u0446\u0440\u0432\u0435\u043D\u0438 \u043A\u0440\u0441\u0442",
      "\u010Dubura",
      "cubura",
      "\u0447\u0443\u0431\u0443\u0440\u0430",
      "neimar",
      "\u043D\u0435\u0438\u043C\u0430\u0440",
      "cvetni trg",
      "\u0446\u0432\u0435\u0442\u043D\u0438 \u0442\u0440\u0433",
      "ju\u017Eni bulevar",
      "juzni bulevar",
      "makenzijeva",
      "krunska",
      "\u043A\u0440\u0443\u043D\u0441\u043A\u0430"
    ],
    lat: 44.7989,
    lng: 20.4764,
    isCentral: true,
    city: "belgrade"
  },
  {
    name: "\u041D\u043E\u0432\u0438 \u0411\u0435\u043E\u0433\u0440\u0430\u0434 (Novi Beograd)",
    shortRu: "\u041D\u043E\u0432\u0438 \u0411\u0435\u043E\u0433\u0440\u0430\u0434",
    aliases: [
      "\u043D\u043E\u0432\u0438 \u0431\u0435\u043E\u0433\u0440\u0430\u0434",
      "\u043D\u043E\u0432\u044B\u0439 \u0431\u0435\u043B\u0433\u0440\u0430\u0434",
      "novi beograd",
      "op\u0161tina novi beograd",
      "opstina novi beograd",
      "\u0431\u043B\u043E\u043A",
      "blok",
      "airport city",
      "west 65",
      "a blok",
      "belville",
      "\u0431\u0435\u043B\u0432\u0438\u043B",
      "be\u017Eanijska kosa",
      "bezanijska kosa",
      "\u0431\u0435\u0436\u0430\u043D\u0438\u0439\u0441\u043A\u0430 \u043A\u043E\u0441\u0430",
      "be\u017Eanija",
      "bezanija",
      "fontana",
      "\u0444\u043E\u043D\u0442\u0430\u043D\u0430",
      "arena",
      "\u0430\u0440\u0435\u043D\u0430",
      "uS\u0107e",
      "usce",
      "\u0443\u0448\u0447\u0435",
      "savada",
      "\u0441\u0430\u0432\u0430\u0434\u0430",
      "ledine",
      "\u043B\u0435\u0434\u0438\u043D\u0435",
      "paviljoni",
      "\u043F\u0430\u0432\u0438\u043B\u044C\u043E\u043D\u0438",
      "to\u0161in bunar",
      "tosin bunar",
      "jurija gagarina"
    ],
    lat: 44.8128,
    lng: 20.4119,
    isCentral: true,
    city: "belgrade"
  },
  {
    name: "\u0421\u0430\u0432\u0441\u043A\u0438 \u0412\u0435\u043D\u0430\u0446 / Belgrade Waterfront",
    shortRu: "Belgrade Waterfront",
    aliases: [
      "\u0441\u0430\u0432\u0441\u043A\u0438 \u0432\u0435\u043D\u0430\u0446",
      "savski venac",
      "op\u0161tina savski venac",
      "opstina savski venac",
      "belgrade waterfront",
      "\u0431\u0435\u043E\u0433\u0440\u0430\u0434 \u043D\u0430 \u0432\u043E\u0434\u0438",
      "beograd na vodi",
      "\u0434\u0435\u0434\u0438\u043D\u044C\u0435",
      "dedinje",
      "\u0441\u0435\u043D\u044F\u043A",
      "senjak",
      "sarajevska",
      "\u0441\u0430\u0440\u0430\u0435\u0432\u0441\u043A\u0430",
      "nemanjina",
      "\u043D\u0435\u043C\u0430\u043D\u044C\u0438\u043D\u0430",
      "kneza milo\u0161a",
      "kneza milosa",
      "klini\u010Dki centar",
      "klinicki centar",
      "prokop",
      "\u043F\u0440\u043E\u043A\u043E\u043F",
      "mostar"
    ],
    lat: 44.8056,
    lng: 20.4519,
    isCentral: true,
    city: "belgrade"
  },
  {
    name: "\u0417\u0435\u043C\u0443\u043D (Zemun)",
    shortRu: "\u0417\u0435\u043C\u0443\u043D",
    aliases: [
      "\u0437\u0435\u043C\u0443\u043D",
      "zemun",
      "op\u0161tina zemun",
      "opstina zemun",
      "\u0433\u0430\u0440\u0434\u043E\u0448",
      "gardo\u0161",
      "gardos",
      "altina",
      "\u0430\u043B\u0442\u0438\u043D\u0430",
      "batajnica",
      "\u0431\u0430\u0442\u0430\u043D\u0438\u0446\u0430",
      "zemun polje",
      "galenika",
      "\u0433\u0430\u043B\u0435\u043D\u0438\u043A\u0430",
      "cara du\u0161ana zemun",
      "prgrenica",
      "retrostil",
      "kej",
      "\u0437\u0435\u043C\u0443\u043D\u0441\u043A\u0438 \u043A\u0435\u0439",
      "novi grad zemun"
    ],
    lat: 44.8431,
    lng: 20.4014,
    isCentral: false,
    city: "belgrade"
  },
  {
    name: "\u041F\u0430\u043B\u0438\u043B\u0443\u043B\u0430 (Palilula)",
    shortRu: "\u041F\u0430\u043B\u0438\u043B\u0443\u043B\u0430",
    aliases: [
      "\u043F\u0430\u043B\u0438\u043B\u0443\u043B\u0430",
      "palilula",
      "op\u0161tina palilula",
      "opstina palilula",
      "\u0442\u0430\u0448\u043C\u0430\u0439\u0434\u0430\u043D",
      "ta\u0161majdan",
      "tasmajdan",
      "\u043A\u0430\u0440\u0430\u0431\u0443\u0440\u043C\u0430",
      "karaburma",
      "bor\u010Da",
      "borca",
      "\u0431\u043E\u0440\u0447\u0430",
      "krnja\u010Da",
      "krnjaca",
      "\u043A\u0440\u043D\u044F\u0447\u0430",
      "bogoslovija",
      "\u0431\u043E\u0433\u043E\u0441\u043B\u043E\u0432\u0438\u044F",
      "vi\u0161nji\u010Dka banja",
      "visnjicka banja",
      "\u0432\u0438\u0448\u043D\u0438\u0447\u043A\u0430 \u0431\u0430\u043D\u044F",
      "kote\u017E",
      "kotez",
      "\u043A\u043E\u0442\u0435\u0436",
      "ov\u010Da",
      "ovca",
      "\u043E\u0432\u0447\u0430",
      "sebe\u0161",
      "sebes",
      "\u0441\u0435\u0431\u0435\u0448",
      "cviji\u0107eva",
      "cvijiceva"
    ],
    lat: 44.8142,
    lng: 20.4875,
    isCentral: false,
    city: "belgrade"
  },
  {
    name: "\u0417\u0432\u0435\u0437\u0434\u0430\u0440\u0430 (Zvezdara)",
    shortRu: "\u0417\u0432\u0435\u0437\u0434\u0430\u0440\u0430",
    aliases: [
      "\u0437\u0432\u0435\u0437\u0434\u0430\u0440\u0430",
      "zvezdara",
      "op\u0161tina zvezdara",
      "opstina zvezdara",
      "\u0432\u0443\u043A\u043E\u0432 \u0441\u043F\u043E\u043C\u0435\u043D\u0438\u043A",
      "vukov spomenik",
      "\u0431\u0443\u043B\u044C\u0432\u0430\u0440 \u043A\u043E\u0440\u043E\u043B\u044F \u0430\u043B\u0435\u043A\u0441\u0430\u043D\u0434\u0440\u0430",
      "bulevar kralja aleksandra",
      "mirijevo",
      "\u043C\u0438\u0440\u0438\u0435\u0432\u043E",
      "lion",
      "\u043B\u0438\u043E\u043D",
      "\u0111eram",
      "djeram",
      "\u0434\u0436\u0435\u0440\u0430\u043C",
      "konjarnik",
      "\u043A\u043E\u043D\u044F\u0440\u043D\u0438\u043A",
      "cvetkova pijaca",
      "\u0446\u0432\u0435\u0442\u043A\u043E\u0432\u0430 \u043F\u0438\u044F\u0446\u0430",
      "u\u010Diteljsko naselje",
      "uciteljsko naselje",
      "olimp",
      "\u043E\u043B\u0438\u043C\u043F",
      "mali mokri lug",
      "veliki mokri lug",
      "dimitrija tucovi\u0107a",
      "dimitrija tucovica"
    ],
    lat: 44.7964,
    lng: 20.5061,
    isCentral: false,
    city: "belgrade"
  },
  {
    name: "\u0412\u043E\u0436\u0434\u043E\u0432\u0430\u0446 (Vo\u017Edovac)",
    shortRu: "\u0412\u043E\u0436\u0434\u043E\u0432\u0430\u0446",
    aliases: [
      "\u0432\u043E\u0436\u0434\u043E\u0432\u0430\u0446",
      "vozdovac",
      "vo\u017Edovac",
      "op\u0161tina vo\u017Edovac",
      "opstina vozdovac",
      "\u0430\u0443\u0442\u043E\u043A\u043E\u043C\u0430\u043D\u0434\u0430",
      "autokomanda",
      "\u0431\u0430\u043D\u044C\u0438\u0446\u0430",
      "banjica",
      "medakovi\u0107",
      "medakovic",
      "\u043C\u0435\u0434\u0430\u043A\u043E\u0432\u0438\u0447",
      "bra\u0107e jerkovi\u0107",
      "brace jerkovic",
      "\u0431\u0440\u0430\u0447\u0435 \u0435\u0440\u043A\u043E\u0432\u0438\u0447",
      "stepa stepanovi\u0107",
      "stepa stepanovic",
      "du\u0161anovac",
      "dusanovac",
      "\u0434\u0443\u0448\u0430\u043D\u043E\u0432\u0430\u0446",
      "\u0161umice",
      "sumice",
      "\u0448\u0443\u043C\u0438\u0446\u0435",
      "ustani\u010Dka",
      "ustanicka",
      "vojvode stepe",
      "\u0432\u043E\u0439\u0432\u043E\u0434\u0435 \u0441\u0442\u0435\u043F\u0435",
      "kumodra\u017E",
      "kumodraz",
      "jajinci"
    ],
    lat: 44.7753,
    lng: 20.4792,
    isCentral: false,
    city: "belgrade"
  },
  {
    name: "\u0427\u0443\u043A\u0430\u0440\u0438\u0446\u0430 / \u0411\u0430\u043D\u043E\u0432\u043E \u0411\u0440\u0434\u043E (\u010Cukarica)",
    shortRu: "\u0411\u0430\u043D\u043E\u0432\u043E \u0411\u0440\u0434\u043E",
    aliases: [
      "\u0447\u0443\u043A\u0430\u0440\u0438\u0446\u0430",
      "\u0431\u0430\u043D\u043E\u0432\u043E \u0431\u0440\u0434\u043E",
      "cukarica",
      "\u010Dukarica",
      "op\u0161tina \u010Dukarica",
      "opstina cukarica",
      "banovo brdo",
      "\u0430\u0434\u0430 \u0446\u0438\u0433\u0430\u043D\u043B\u0438\u044F",
      "ada ciganlija",
      "\u017Earkovo",
      "zarkovo",
      "\u0436\u0430\u0440\u043A\u043E\u0432\u043E",
      "cerak",
      "\u0446\u0435\u0440\u0430\u043A",
      "vidikovac",
      "\u0432\u0438\u0434\u0438\u043A\u043E\u0432\u0430\u0446",
      "bele vode",
      "\u0431\u0435\u043B\u0435 \u0432\u043E\u0434\u0435",
      "ko\u0161utnjak",
      "kosutnjak",
      "po\u017Ee\u0161ka",
      "pozeska",
      "\u043F\u043E\u0436\u0435\u0448\u043A\u0430",
      "rakovica",
      "op\u0161tina rakovica",
      "\u0440\u0430\u043A\u043E\u0432\u0438\u0446\u0430",
      "miljakovac",
      "\u043C\u0438\u043B\u044F\u043A\u043E\u0432\u0430\u0446",
      "kanarevo brdo",
      "petlovo brdo",
      "labudovo brdo",
      "kne\u017Eevac",
      "knezevac"
    ],
    lat: 44.7778,
    lng: 20.4158,
    isCentral: false,
    city: "belgrade"
  }
];
var YEREVAN_DISTRICTS = YEREVAN_DISTRICT_LIST.map((d) => d.name);
var BELGRADE_DISTRICTS = BELGRADE_DISTRICT_LIST.map((d) => d.name);
function getApartmentCity(apartment) {
  if (apartment.city === "yerevan" || apartment.city === "belgrade" || apartment.city === "tbilisi") {
    return apartment.city;
  }
  const combined = `${apartment.district || ""} ${apartment.address || ""} ${apartment.title || ""}`.toLowerCase();
  if (YEREVAN_DISTRICT_LIST.some(
    (d) => d.name.toLowerCase() === (apartment.district || "").toLowerCase() || d.aliases.some((a) => combined.includes(a))
  ) || combined.includes("\u0435\u0440\u0435\u0432\u0430\u043D") || combined.includes("yerevan")) {
    return "yerevan";
  }
  if (BELGRADE_DISTRICT_LIST.some(
    (d) => d.name.toLowerCase() === (apartment.district || "").toLowerCase() || d.aliases.some((a) => combined.includes(a))
  ) || combined.includes("\u0431\u0435\u043B\u0433\u0440\u0430\u0434") || combined.includes("belgrade") || combined.includes("\u0431\u0435\u043E\u0433\u0440\u0430\u0434")) {
    return "belgrade";
  }
  return "tbilisi";
}
var TBILISI_DISTRICT_LIST = [
  {
    name: "\u0414\u0438\u0434\u0438 \u0414\u0438\u0433\u043E\u043C\u0438 (Didi Dighomi)",
    shortRu: "\u0414\u0438\u0434\u0438 \u0414\u0438\u0433\u043E\u043C\u0438",
    aliases: [
      "\u0434\u0438\u0434\u0438 \u0434\u0438\u0433\u043E\u043C\u0438",
      "\u0434\u0438\u0434 \u0434\u0438\u0433\u043E\u043C",
      "didi dighomi",
      "\u10D3\u10D8\u10D3\u10D8 \u10D3\u10D8\u10E6\u10DD\u10DB\u10D8",
      "\u10D3\u10D8\u10D3 \u10D3\u10D8\u10E6\u10DD\u10DB\u10E8\u10D8",
      "\u043C\u0438\u0440\u0438\u0430\u043D\u0430",
      "\u0446\u0430\u0440\u044F \u043C\u0438\u0440\u0438\u0430\u043D\u0430",
      "\u043C\u0438\u0440\u0438\u0430\u043D \u043C\u0435\u043F\u0435",
      "mirian mepe",
      "\u10DB\u10D8\u10E0\u10D8\u10D0\u10DC \u10DB\u10D4\u10E4\u10D8\u10E1",
      "\u0434\u0438\u0433\u043E\u043C\u0438",
      "digomi",
      "\u0434\u0438\u0433\u043E\u043C",
      "\u10D3\u10D8\u10E6\u10DD\u10DB\u10D8",
      "\u10D3\u10D8\u10E6\u10DB\u10D8\u10E1",
      "\u043F\u0435\u0442\u0440\u0438\u0446\u0438",
      "petritsi",
      "\u10DE\u10D4\u10E2\u10E0\u10D8\u10EC\u10D8\u10E1",
      "\u0444\u0430\u0440\u043D\u0430\u0432\u0430\u0437",
      "farnavaz",
      "\u10E4\u10D0\u10E0\u10DC\u10D0\u10D5\u10D0\u10D6",
      "\u0434\u0435\u043C\u0435\u0442\u0440\u0435 \u0442\u0430\u0432\u0434\u0430\u0434\u0435\u0431\u0443\u043B\u0438",
      "\u0442\u0430\u0432\u0434\u0430\u0434\u0435\u0431\u0443\u043B\u0438",
      "\u10D7\u10D0\u10D5\u10D3\u10D0\u10D3\u10D4\u10D1\u10E3\u10DA\u10D8\u10E1",
      "\u0431\u043E\u0431 \u0443\u043E\u043B\u0448",
      "\u0443\u043E\u043B\u0448",
      "\u10E3\u10DD\u10DA\u10E8\u10D8\u10E1",
      "\u0442\u0435\u0438\u043C\u0443\u0440\u0430\u0437",
      "\u10D7\u10D4\u10D8\u10DB\u10E3\u10E0\u10D0\u10D6",
      "\u0430\u0431\u0430\u0448\u0438\u0434\u0437\u0435-\u043E\u0440\u0431\u0435\u043B\u0438\u0430\u043D\u0438",
      "\u043E\u0440\u0431\u0435\u043B\u0438\u0430\u043D\u0438 \u043D.",
      "\u0430\u0433\u043C\u0430\u0448\u0435\u043D\u0435\u0431\u0435\u043B\u0438 \u0430\u043B\u043B\u0435\u044F",
      "\u10D0\u10E6\u10DB\u10D0\u10E8\u10D4\u10DC\u10D4\u10D1\u10DA\u10D8\u10E1 \u10EE\u10D4\u10D8\u10D5"
    ],
    lat: 41.7856,
    lng: 44.7612,
    isCentral: false
  },
  {
    name: "\u0411\u0430\u0433\u0435\u0431\u0438 (Bagebi)",
    shortRu: "\u0411\u0430\u0433\u0435\u0431\u0438",
    aliases: [
      "\u0431\u0430\u0433\u0435\u0431\u0438",
      "\u0431\u0430\u0433\u0435\u0431\u0448\u0438",
      "\u0431\u0430\u0433\u0435\u0431",
      "bagebi",
      "\u10D1\u10D0\u10D2\u10D4\u10D1\u10D8",
      "\u10D1\u10D0\u10D2\u10D4\u10D1\u10E8\u10D8",
      "\u0443\u0447\u0445\u043E\u0437",
      "\u0441\u0430\u043A\u0440\u0438\u0432\u0435\u043B\u043E",
      "\u0431\u0430\u0433\u0435\u0431\u0438\u0441",
      "\u0446\u0445\u043D\u0435\u0442\u0438\u0441",
      "\u0446\u0445\u043D\u0435\u0442\u0441\u043A\u043E\u0435",
      "\u10EC\u10E7\u10DC\u10D4\u10D7\u10D8\u10E1 \u10D2\u10D6\u10D0\u10E2\u10D9\u10D4\u10EA\u10D8\u10DA\u10D8"
    ],
    lat: 41.7089,
    lng: 44.7321,
    isCentral: false
  },
  {
    name: "\u041E\u0440\u0442\u0430\u0447\u0430\u043B\u0430 (Ortachala)",
    shortRu: "\u041E\u0440\u0442\u0430\u0447\u0430\u043B\u0430",
    aliases: [
      "\u043E\u0440\u0442\u0430\u0447\u0430\u043B\u0430",
      "\u043E\u0440\u0442\u0430\u0447\u0430\u043B",
      "ortachala",
      "\u10DD\u10E0\u10D7\u10D0\u10ED\u10D0\u10DA\u10D0",
      "\u10DD\u10E0\u10D7\u10D0\u10ED\u10D0\u10DA\u10D0\u10E8\u10D8",
      "\u043E\u0440\u0442\u0430\u0447\u0430\u043B\u044C",
      "\u0433\u0443\u043B\u0438\u044F",
      "gulia",
      "\u0433\u0443\u043B\u0443\u0430",
      "gulua",
      "\u10D2\u10E3\u10DA\u10E3\u10D0\u10E1",
      "\u0433\u043E\u0440\u0433\u0430\u0441\u0430\u043B\u0438",
      "\u0433\u043E\u0440\u0433\u0430\u0441\u0430\u043B",
      "gorgasali",
      "\u10D2\u10DD\u10E0\u10D2\u10D0\u10E1\u10DA\u10D8\u10E1",
      "\u0431\u043E\u0447\u043E\u0440\u043C\u0430",
      "\u0431\u043E\u0447\u043E\u0440\u043C\u0438\u0441",
      "\u0431\u043E\u0447\u043E\u0440\u043C\u0438",
      "\u0433\u0440\u0433\u0430\u0441\u0430\u043B\u0438",
      "\u043E\u0440\u0442\u0430\u0447\u0430\u043B\u044B",
      "\u043E\u0440\u0442\u0430\u0447\u0430\u043B\u0435",
      "\u043A\u0440\u0446\u0430\u043D\u0438\u0441\u0438\u0441"
    ],
    lat: 41.6789,
    lng: 44.8214,
    isCentral: false
  },
  {
    name: "\u041A\u0440\u0446\u0430\u043D\u0438\u0441\u0438 (Krtsanisi)",
    shortRu: "\u041A\u0440\u0446\u0430\u043D\u0438\u0441\u0438",
    aliases: [
      "\u043A\u0440\u0446\u0430\u043D\u0438\u0441\u0438",
      "\u043A\u0440\u0446\u0430\u043D\u0438\u0441\u0448\u0438",
      "\u043A\u0440\u0446\u0430\u043D\u0438\u0441",
      "krtsanisi",
      "\u10D9\u10E0\u10EC\u10D0\u10DC\u10D8\u10E1\u10D8",
      "\u10D9\u10E0\u10EC\u10D0\u10DC\u10D8\u10E1\u10E8\u10D8",
      "\u0440\u0435\u0437\u0438\u0434\u0435\u043D\u0446\u0438\u044F \u043A\u0440\u0446\u0430\u043D\u0438\u0441\u0438",
      "\u0432\u043E\u043B\u0441\u043A\u0438",
      "\u0432\u043E\u043B\u044C\u0441\u043A\u043E\u0433\u043E",
      "\u10D5\u10DD\u10DA\u10E1\u10D9\u10D8\u10E1"
    ],
    lat: 41.6712,
    lng: 44.819,
    isCentral: false
  },
  {
    name: "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E (Saburtalo)",
    shortRu: "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E",
    aliases: [
      "\u0441\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E",
      "\u0441\u0430\u0431\u0443\u0440\u0442\u0430\u043B",
      "saburtalo",
      "\u10E1\u10D0\u10D1\u10E3\u10E0\u10D7\u10D0\u10DA\u10DD",
      "\u10E1\u10D0\u10D1\u10E3\u10E0\u10D7\u10D0\u10DA\u10DD\u10D6\u10D4",
      "\u043A\u0430\u0437\u0431\u0435\u0433\u0438",
      "kazbegi",
      "\u10E7\u10D0\u10D6\u10D1\u10D4\u10D2\u10D8\u10E1",
      "\u043F\u0435\u043A\u0438\u043D",
      "\u043F\u0435\u043A\u0438\u043D\u0438",
      "\u10DE\u10D4\u10D9\u10D8\u10DC\u10D8\u10E1",
      "\u0432\u0430\u0436\u0438",
      "\u0432\u0430\u0436\u0430",
      "\u043F\u0448\u0430\u0432\u0435\u043B\u0430",
      "vazha",
      "\u10D5\u10D0\u10DF\u10D0-\u10E4\u10E8\u10D0\u10D5\u10D4\u10DA\u10D0\u10E1",
      "\u0434\u0435\u043B\u0438\u0441\u0438",
      "delisi",
      "\u10D3\u10D4\u10DA\u10D8\u10E1\u10D8",
      "\u0431\u0430\u0445\u0442\u0440\u0438\u043E\u043D\u0438",
      "\u0431\u0430\u0445\u0442\u0440\u0438\u043E\u043D\u0438\u0441",
      "bakhtrioni",
      "\u10D1\u10D0\u10EE\u10E2\u10E0\u10D8\u10DD\u10DC\u10D8\u10E1",
      "\u043D\u0443\u0446\u0443\u0431\u0438\u0434\u0437\u0435",
      "nutsubidze",
      "\u10DC\u10E3\u10EA\u10E3\u10D1\u10D8\u10EB\u10D8\u10E1",
      "\u043F\u043E\u043B\u0438\u0442\u043A\u043E\u0432\u0441\u043A\u0430\u044F",
      "\u043F\u043E\u043B\u0438\u0442\u043A\u043E\u0432\u0441\u043A\u043E\u0439",
      "politkovskaya",
      "\u10DE\u10DD\u10DA\u10D8\u10E2\u10D9\u10DD\u10D5\u10E1\u10D9\u10D0\u10D8\u10D0\u10E1",
      "\u0433\u0430\u043C\u0440\u0435\u043A\u0435\u043B\u0438",
      "gamrekeli",
      "\u10D2\u10D0\u10DB\u10E0\u10D4\u10D9\u10D4\u10DA\u10D8\u10E1",
      "\u0434\u0436\u0438\u043A\u0438\u044F",
      "jikia",
      "\u10EF\u10D8\u10E5\u10D8\u10D0\u10E1",
      "\u0443\u043D\u0438\u0432\u0435\u0440\u0441\u0438\u0442\u0435\u0442\u0441\u043A\u0430\u044F",
      "\u0443\u043D\u0438\u0432\u0435\u0440\u0441\u0438\u0442\u0435\u0442\u0438\u0441",
      "university",
      "\u10E3\u10DC\u10D8\u10D5\u10D4\u10E0\u10E1\u10D8\u10E2\u10D4\u10E2\u10D8\u10E1",
      "\u043A\u0430\u0432\u0442\u0430\u0440\u0430\u0434\u0437\u0435",
      "kavtaradze",
      "\u10E5\u10D0\u10D5\u10D7\u10D0\u10E0\u10D0\u10EB\u10D8\u10E1",
      "\u0441\u0430\u0438\u0440\u043C\u0435",
      "sairme",
      "\u10E1\u10D0\u10D8\u10E0\u10DB\u10D8\u10E1",
      "\u043C\u0438\u043D\u0434\u0430\u043B\u0438",
      "\u043C\u0438\u043D\u0434\u0430\u0434\u0437\u0435",
      "\u0448\u0430\u0440\u0442\u0430\u0432\u0430",
      "shartava",
      "\u10E8\u10D0\u10E0\u10E2\u10D0\u10D5\u10D0\u10E1",
      "\u0438\u043E\u0441\u0435\u0431\u0438\u0434\u0437\u0435",
      "iosebidze",
      "\u10D8\u10DD\u10E1\u10D4\u10D1\u10D8\u10EB\u10D8\u10E1",
      "\u0441\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u0438\u043D",
      "\u0446\u0438\u043D\u0446\u0430\u0434\u0437\u0435",
      "tsintsadze",
      "\u10EA\u10D8\u10DC\u10EA\u10D0\u10EB\u10D8\u10E1",
      "\u0448\u0430\u0432\u0438\u0448\u0432\u0438\u043B\u0438",
      "shavishvili",
      "\u10E8\u10D0\u10D5\u10D8\u10E8\u10D5\u10D8\u10DA\u10D8\u10E1",
      "\u0430\u043B\u0435\u043A\u0441\u0438\u0434\u0437\u0435",
      "aleksidze",
      "\u10D0\u10DA\u10D4\u10E5\u10E1\u10D8\u10EB\u10D8\u10E1",
      "\u0434\u0430\u0442\u0443\u0430\u0448\u0432\u0438\u043B\u0438",
      "datuashvili",
      "\u10D3\u10D0\u10D7\u10E3\u10D0\u10E8\u10D5\u10D8\u10DA\u10D8\u10E1",
      "\u0442\u0430\u0432\u0445\u0435\u043B\u0438\u0434\u0437\u0435",
      "tavkhelidze",
      "\u10D7\u10D0\u10D5\u10EE\u10D4\u10DA\u10D8\u10EB\u10D8\u10E1",
      "\u0447\u0438\u043B\u0430\u0434\u0437\u0435",
      "\u0447\u0438\u043B\u0430\u0434\u0437\u0438\u0435",
      "chiladze",
      "\u10ED\u10D8\u10DA\u10D0\u10EB\u10D8\u10E1",
      "\u043A\u043E\u0441\u0442\u0430\u0432\u0430",
      "kostava",
      "\u10D9\u10DD\u10E1\u10E2\u10D0\u10D5\u10D0\u10E1",
      "\u0433\u0430\u0433\u0430\u0440\u0438\u043D\u0430",
      "gagarin",
      "\u10D2\u10D0\u10D2\u10D0\u10E0\u10D8\u10DC\u10D8\u10E1",
      "\u043C\u0438\u0446\u043A\u0435\u0432\u0438\u0447\u0430",
      "\u043C\u0438\u0446\u043A\u0435\u0432\u0438\u0447\u0438\u0441",
      "mitskevich",
      "\u10DB\u10D8\u10EA\u10D9\u10D4\u10D5\u10D8\u10E9\u10D8\u10E1",
      "\u0442\u0430\u043C\u0430\u0440\u0430\u0448\u0432\u0438\u043B\u0438",
      "tamarashvili",
      "\u10D7\u10D0\u10DB\u10D0\u10E0\u10D0\u10E8\u10D5\u10D8\u10DA\u10D8\u10E1",
      "\u0430\u0441\u0430\u0442\u0438\u0430\u043D\u0438 \u043C.",
      "\u0444\u0430\u043D\u0434\u0436\u0438\u043A\u0438\u0434\u0437\u0435",
      "\u0431\u0443\u0434\u0430\u043F\u0435\u0448\u0442",
      "\u043B\u044C\u0432\u043E\u0432\u0441\u043A\u0430\u044F",
      "\u043E\u043D\u0438\u0430\u0448\u0432\u0438\u043B\u0438",
      "\u043A\u0430\u043C\u0430\u093E\u0928\u093F",
      "\u043A\u0430\u043C\u0430\u043D\u0438\u0441"
    ],
    lat: 41.7254,
    lng: 44.7568,
    isCentral: false
  },
  {
    name: "\u0412\u0435\u0440\u0430 (Vera)",
    shortRu: "\u0412\u0435\u0440\u0430",
    aliases: [
      "\u0432\u0435\u0440\u0430",
      "\u0432\u0435\u0440\u0430\u0437\u0435",
      "vera",
      "\u10D5\u10D4\u10E0\u10D0",
      "\u10D5\u10D4\u10E0\u10D0\u10D6\u10D4",
      "\u0431\u0430\u0440\u043D\u043E\u0432",
      "\u0431\u0430\u0440\u043D\u043E\u0432\u0430",
      "barnov",
      "barnovi",
      "\u10D1\u10D0\u10E0\u10DC\u10DD\u10D5\u10D8\u10E1",
      "\u043A\u0443\u0447\u0443\u043A\u0438\u0434\u0437\u0435",
      "\u043F\u0435\u0442\u0440\u0438\u0430\u0448\u0432\u0438\u043B\u0438",
      "\u0444\u0438\u043B\u0430\u0440\u043C\u043E\u043D\u0438\u044F",
      "\u043C\u0435\u043B\u0438\u043A\u0438\u0448\u0432\u0438\u043B\u0438",
      "melikishvili",
      "\u10DB\u10D4\u10DA\u10D8\u10E5\u10D8\u10E8\u10D5\u10D8\u10DA\u10D8\u10E1",
      "\u0448\u0430\u043D\u0438\u0434\u0437\u0435",
      "\u0433\u043E\u0433\u0435\u0431\u0430\u0448\u0432\u0438\u043B\u0438",
      "\u0445\u043E\u0440\u0430\u0432\u0430",
      "\u043D\u0438\u043A\u043E\u043B\u0430\u0434\u0437\u0435",
      "\u0434\u0436\u0430\u043D\u0430\u0448\u0438\u044F",
      "\u043A\u0440\u0443\u0433 \u0432\u0435\u0440\u044B",
      "\u0442\u0430\u0440\u0445\u043D\u0438\u0448\u0432\u0438\u043B\u0438"
    ],
    lat: 41.7082,
    lng: 44.7834,
    isCentral: true
  },
  {
    name: "\u041C\u0442\u0430\u0446\u043C\u0438\u043D\u0434\u0430 (Mtatsminda)",
    shortRu: "\u041C\u0442\u0430\u0446\u043C\u0438\u043D\u0434\u0430",
    aliases: [
      "\u043C\u0442\u0430\u0446\u043C\u0438\u043D\u0434\u0430",
      "\u043C\u0442\u0430\u0446\u043C\u0438\u043D\u0434",
      "mtatsminda",
      "\u10DB\u10D7\u10D0\u10EC\u10DB\u10D8\u10DC\u10D3\u10D0",
      "\u10DB\u10D7\u10D0\u10EC\u10DB\u10D8\u10DC\u10D3\u10D0\u10D6\u10D4",
      "\u0440\u0443\u0441\u0442\u0430\u0432\u0435\u043B\u0438",
      "rustaveli",
      "\u10E0\u10E3\u10E1\u10D7\u10D0\u10D5\u10D4\u10DA\u10D8\u10E1",
      "\u0444\u0443\u043D\u0438\u043A\u0443\u043B\u0435\u0440",
      "\u0441\u0432\u043E\u0431\u043E\u0434",
      "\u0431\u0435\u0441\u0438\u043A\u0438",
      "\u0433\u0440\u0438\u0431\u043E\u0435\u0434\u043E\u0432",
      "\u0442\u0430\u0431\u0438\u0434\u0437\u0435",
      "\u0437\u043E\u043B\u043E\u0442\u0430\u044F \u043C\u0438\u043B\u044F",
      "\u0438\u043D\u0433\u043E\u0440\u043E\u043A\u0432\u0430",
      "\u0431\u0440\u0430\u0442\u044C\u0435\u0432 \u0437\u0443\u0431\u0430\u043B\u0430\u0448\u0432\u0438\u043B\u0438",
      "\u043C\u0430\u043C\u0430\u0434\u0430\u0432\u0442\u0438",
      "\u0447\u043E\u043D\u043A\u0430\u0434\u0437\u0435"
    ],
    lat: 41.6961,
    lng: 44.7938,
    isCentral: true
  },
  {
    name: "\u0421\u0442\u0430\u0440\u044B\u0439 \u0422\u0431\u0438\u043B\u0438\u0441\u0438 / \u0421\u043E\u043B\u043E\u043B\u0430\u043A\u0438",
    shortRu: "\u0421\u0442\u0430\u0440\u044B\u0439 \u0422\u0431\u0438\u043B\u0438\u0441\u0438",
    aliases: [
      "\u0441\u043E\u043B\u043E\u043B\u0430\u043A\u0438",
      "\u0441\u043E\u043B\u043E\u043B\u0430\u043A",
      "sololaki",
      "\u10E1\u10DD\u10DA\u10DD\u10DA\u10D0\u10D9\u10D8",
      "\u10E1\u10DD\u10DA\u10DD\u10DA\u10D0\u10D9\u10E8\u10D8",
      "\u0441\u0442\u0430\u0440\u044B\u0439 \u0442\u0431\u0438\u043B\u0438\u0441\u0438",
      "\u0441\u0442\u0430\u0440\u043E\u0433\u043E \u0442\u0431\u0438\u043B\u0438\u0441\u0438",
      "old tbilisi",
      "\u0434\u0430\u0434\u0438\u0430\u043D\u0438 \u0448.",
      "\u043A\u0438\u043A\u043E\u0434\u0437\u0435",
      "\u043B\u0435\u0441\u0435\u043B\u0438\u0434\u0437\u0435",
      "\u043A\u043E\u0442\u044D \u0430\u0431\u0445\u0430\u0437\u0438",
      "\u0448\u0438\u043D\u0434\u0438\u0441\u0438",
      "\u043A\u0430\u043B\u0430",
      "\u0430\u043C\u0430\u0433\u043B\u0435\u0431\u0430",
      "\u043B\u0435\u0440\u043C\u043E\u043D\u0442\u043E\u0432",
      "\u0431\u0435\u0442\u043B\u0435\u043C\u0438",
      "\u0441\u0435\u0440\u043D\u044B\u0435 \u0431\u0430\u043D\u0438",
      "\u0430\u0431\u0430\u043D\u043E\u0442\u0443\u0431\u0430\u043D\u0438",
      "\u043C\u0430\u0439\u0434\u0430\u043D\u0438"
    ],
    lat: 41.6899,
    lng: 44.7981,
    isCentral: true
  },
  {
    name: "\u0410\u0432\u043B\u0430\u0431\u0430\u0440\u0438 (Avlabari)",
    shortRu: "\u0410\u0432\u043B\u0430\u0431\u0430\u0440\u0438",
    aliases: [
      "\u0430\u0432\u043B\u0430\u0431\u0430\u0440\u0438",
      "\u0430\u0432\u043B\u0430\u0431\u0430\u0440",
      "avlabari",
      "\u10D0\u10D5\u10DA\u10D0\u10D1\u10D0\u10E0\u10D8",
      "\u10D0\u10D5\u10DA\u10D0\u10D1\u10D0\u10E0\u10E8\u10D8",
      "\u0442\u0440\u043E\u0438\u0446",
      "\u0441\u0430\u043C\u0435\u0431\u0430",
      "\u043C\u0435\u0442\u0440\u043E \u0430\u0432\u043B\u0430\u0431\u0430\u0440\u0438",
      "\u0430\u0440\u043C\u0430\u0437\u0438",
      "\u0434\u0443\u0448\u0435\u0442\u0438",
      "\u0432\u0438\u043D\u043D\u044B\u0439 \u043F\u043E\u0434\u044A\u0435\u043C",
      "\u0435\u0432\u0440\u043E\u043F\u0435\u0439\u0441\u043A\u0430\u044F \u043F\u043B\u043E\u0449\u0430\u0434\u044C",
      "\u0440\u0438\u043A\u044D",
      "\u043A\u0435\u0442\u0435\u0432\u0430\u043D \u0434\u0435\u0434\u043E\u0444\u0430\u043B\u0438",
      "\u043A\u0435\u0442\u0435\u0432\u0430\u043D \u0446\u0445\u0430\u043C\u0435\u0431\u0443\u043B\u0438"
    ],
    lat: 41.6934,
    lng: 44.8142,
    isCentral: false
  },
  {
    name: "\u0427\u0443\u0433\u0443\u0440\u0435\u0442\u0438 / \u041C\u0430\u0440\u0434\u0436\u0430\u043D\u0438\u0448\u0432\u0438\u043B\u0438",
    shortRu: "\u0427\u0443\u0433\u0443\u0440\u0435\u0442\u0438",
    aliases: [
      "\u0447\u0443\u0433\u0443\u0440\u0435\u0442\u0438",
      "\u0447\u0443\u0433\u0443\u0440\u0435\u0442",
      "chugureti",
      "\u10E9\u10E3\u10E6\u10E3\u10E0\u10D4\u10D7\u10D8",
      "\u10E9\u10E3\u10E6\u10E3\u10E0\u10D4\u10D7\u10E8\u10D8",
      "\u043C\u0430\u0440\u0434\u0436\u0430\u043D\u0438\u0448\u0432\u0438\u043B\u0438",
      "marjanishvili",
      "\u10DB\u10D0\u10E0\u10EF\u10D0\u10DC\u10D8\u10E8\u10D5\u10D8\u10DA\u10D8\u10E1",
      "\u0444\u0430\u0431\u0440\u0438\u043A\u0430",
      "fabrika",
      "\u0430\u0433\u043C\u0430\u0448\u0435\u043D\u0435\u0431\u0435\u043B\u0438 \u0434.",
      "\u043A\u0438\u0435\u0432\u0441\u043A\u0430\u044F",
      "\u043A\u043B\u0430\u0440\u0430 \u0446\u0435\u0442\u043A\u0438\u043D",
      "\u0432\u043E\u0440\u043E\u043D\u0446\u043E\u0432",
      "\u0441\u0443\u0445\u043E\u0439 \u043C\u043E\u0441\u0442",
      "\u0446\u0438\u043D\u0430\u043C\u0434\u0437\u0433\u0432\u0440\u0438\u0448\u0432\u0438\u043B\u0438",
      "\u0443\u0437\u043D\u0430\u0434\u0437\u0435",
      "\u043F\u043B\u0438\u0435\u0432",
      "\u0447\u0438\u043A\u043E\u0432\u0430\u043D\u0438"
    ],
    lat: 41.7126,
    lng: 44.8015,
    isCentral: true
  },
  {
    name: "\u0414\u0438\u0434\u0443\u0431\u0435 (Didube)",
    shortRu: "\u0414\u0438\u0434\u0443\u0431\u0435",
    aliases: [
      "\u0434\u0438\u0434\u0443\u0431\u0435",
      "\u0434\u0438\u0434\u0443\u0431\u0435\u0448\u0438",
      "\u0434\u0438\u0434\u0443\u0431",
      "didube",
      "\u10D3\u10D8\u10D3\u10E3\u10D1\u10D4",
      "\u10D3\u10D8\u10D3\u10E3\u10D1\u10D4\u10E8\u10D8",
      "\u0446\u0435\u0440\u0435\u0442\u0435\u043B\u0438",
      "tsereteli",
      "\u10EC\u10D4\u10E0\u10D4\u10D7\u10DA\u10D8\u10E1",
      "\u043F\u0440\u043E\u0441\u043F\u0435\u043A\u0442 \u0446\u0435\u0440\u0435\u0442\u0435\u043B\u0438",
      "\u044D\u043A\u0441\u043F\u043E",
      "expo",
      "\u0433\u0435\u043B\u043E\u0432\u0430\u043D\u0438",
      "\u043C\u0430\u0440\u0448\u0430\u043B\u0430 \u0433\u0435\u043B\u043E\u0432\u0430\u043D\u0438",
      "gelovani",
      "\u10D2\u10D4\u10DA\u10DD\u10D5\u10D0\u10DC\u10D8\u10E1",
      "\u0431\u0430\u0433\u0440\u0430\u0442\u0438\u043E\u043D\u0438",
      "\u043A\u0438\u043F\u0448\u0438\u0434\u0437\u0435",
      "\u0432\u044B\u0441\u0442\u0430\u0432\u043E\u0447\u043D\u044B\u0439 \u0446\u0435\u043D\u0442\u0440",
      "\u0430\u0433\u043B\u0430\u0434\u0437\u0435",
      "\u043C\u0435\u043A\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u0438\u0441",
      "\u043C\u0435\u0445\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u0438",
      "\u043A\u0435\u0434\u0438\u0430\u0441",
      "\u043A\u0435\u0434\u0438\u044F",
      "\u10D9\u10D4\u10D3\u10D8\u10D0\u10E1"
    ],
    lat: 41.7368,
    lng: 44.7825,
    isCentral: false
  },
  {
    name: "\u0412\u0430\u0440\u043A\u0435\u0442\u0438\u043B\u0438 (Varketili)",
    shortRu: "\u0412\u0430\u0440\u043A\u0435\u0442\u0438\u043B\u0438",
    aliases: [
      "\u0432\u0430\u0440\u043A\u0435\u0442\u0438\u043B\u0438",
      "\u0432\u0430\u0440\u043A\u0435\u0442\u0438\u043B\u0448\u0438",
      "\u0432\u0430\u0440\u043A\u0435\u0442\u0438\u043B",
      "varketili",
      "\u10D5\u10D0\u10E0\u10D9\u10D4\u10D7\u10D8\u10DA\u10D8",
      "\u10D5\u10D0\u10E0\u10D9\u10D4\u10D7\u10D8\u10DA\u10E8\u10D8",
      "\u0434\u0436\u0430\u0432\u0430\u0445\u0435\u0442\u0438",
      "\u0441\u0443\u0445\u0438\u0448\u0432\u0438\u043B\u0438",
      "\u0445\u0443\u043C\u0430\u043B\u0430\u0448\u0432\u0438\u043B\u0438",
      "\u043C\u0435\u0442\u0440\u043E \u0432\u0430\u0440\u043A\u0435\u0442\u0438\u043B\u0438",
      "\u043A\u0443\u043F\u0440\u0430\u0434\u0437\u0435",
      "kupradze",
      "\u10D9\u10E3\u10DE\u10E0\u10D0\u10EB\u10D8\u10E1"
    ],
    lat: 41.6998,
    lng: 44.8765,
    isCentral: false
  },
  {
    name: "\u0421\u0430\u043C\u0433\u043E\u0440\u0438 (Samgori)",
    shortRu: "\u0421\u0430\u043C\u0433\u043E\u0440\u0438",
    aliases: [
      "\u0441\u0430\u043C\u0433\u043E\u0440\u0438",
      "\u0441\u0430\u043C\u0433\u043E\u0440\u0448\u0438",
      "\u0441\u0430\u043C\u0433\u043E\u0440",
      "samgori",
      "\u10E1\u10D0\u10DB\u10D2\u10DD\u10E0\u10D8",
      "\u10E1\u10D0\u10DB\u10D2\u10DD\u10E0\u10E8\u10D8",
      "\u043C\u043E\u0441\u043A\u043E\u0432\u0441\u043A\u0438\u0439 \u043F\u0440\u043E\u0441\u043F\u0435\u043A\u0442",
      "\u043C\u043E\u0441\u043A\u043E\u0432\u0441\u043A\u043E\u043C",
      "\u043C\u0435\u0442\u0440\u043E \u0441\u0430\u043C\u0433\u043E\u0440\u0438",
      "\u043A\u0430\u0445\u043E\u0432\u043A\u0430",
      "\u043B\u0438\u043B\u043E",
      "\u0430\u0444\u0440\u0438\u043A\u0430"
    ],
    lat: 41.6865,
    lng: 44.8582,
    isCentral: false
  },
  {
    name: "\u0418\u0441\u0430\u043D\u0438 (Isani)",
    shortRu: "\u0418\u0441\u0430\u043D\u0438",
    aliases: [
      "\u0438\u0441\u0430\u043D\u0438",
      "\u0438\u0441\u0430\u043D\u0448\u0438",
      "isani",
      "\u10D8\u10E1\u10D0\u10DC\u10D8",
      "\u10D8\u10E1\u10D0\u10DC\u10E8\u10D8",
      "\u043D\u0430\u0432\u0442\u043B\u0443\u0433\u0438",
      "\u0433\u0430\u0431\u0440\u0438\u0435\u043B",
      "\u0430\u0431\u0443\u0441\u0435\u0440\u0438\u0434\u0437\u0435",
      "\u0442\u0431\u0435\u043B\u044C",
      "\u043C\u0435\u0442\u0440\u043E \u0438\u0441\u0430\u043D\u0438",
      "\u043B\u0435\u0445\u0430 \u043A\u0430\u0447\u0438\u043D\u044C\u0441\u043A\u043E\u0433\u043E",
      "\u0430\u0446\u043A\u0443\u0440\u0438",
      "\u0434\u043E\u043B\u0430\u0431\u0430\u0443\u0440\u0438",
      "\u043A\u0432\u0430\u0440\u0435\u043B\u0438",
      "\u0431\u0435\u0440\u0438 \u0433\u0430\u0431\u0440\u0438\u044D\u043B",
      "\u0441\u0430\u043B\u043E\u0441",
      "\u0447\u043E\u043B\u043E\u043A\u0430\u0448\u0432\u0438\u043B\u0438"
    ],
    lat: 41.6892,
    lng: 44.8398,
    isCentral: false
  },
  {
    name: "\u0413\u043B\u0434\u0430\u043D\u0438 (Gldani)",
    shortRu: "\u0413\u043B\u0434\u0430\u043D\u0438",
    aliases: [
      "\u0433\u043B\u0434\u0430\u043D\u0438",
      "\u0433\u043B\u0434\u0430\u043D\u0448\u0438",
      "\u0433\u043B\u0434\u0430\u043D",
      "\u0433\u043B\u043E\u0434\u0430\u043D\u0438",
      "gldani",
      "\u10D2\u10DA\u10D3\u10D0\u10DC\u10D8",
      "\u10D2\u10DA\u10D3\u10D0\u10DC\u10E8\u10D8",
      "\u0430\u0445\u043C\u0435\u0442\u0435\u043B\u0438",
      "\u0445\u0438\u0437\u0430\u043D\u0438\u0448\u0432\u0438\u043B\u0438",
      "\u043C\u0438\u043A\u0440\u043E\u0440\u0430\u0439\u043E\u043D \u0433\u043B\u0434\u0430\u043D\u0438",
      "\u0432\u0435\u043A\u0443\u0430",
      "vekua",
      "\u10D5\u10D4\u10D9\u10E3\u10D0\u10E1",
      "\u043C\u0443\u0445\u0438\u0430\u043D\u0438",
      "mukhiani",
      "\u10DB\u10E3\u10EE\u10D8\u10D0\u10DC\u10D8"
    ],
    lat: 41.7923,
    lng: 44.8167,
    isCentral: false
  },
  {
    name: "\u041D\u0430\u0434\u0437\u0430\u043B\u0430\u0434\u0435\u0432\u0438 (Nadzaladevi)",
    shortRu: "\u041D\u0430\u0434\u0437\u0430\u043B\u0430\u0434\u0435\u0432\u0438",
    aliases: [
      "\u043D\u0430\u0434\u0437\u0430\u043B\u0430\u0434\u0435\u0432\u0438",
      "\u043D\u0430\u0434\u0437\u0430\u043B\u0430\u0434\u0435\u0432\u0448\u0438",
      "\u043D\u0430\u0434\u0437\u0430\u043B\u0430\u0434\u0435\u0432",
      "nadzaladevi",
      "\u10DC\u10D0\u10EB\u10D0\u10DA\u10D0\u10D3\u10D4\u10D5\u10D8",
      "\u10DC\u10D0\u10EB\u10D0\u10DA\u10D0\u10D3\u10D4\u10D5\u10E8\u10D8",
      "\u0446\u043E\u0442\u043D\u0435 \u0434\u0430\u0434\u0438\u0430\u043D\u0438",
      "\u043A\u0438\u043A\u0432\u0438\u0434\u0437\u0435",
      "\u043C\u0435\u0442\u0440\u043E \u043D\u0430\u0434\u0437\u0430\u043B\u0430\u0434\u0435\u0432\u0438",
      "\u0447\u043A\u043E\u043D\u0434\u0438\u0434\u0435\u043B\u0438",
      "\u0447\u043A\u043E\u043D\u0434\u0438\u0434\u0435\u043B\u0438\u0441",
      "\u10ED\u10E7\u10DD\u10DC\u10D3\u10D8\u10D3\u10D4\u10DA\u10D8\u10E1",
      "\u0437\u0435\u0434\u0430\u0437\u0435\u043D\u0438",
      "\u0437\u0435\u0434\u0430\u0437\u0435\u043D\u0438\u0441",
      "\u10D6\u10D4\u10D3\u10D0\u10D6\u10D4\u10DC\u10D8\u10E1",
      "\u0433\u043E\u0446\u0438\u0440\u0438\u0434\u0437\u0435"
    ],
    lat: 41.7345,
    lng: 44.7985,
    isCentral: false
  },
  {
    name: "\u0421\u0430\u043D\u0437\u043E\u043D\u0430 (Sanzona)",
    shortRu: "\u0421\u0430\u043D\u0437\u043E\u043D\u0430",
    aliases: [
      "\u0441\u0430\u043D\u0437\u043E\u043D\u0430",
      "\u0441\u0430\u043D\u0437\u043E\u043D",
      "sanzona",
      "\u10E1\u10D0\u10DC\u10D6\u10DD\u10DC\u10D0",
      "\u0433\u0443\u0440\u0430\u043C\u0438\u0448\u0432\u0438\u043B\u0438",
      "\u0433\u0443\u0440\u043C\u0438\u0448\u0432\u0438\u043B\u0438",
      "guramishvili",
      "\u10D2\u10E3\u10E0\u10D0\u10DB\u10D8\u10E8\u10D5\u10D8\u10DA\u10D8\u10E1",
      "\u0433\u0440\u043C\u0430\u0433\u0435\u043B\u0435",
      "\u0441\u0430\u0440\u0430\u0434\u0436\u0438\u0448\u0432\u0438\u043B\u0438"
    ],
    lat: 41.7589,
    lng: 44.7995,
    isCentral: false
  },
  {
    name: "\u0412\u0430\u043A\u0435 (Vake)",
    shortRu: "\u0412\u0430\u043A\u0435",
    aliases: [
      "\u0432\u0430\u043A\u0435",
      "\u0432\u0430\u043A\u0435\u0448\u0438",
      "vake",
      "\u10D5\u10D0\u10D9\u10D4",
      "\u10D5\u10D0\u10D9\u10D4\u10E8\u10D8",
      "\u0447\u0430\u0432\u0447\u0430\u0432\u0430\u0434\u0437\u0435",
      "chavchavadze",
      "\u10ED\u10D0\u10D5\u10ED\u10D0\u10D5\u10D0\u10EB\u10D8\u10E1",
      "\u0430\u0440\u0430\u043A\u0438\u0448\u0432\u0438\u043B\u0438",
      "\u0430\u0431\u0430\u0448\u0438\u0434\u0437\u0435 \u0438.",
      "\u043F\u0430\u043B\u0438\u0430\u0448\u0432\u0438\u043B\u0438",
      "paliashvili",
      "\u10E4\u10D0\u10DA\u10D8\u10D0\u10E8\u10D5\u10D8\u10DA\u10D8\u10E1",
      "\u043C\u0437\u0438\u0443\u0440\u0438",
      "\u0430\u0442\u0435\u043D\u0438",
      "\u0430\u0442\u0435\u043D\u0438\u0441",
      "ateni",
      "\u10D0\u10E2\u10D4\u10DC\u10D8\u10E1",
      "\u043C\u043E\u0441\u0430\u0448\u0432\u0438\u043B\u0438",
      "mosashvili",
      "\u10DB\u10DD\u10E1\u10D0\u10E8\u10D5\u10D8\u10DA\u10D8\u10E1",
      "\u043A\u043E\u0432\u0430\u043B\u0435\u0432\u0441\u043A\u043E\u0439",
      "\u0442\u0430\u0440\u0430\u0441\u0430 \u0448\u0435\u0432\u0447\u0435\u043D\u043A\u043E",
      "\u043C\u0430\u0440\u0433\u0435\u043B\u0430\u043D\u0438",
      "\u0436\u0432\u0430\u043D\u0438\u0430",
      "\u0436\u0432\u0430\u043D\u0438\u044F",
      "zhvania",
      "\u10DF\u10D5\u10D0\u10DC\u10D8\u10D0\u10E1",
      "\u043A\u0438\u043F\u0448\u0438\u0434\u0437\u0435 \u043D.",
      "\u0448\u0430\u0442\u0440\u043E",
      "\u0440\u0430\u0434\u0438\u0430\u043D\u0438",
      "\u0442\u0430\u043A\u0442\u0438\u043A\u0438\u0448\u0432\u0438\u043B\u0438",
      "\u043C\u0446\u0445\u0435\u0442\u0430",
      "\u043C\u0446\u0445\u0435\u0442\u0438\u0441"
    ],
    lat: 41.7118,
    lng: 44.7571,
    isCentral: true
  }
];
var TBILISI_DISTRICTS = TBILISI_DISTRICT_LIST.map((d) => d.name);
var DISTRICT_COORDS = TBILISI_DISTRICT_LIST.reduce((acc, curr) => {
  acc[curr.name] = { lat: curr.lat, lng: curr.lng };
  return acc;
}, {});
var TBILISI_STREET_COORDS = [
  // Saburtalo streets
  { keywords: ["\u043A\u0430\u0432\u0442\u0430\u0440\u0430\u0434\u0437\u0435", "\u10E5\u10D0\u10D5\u10D7\u10D0\u10E0\u10D0\u10EB", "kavtaradze"], lat: 41.7217, lng: 44.7358, district: "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E (Saburtalo)" },
  { keywords: ["\u0448\u0430\u0432\u0438\u0448\u0432\u0438\u043B\u0438", "\u10E8\u10D0\u10D5\u10D8\u10E8\u10D5\u10D8\u10DA", "shavishvili"], lat: 41.7224, lng: 44.7379, district: "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E (Saburtalo)" },
  { keywords: ["\u0443\u043D\u0438\u0432\u0435\u0440\u0441\u0438\u0442\u0435\u0442", "\u10E3\u10DC\u10D8\u10D5\u10D4\u10E0\u10E1\u10D8\u10E2\u10D4\u10E2", "university"], lat: 41.7201, lng: 44.7265, district: "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E (Saburtalo)" },
  { keywords: ["\u043F\u043E\u043B\u0438\u0442\u043A\u043E\u0432\u0441\u043A", "\u0434\u0436\u0438\u043A\u0438\u044F", "\u10DE\u10DD\u10DA\u10D8\u10E2\u10D9\u10DD\u10D5\u10E1\u10D9", "\u10EF\u10D8\u10E5\u10D8\u10D0", "politkovsk", "jikia"], lat: 41.7192, lng: 44.7168, district: "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E (Saburtalo)" },
  { keywords: ["\u0446\u0438\u043D\u0446\u0430\u0434\u0437\u0435", "\u10EA\u10D8\u10DC\u10EA\u10D0\u10EB", "tsintsadze"], lat: 41.7248, lng: 44.7654, district: "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E (Saburtalo)" },
  { keywords: ["\u0448\u0430\u0440\u0442\u0430\u0432\u0430", "\u10E8\u10D0\u10E0\u10E2\u10D0\u10D5\u10D0", "shartava"], lat: 41.7315, lng: 44.7689, district: "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E (Saburtalo)" },
  { keywords: ["\u043F\u0435\u043A\u0438\u043D", "\u10DE\u10D4\u10D9\u10D8\u10DC", "pekini"], lat: 41.7258, lng: 44.7698, district: "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E (Saburtalo)" },
  { keywords: ["\u043A\u0430\u0437\u0431\u0435\u0433\u0438", "\u10E7\u10D0\u10D6\u10D1\u10D4\u10D2", "kazbegi"], lat: 41.7242, lng: 44.7535, district: "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E (Saburtalo)" },
  { keywords: ["\u0432\u0430\u0436\u0430", "\u043F\u0448\u0430\u0432\u0435\u043B\u0430", "\u10D5\u10D0\u10DF\u10D0", "\u10E4\u10E8\u10D0\u10D5\u10D4\u10DA\u10D0", "vazha"], lat: 41.7235, lng: 44.7445, district: "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E (Saburtalo)" },
  { keywords: ["\u043D\u0443\u0446\u0443\u0431\u0438\u0434\u0437\u0435", "\u10DC\u10E3\u10EA\u10E3\u10D1\u10D8\u10EB", "nutsubidze", "\u0434\u0430\u0442\u0443\u0430\u0448\u0432\u0438\u043B\u0438", "\u10D3\u10D0\u10D7\u10E3\u10D0\u10E8\u10D5\u10D8\u10DA"], lat: 41.7285, lng: 44.7362, district: "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E (Saburtalo)" },
  { keywords: ["\u0431\u0430\u0445\u0442\u0440\u0438\u043E\u043D\u0438", "\u10D1\u10D0\u10EE\u10E2\u10E0\u10D8\u10DD\u10DC", "bakhtrioni"], lat: 41.7219, lng: 44.7641, district: "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E (Saburtalo)" },
  { keywords: ["\u0430\u043B\u0435\u043A\u0441\u0438\u0434\u0437\u0435", "\u10D0\u10DA\u10D4\u10E5\u10E1\u10D8\u10EB", "aleksidze", "king david"], lat: 41.7186, lng: 44.7805, district: "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E (Saburtalo)" },
  { keywords: ["\u0442\u0430\u0432\u0445\u0435\u043B\u0438\u0434\u0437\u0435", "\u10D7\u10D0\u10D5\u10EE\u10D4\u10DA\u10D8\u10EB", "tavkhelidze"], lat: 41.7239, lng: 44.7485, district: "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E (Saburtalo)" },
  { keywords: ["\u0447\u0438\u043B\u0430\u0434\u0437\u0435", "\u0447\u0438\u043B\u0430\u0434\u0437\u0438\u0435", "\u10ED\u10D8\u10DA\u10D0\u10EB", "chiladze"], lat: 41.7269, lng: 44.7562, district: "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E (Saburtalo)" },
  { keywords: ["\u043A\u043E\u0441\u0442\u0430\u0432\u0430", "\u10D9\u10DD\u10E1\u10E2\u10D0\u10D5\u10D0", "kostava"], lat: 41.7172, lng: 44.7775, district: "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E (Saburtalo)" },
  { keywords: ["\u043C\u0438\u0446\u043A\u0435\u0432\u0438\u0447", "\u10DB\u10D8\u10EA\u10D9\u10D4\u10D5\u10D8\u10E9", "mitskevich"], lat: 41.7262, lng: 44.7634, district: "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E (Saburtalo)" },
  { keywords: ["\u0441\u0430\u0438\u0440\u043C\u0435", "\u10E1\u10D0\u10D8\u10E0\u10DB", "sairme"], lat: 41.7222, lng: 44.7575, district: "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E (Saburtalo)" },
  { keywords: ["\u0442\u0430\u043C\u0430\u0440\u0430\u0448\u0432\u0438\u043B\u0438", "\u10D7\u10D0\u10DB\u10D0\u10E0\u10D0\u10E8\u10D5\u10D8\u10DA", "tamarashvili"], lat: 41.7168, lng: 44.7492, district: "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E (Saburtalo)" },
  { keywords: ["\u0438\u043E\u0441\u0435\u0431\u0438\u0434\u0437\u0435", "\u10D8\u10DD\u10E1\u10D4\u10D1\u10D8\u10EB", "iosebidze"], lat: 41.7288, lng: 44.7721, district: "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E (Saburtalo)" },
  { keywords: ["\u0433\u0430\u0433\u0430\u0440\u0438\u043D", "\u10D2\u10D0\u10D2\u10D0\u10E0\u10D8\u10DC", "gagarin"], lat: 41.7351, lng: 44.7695, district: "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E (Saburtalo)" },
  { keywords: ["\u0444\u0430\u043D\u0434\u0436\u0438\u043A\u0438\u0434\u0437\u0435", "\u0431\u0443\u0434\u0430\u043F\u0435\u0448\u0442", "\u10E4\u10D0\u10DC\u10EF\u10D8\u10D9\u10D8\u10EB", "\u10D1\u10E3\u10D3\u10D0\u10DE\u10D4\u10E8\u10E2"], lat: 41.7295, lng: 44.7582, district: "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E (Saburtalo)" },
  { keywords: ["\u0433\u0430\u043C\u0440\u0435\u043A\u0435\u043B\u0438", "\u10D2\u10D0\u10DB\u10E0\u10D4\u10D9\u10D4\u10DA", "gamrekeli"], lat: 41.7271, lng: 44.7618, district: "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E (Saburtalo)" },
  { keywords: ["\u0430\u0441\u0430\u0442\u0438\u0430\u043D\u0438 \u043C.", "\u043C\u0438\u0445\u0430\u0438\u043B\u0430 \u0430\u0441\u0430\u0442\u0438\u0430\u043D\u0438", "\u10D0\u10E1\u10D0\u10D7\u10D8\u10D0\u10DC\u10D8"], lat: 41.7215, lng: 44.7498, district: "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E (Saburtalo)" },
  { keywords: ["\u0431\u043E\u0447\u043E\u0440\u0438\u0448\u0432\u0438\u043B\u0438", "\u10D1\u10DD\u10ED\u10DD\u10E0\u10D8\u10E8\u10D5\u10D8\u10DA"], lat: 41.7204, lng: 44.7792, district: "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E (Saburtalo)" },
  { keywords: ["\u043A\u0430\u043C\u0430\u043D\u0438", "\u10D9\u10D0\u10DB\u10D0\u10DC"], lat: 41.7282, lng: 44.7495, district: "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E (Saburtalo)" },
  // Vake & Bagebi streets
  { keywords: ["\u0447\u0430\u0432\u0447\u0430\u0432\u0430\u0434\u0437\u0435", "\u10ED\u10D0\u10D5\u10ED\u10D0\u10D5\u10D0\u10EB", "chavchavadze"], lat: 41.7098, lng: 44.7615, district: "\u0412\u0430\u043A\u0435 (Vake)" },
  { keywords: ["\u043F\u0430\u043B\u0438\u0430\u0448\u0432\u0438\u043B\u0438", "\u10E4\u10D0\u10DA\u10D8\u10D0\u10E8\u10D5\u10D8\u10DA", "paliashvili"], lat: 41.7089, lng: 44.7652, district: "\u0412\u0430\u043A\u0435 (Vake)" },
  { keywords: ["\u0430\u0431\u0430\u0448\u0438\u0434\u0437\u0435 \u0438.", "\u0438\u0440\u0430\u043A\u043B\u0438\u044F \u0430\u0431\u0430\u0448\u0438\u0434\u0437\u0435", "\u10D0\u10D1\u10D0\u10E8\u10D8\u10EB\u10D8\u10E1"], lat: 41.7079, lng: 44.7661, district: "\u0412\u0430\u043A\u0435 (Vake)" },
  { keywords: ["\u0436\u0432\u0430\u043D\u0438\u0430", "\u0436\u0432\u0430\u043D\u0438\u044F", "\u10DF\u10D5\u10D0\u10DC\u10D8\u10D0", "zhvania"], lat: 41.7048, lng: 44.7575, district: "\u0412\u0430\u043A\u0435 (Vake)" },
  { keywords: ["\u0430\u0442\u0435\u043D\u0438", "\u0430\u0442\u0435\u043D\u0438\u0441", "\u10D0\u10E2\u10D4\u10DC\u10D8\u10E1", "ateni"], lat: 41.7105, lng: 44.7712, district: "\u0412\u0430\u043A\u0435 (Vake)" },
  { keywords: ["\u043C\u043E\u0441\u0430\u0448\u0432\u0438\u043B\u0438", "\u10DB\u10DD\u10E1\u10D0\u10E8\u10D5\u10D8\u10DA", "mosashvili"], lat: 41.7104, lng: 44.7628, district: "\u0412\u0430\u043A\u0435 (Vake)" },
  { keywords: ["\u0430\u0440\u0430\u043A\u0438\u0448\u0432\u0438\u043B\u0438", "\u10D0\u10E0\u10D0\u10E7\u10D8\u10E8\u10D5\u10D8\u10DA", "arakishvili"], lat: 41.7085, lng: 44.7685, district: "\u0412\u0430\u043A\u0435 (Vake)" },
  { keywords: ["\u043A\u0438\u043F\u0448\u0438\u0434\u0437\u0435", "\u10E7\u10D8\u10E4\u10E8\u10D8\u10EB", "kipshidze"], lat: 41.7119, lng: 44.7524, district: "\u0412\u0430\u043A\u0435 (Vake)" },
  { keywords: ["\u043C\u0446\u0445\u0435\u0442\u0430", "\u043C\u0446\u0445\u0435\u0442\u0438\u0441", "\u10DB\u10EA\u10EE\u10D4\u10D7\u10D8\u10E1"], lat: 41.7072, lng: 44.7695, district: "\u0412\u0430\u043A\u0435 (Vake)" },
  { keywords: ["\u0431\u0430\u0433\u0435\u0431\u0438", "\u0431\u0430\u0433\u0435\u0431\u0448\u0438", "\u10D1\u10D0\u10D2\u10D4\u10D1", "\u0446\u0445\u043D\u0435\u0442\u0438\u0441", "\u10EC\u10E7\u10DC\u10D4\u10D7\u10D8\u10E1"], lat: 41.7085, lng: 44.7325, district: "\u0411\u0430\u0433\u0435\u0431\u0438 (Bagebi)" },
  // Vera & Mtatsminda & Sololaki streets
  { keywords: ["\u043C\u0435\u043B\u0438\u043A\u0438\u0448\u0432\u0438\u043B\u0438", "\u10DB\u10D4\u10DA\u10D8\u10E5\u10D8\u10E8\u10D5\u10D8\u10DA", "melikishvili"], lat: 41.7094, lng: 44.7805, district: "\u0412\u0435\u0440\u0430 (Vera)" },
  { keywords: ["\u0431\u0430\u0440\u043D\u043E\u0432", "\u10D1\u10D0\u10E0\u10DC\u10DD\u10D5", "barnov"], lat: 41.7058, lng: 44.7818, district: "\u0412\u0435\u0440\u0430 (Vera)" },
  { keywords: ["\u0433\u043E\u0433\u0435\u0431\u0430\u0448\u0432\u0438\u043B\u0438", "\u10D2\u10DD\u10D2\u10D4\u10D1\u10D0\u10E8\u10D5\u10D8\u10DA", "gogebashvili"], lat: 41.7049, lng: 44.7845, district: "\u0412\u0435\u0440\u0430 (Vera)" },
  { keywords: ["\u043F\u0435\u0442\u0440\u0438\u0430\u0448\u0432\u0438\u043B\u0438", "\u10DE\u10D4\u10E2\u10E0\u10D8\u10D0\u10E8\u10D5\u10D8\u10DA", "petriashvili"], lat: 41.7069, lng: 44.7792, district: "\u0412\u0435\u0440\u0430 (Vera)" },
  { keywords: ["\u0440\u0443\u0441\u0442\u0430\u0432\u0435\u043B\u0438", "\u10E0\u10E3\u10E1\u10D7\u10D0\u10D5\u10D4\u10DA", "rustaveli"], lat: 41.6995, lng: 44.7945, district: "\u041C\u0442\u0430\u0446\u043C\u0438\u043D\u0434\u0430 (Mtatsminda)" },
  { keywords: ["\u0438\u043D\u0433\u043E\u0440\u043E\u043A\u0432\u0430", "\u10D8\u10DC\u10D2\u10DD\u10E0\u10DD\u10E7\u10D5\u10D0", "ingorokva"], lat: 41.6968, lng: 44.7948, district: "\u041C\u0442\u0430\u0446\u043C\u0438\u043D\u0434\u0430 (Mtatsminda)" },
  { keywords: ["\u0447\u043E\u043D\u043A\u0430\u0434\u0437\u0435", "\u10ED\u10DD\u10DC\u10E5\u10D0\u10EB", "chonkadze"], lat: 41.6938, lng: 44.7925, district: "\u041C\u0442\u0430\u0446\u043C\u0438\u043D\u0434\u0430 (Mtatsminda)" },
  { keywords: ["\u0430\u043C\u0430\u0433\u043B\u0435\u0431\u0430", "\u10D0\u10DB\u10D0\u10E6\u10DA\u10D4\u10D1", "amagleba"], lat: 41.6895, lng: 44.7965, district: "\u0421\u0442\u0430\u0440\u044B\u0439 \u0422\u0431\u0438\u043B\u0438\u0441\u0438 / \u0421\u043E\u043B\u043E\u043B\u0430\u043A\u0438" },
  { keywords: ["\u043B\u0435\u0440\u043C\u043E\u043D\u0442\u043E\u0432", "\u10DA\u10D4\u10E0\u10DB\u10DD\u10DC\u10E2\u10DD\u10D5", "lermontov"], lat: 41.6912, lng: 44.7992, district: "\u0421\u0442\u0430\u0440\u044B\u0439 \u0422\u0431\u0438\u043B\u0438\u0441\u0438 / \u0421\u043E\u043B\u043E\u043B\u0430\u043A\u0438" },
  // Didi Dighomi streets
  { keywords: ["\u043C\u0438\u0440\u0438\u0430\u043D\u0430", "\u043C\u0438\u0440\u0438\u0430\u043D", "\u10DB\u10D8\u10E0\u10D8\u10D0\u10DC", "mirian"], lat: 41.7875, lng: 44.7568, district: "\u0414\u0438\u0434\u0438 \u0414\u0438\u0433\u043E\u043C\u0438 (Didi Dighomi)" },
  { keywords: ["\u043F\u0435\u0442\u0440\u0438\u0446\u0438", "\u10DE\u10D4\u10E2\u10E0\u10D8\u10EC", "petritsi"], lat: 41.7842, lng: 44.7595, district: "\u0414\u0438\u0434\u0438 \u0414\u0438\u0433\u043E\u043C\u0438 (Didi Dighomi)" },
  { keywords: ["\u0444\u0430\u0440\u043D\u0430\u0432\u0430\u0437", "\u10E4\u10D0\u10E0\u10DC\u10D0\u10D5\u10D0\u10D6", "farnavaz"], lat: 41.7825, lng: 44.7645, district: "\u0414\u0438\u0434\u0438 \u0414\u0438\u0433\u043E\u043C\u0438 (Didi Dighomi)" },
  { keywords: ["\u0442\u0430\u0432\u0434\u0430\u0434\u0435\u0431\u0443\u043B\u0438", "\u0434\u0435\u043C\u0435\u0442\u0440\u0435", "\u10D7\u10D0\u10D5\u10D3\u10D0\u10D3\u10D4\u10D1\u10E3\u10DA", "demetre"], lat: 41.7912, lng: 44.7532, district: "\u0414\u0438\u0434\u0438 \u0414\u0438\u0433\u043E\u043C\u0438 (Didi Dighomi)" },
  { keywords: ["\u0431\u043E\u0431 \u0443\u043E\u043B\u0448", "\u0443\u043E\u043B\u0448\u0438\u0441", "\u10E3\u10DD\u10DA\u10E8", "bob walsh"], lat: 41.7745, lng: 44.7712, district: "\u0414\u0438\u0434\u0438 \u0414\u0438\u0433\u043E\u043C\u0438 (Didi Dighomi)" },
  { keywords: ["\u0442\u0435\u0438\u043C\u0443\u0440\u0430\u0437", "\u10D7\u10D4\u10D8\u10DB\u10E3\u10E0\u10D0\u10D6", "teimuraz"], lat: 41.7889, lng: 44.7545, district: "\u0414\u0438\u0434\u0438 \u0414\u0438\u0433\u043E\u043C\u0438 (Didi Dighomi)" },
  { keywords: ["\u0430\u0431\u0430\u0448\u0438\u0434\u0437\u0435-\u043E\u0440\u0431\u0435\u043B\u0438\u0430\u043D\u0438", "\u043E\u0440\u0431\u0435\u043B\u0438\u0430\u043D\u0438 \u043D."], lat: 41.7852, lng: 44.7581, district: "\u0414\u0438\u0434\u0438 \u0414\u0438\u0433\u043E\u043C\u0438 (Didi Dighomi)" },
  { keywords: ["\u0430\u0433\u043C\u0430\u0448\u0435\u043D\u0435\u0431\u0435\u043B\u0438 \u0445\u0435\u0439\u0432", "\u0430\u043B\u043B\u0435\u044F \u0430\u0433\u043C\u0430\u0448\u0435\u043D\u0435\u0431\u0435\u043B\u0438", "\u10D0\u10E6\u10DB\u10D0\u10E8\u10D4\u10DC\u10D4\u10D1\u10DA\u10D8\u10E1 \u10EE\u10D4\u10D8\u10D5"], lat: 41.7785, lng: 44.7695, district: "\u0414\u0438\u0434\u0438 \u0414\u0438\u0433\u043E\u043C\u0438 (Didi Dighomi)" },
  // Didube & Chugureti & Nadzaladevi & Gldani streets
  { keywords: ["\u0446\u0435\u0440\u0435\u0442\u0435\u043B\u0438", "\u10EC\u10D4\u10E0\u10D4\u10D7\u10DA", "tsereteli"], lat: 41.7355, lng: 44.7842, district: "\u0414\u0438\u0434\u0443\u0431\u0435 (Didube)" },
  { keywords: ["\u0433\u0435\u043B\u043E\u0432\u0430\u043D\u0438", "\u10D2\u10D4\u10DA\u10DD\u10D5\u10D0\u10DC", "gelovani"], lat: 41.7495, lng: 44.7715, district: "\u0414\u0438\u0434\u0443\u0431\u0435 (Didube)" },
  { keywords: ["\u043A\u0435\u0434\u0438\u0430", "\u043A\u0435\u0434\u0438\u0430\u0441", "\u10D9\u10D4\u10D3\u10D8\u10D0", "kedia"], lat: 41.7392, lng: 44.7815, district: "\u0414\u0438\u0434\u0443\u0431\u0435 (Didube)" },
  { keywords: ["\u043C\u0435\u043A\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u0438\u0441", "\u043C\u0435\u0445\u0430\u043D\u0438\u0437\u0430\u0446", "\u10DB\u10D4\u10E5\u10D0\u10DC\u10D8\u10D6\u10D0\u10EA\u10D8\u10D8\u10E1"], lat: 41.7425, lng: 44.7828, district: "\u0414\u0438\u0434\u0443\u0431\u0435 (Didube)" },
  { keywords: ["\u0430\u0433\u043B\u0430\u0434\u0437\u0435", "\u10D0\u10D2\u10DA\u10D0\u10EB", "agladze"], lat: 41.7342, lng: 44.7798, district: "\u0414\u0438\u0434\u0443\u0431\u0435 (Didube)" },
  { keywords: ["\u043C\u0430\u0440\u0434\u0436\u0430\u043D\u0438\u0448\u0432\u0438\u043B\u0438", "\u10DB\u10D0\u10E0\u10EF\u10D0\u10DC\u10D8\u10E8\u10D5\u10D8\u10DA", "marjanishvili"], lat: 41.7095, lng: 44.7975, district: "\u0427\u0443\u0433\u0443\u0440\u0435\u0442\u0438 / \u041C\u0430\u0440\u0434\u0436\u0430\u043D\u0438\u0448\u0432\u0438\u043B\u0438" },
  { keywords: ["\u0430\u0433\u043C\u0430\u0448\u0435\u043D\u0435\u0431\u0435\u043B\u0438", "\u10D0\u10E6\u10DB\u10D0\u10E8\u10D4\u10DC\u10D4\u10D1\u10DA", "agmashenebeli"], lat: 41.7115, lng: 44.7962, district: "\u0427\u0443\u0433\u0443\u0440\u0435\u0442\u0438 / \u041C\u0430\u0440\u0434\u0436\u0430\u043D\u0438\u0448\u0432\u0438\u043B\u0438" },
  { keywords: ["\u0446\u0438\u043D\u0430\u043C\u0434\u0437\u0433\u0432\u0440\u0438\u0448\u0432\u0438\u043B\u0438", "\u10EC\u10D8\u10DC\u10D0\u10DB\u10EB\u10E6\u10D5\u10E0\u10D8\u10E8\u10D5\u10D8\u10DA"], lat: 41.7138, lng: 44.7995, district: "\u0427\u0443\u0433\u0443\u0440\u0435\u0442\u0438 / \u041C\u0430\u0440\u0434\u0436\u0430\u043D\u0438\u0448\u0432\u0438\u043B\u0438" },
  { keywords: ["\u0443\u0437\u043D\u0430\u0434\u0437\u0435", "\u10E3\u10D6\u10DC\u10D0\u10EB", "uznadze"], lat: 41.7105, lng: 44.7942, district: "\u0427\u0443\u0433\u0443\u0440\u0435\u0442\u0438 / \u041C\u0430\u0440\u0434\u0436\u0430\u043D\u0438\u0448\u0432\u0438\u043B\u0438" },
  { keywords: ["\u0447\u043A\u043E\u043D\u0434\u0438\u0434\u0435\u043B\u0438", "\u10ED\u10E7\u10DD\u10DC\u10D3\u10D8\u10D3\u10D4\u10DA", "chkondideli"], lat: 41.7365, lng: 44.7948, district: "\u041D\u0430\u0434\u0437\u0430\u043B\u0430\u0434\u0435\u0432\u0438 (Nadzaladevi)" },
  { keywords: ["\u0446\u043E\u0442\u043D\u0435 \u0434\u0430\u0434\u0438\u0430\u043D\u0438", "\u0434\u0430\u0434\u0438\u0430\u043D\u0438 \u0446.", "\u10EA\u10DD\u10E2\u10DC\u10D4 \u10D3\u10D0\u10D3\u10D8\u10D0\u10DC"], lat: 41.7325, lng: 44.7995, district: "\u041D\u0430\u0434\u0437\u0430\u043B\u0430\u0434\u0435\u0432\u0438 (Nadzaladevi)" },
  { keywords: ["\u0437\u0435\u0434\u0430\u0437\u0435\u043D\u0438", "\u10D6\u10D4\u10D3\u10D0\u10D6\u10D4\u10DC", "zedazeni"], lat: 41.7385, lng: 44.8012, district: "\u041D\u0430\u0434\u0437\u0430\u043B\u0430\u0434\u0435\u0432\u0438 (Nadzaladevi)" },
  { keywords: ["\u0433\u0443\u0440\u0430\u043C\u0438\u0448\u0432\u0438\u043B\u0438", "\u0433\u0443\u0440\u043C\u0438\u0448\u0432\u0438\u043B\u0438", "\u10D2\u10E3\u10E0\u10D0\u10DB\u10D8\u10E8\u10D5\u10D8\u10DA", "guramishvili"], lat: 41.7615, lng: 44.7985, district: "\u0421\u0430\u043D\u0437\u043E\u043D\u0430 (Sanzona)" },
  { keywords: ["\u0432\u0435\u043A\u0443\u0430", "\u10D5\u10D4\u10D9\u10E3\u10D0", "vekua"], lat: 41.7938, lng: 44.8195, district: "\u0413\u043B\u0434\u0430\u043D\u0438 (Gldani)" },
  { keywords: ["\u0445\u0438\u0437\u0430\u043D\u0438\u0448\u0432\u0438\u043B\u0438", "\u10EE\u10D8\u10D6\u10D0\u10DC\u10D8\u10E8\u10D5\u10D8\u10DA", "khizanishvili"], lat: 41.7955, lng: 44.8152, district: "\u0413\u043B\u0434\u0430\u043D\u0438 (Gldani)" },
  // Ortachala, Krtsanisi, Isani, Avlabari, Samgori, Varketili streets
  { keywords: ["\u0433\u043E\u0440\u0433\u0430\u0441\u0430\u043B\u0438", "\u10D2\u10DD\u10E0\u10D2\u10D0\u10E1\u10DA", "gorgasali"], lat: 41.6815, lng: 44.8195, district: "\u041E\u0440\u0442\u0430\u0447\u0430\u043B\u0430 (Ortachala)" },
  { keywords: ["\u0433\u0443\u043B\u0443\u0430", "\u0433\u0443\u043B\u0438\u044F", "\u10D2\u10E3\u10DA\u10E3\u10D0", "gulua"], lat: 41.6768, lng: 44.8245, district: "\u041E\u0440\u0442\u0430\u0447\u0430\u043B\u0430 (Ortachala)" },
  { keywords: ["\u0431\u043E\u0447\u043E\u0440\u043C\u0430", "\u0431\u043E\u0447\u043E\u0440\u043C\u0438", "\u10D1\u10DD\u10ED\u10DD\u10E0\u10DB", "bochorma"], lat: 41.6882, lng: 44.8285, district: "\u041E\u0440\u0442\u0430\u0447\u0430\u043B\u0430 (Ortachala)" },
  { keywords: ["\u0432\u043E\u043B\u0441\u043A\u0438", "\u0432\u043E\u043B\u044C\u0441\u043A", "\u10D5\u10DD\u10DA\u10E1\u10D9", "volski"], lat: 41.6705, lng: 44.8165, district: "\u041A\u0440\u0446\u0430\u043D\u0438\u0441\u0438 (Krtsanisi)" },
  { keywords: ["\u043A\u0440\u0446\u0430\u043D\u0438\u0441\u0438", "\u10D9\u10E0\u10EC\u10D0\u10DC\u10D8\u10E1", "krtsanisi"], lat: 41.6725, lng: 44.8185, district: "\u041A\u0440\u0446\u0430\u043D\u0438\u0441\u0438 (Krtsanisi)" },
  { keywords: ["\u043A\u0435\u0442\u0435\u0432\u0430\u043D", "\u10E5\u10D4\u10D7\u10D4\u10D5\u10D0\u10DC", "ketevan"], lat: 41.6915, lng: 44.8215, district: "\u0410\u0432\u043B\u0430\u0431\u0430\u0440\u0438 (Avlabari)" },
  { keywords: ["\u043B\u0435\u0445\u0430 \u043A\u0430\u0447\u0438\u043D\u044C\u0441\u043A", "\u043A\u0430\u0447\u0438\u043D\u0441\u043A", "\u10D9\u10D0\u10E9\u10D8\u10DC\u10E1\u10D9"], lat: 41.6888, lng: 44.8325, district: "\u0418\u0441\u0430\u043D\u0438 (Isani)" },
  { keywords: ["\u0433\u0430\u0431\u0440\u0438\u044D\u043B", "\u0433\u0430\u0431\u0440\u0438\u0435\u043B", "\u0441\u0430\u043B\u043E\u0441", "\u10D1\u10D4\u10E0\u10D8 \u10D2\u10D0\u10D1\u10E0\u10D8\u10D4\u10DA", "salosi"], lat: 41.6795, lng: 44.8512, district: "\u0418\u0441\u0430\u043D\u0438 (Isani)" },
  { keywords: ["\u043D\u0430\u0432\u0442\u043B\u0443\u0433", "\u10DC\u10D0\u10D5\u10D7\u10DA\u10E3\u10E6", "navtlugi"], lat: 41.6855, lng: 44.8425, district: "\u0418\u0441\u0430\u043D\u0438 (Isani)" },
  { keywords: ["\u0447\u043E\u043B\u043E\u043A\u0430\u0448\u0432\u0438\u043B\u0438", "\u10E9\u10DD\u10DA\u10DD\u10E7\u10D0\u10E8\u10D5\u10D8\u10DA", "cholokashvili"], lat: 41.6845, lng: 44.8365, district: "\u0418\u0441\u0430\u043D\u0438 (Isani)" },
  { keywords: ["\u043C\u043E\u0441\u043A\u043E\u0432\u0441\u043A", "\u10DB\u10DD\u10E1\u10D9\u10DD\u10D5\u10D8\u10E1", "moscow"], lat: 41.6785, lng: 44.8685, district: "\u0421\u0430\u043C\u0433\u043E\u0440\u0438 (Samgori)" },
  { keywords: ["\u043A\u0443\u043F\u0440\u0430\u0434\u0437\u0435", "\u10D9\u10E3\u10DE\u10E0\u10D0\u10EB", "kupradze"], lat: 41.6985, lng: 44.8785, district: "\u0412\u0430\u0440\u043A\u0435\u0442\u0438\u043B\u0438 (Varketili)" },
  { keywords: ["\u0434\u0436\u0430\u0432\u0430\u0445\u0435\u0442\u0438", "\u10EF\u10D0\u10D5\u10D0\u10EE\u10D4\u10D7", "javakheti"], lat: 41.6965, lng: 44.8725, district: "\u0412\u0430\u0440\u043A\u0435\u0442\u0438\u043B\u0438 (Varketili)" }
];
var GENERIC_FALLBACK_CENTERS = /* @__PURE__ */ new Set([
  "41.7118,44.7571",
  "41.7289,44.7645",
  "41.7254,44.7568",
  "41.7345,44.8021",
  "41.7345,44.7985",
  "41.7126,44.8015",
  "41.7082,44.7834",
  "41.6892,44.8398",
  "41.6961,44.7938",
  "41.6789,44.8214",
  "41.6712,44.819",
  "41.6712,44.8190",
  "41.7856,44.7612",
  "41.7089,44.7321",
  "41.6899,44.7981",
  "41.6934,44.8142",
  "41.7456,44.7789",
  "41.7368,44.7825",
  "41.6865,44.8682",
  "41.6865,44.8582",
  "41.7923,44.8167",
  "41.6998,44.8765",
  "41.7589,44.7995"
]);
function hashString(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
function getDeterministicOffset(seed, radiusLat = 22e-4, radiusLng = 28e-4) {
  const h1 = hashString(seed + "_lat");
  const h2 = hashString(seed + "_lng");
  const n1 = h1 % 1e4 / 5e3 - 1;
  const n2 = h2 % 1e4 / 5e3 - 1;
  return {
    dLat: Number((n1 * radiusLat).toFixed(6)),
    dLng: Number((n2 * radiusLng).toFixed(6))
  };
}
function detectDistrictFromText(text) {
  const cleanedText = (text || "").replace(/ვაკე-საბურთალო|ваке-сабуртало|vake-saburtalo/gi, "").replace(/დიდუბე-ჩუღურეთი|дидубе-чугурети|didube-chugureti/gi, "").replace(/გლდანი-ნაძალადევი|глдани-надзаладеви|gldani-nadzaladevi/gi, "").replace(/ისანი-სამგორი|исани-самгори|isani-samgori/gi, "").replace(/ძველი თბილისი/gi, "").toLowerCase();
  for (const street of TBILISI_STREET_COORDS) {
    if (street.keywords.some((kw) => cleanedText.includes(kw))) {
      const offset = getDeterministicOffset(cleanedText, 14e-4, 18e-4);
      return {
        district: street.district,
        lat: Number((street.lat + offset.dLat).toFixed(6)),
        lng: Number((street.lng + offset.dLng).toFixed(6))
      };
    }
  }
  for (const item of TBILISI_DISTRICT_LIST) {
    if (item.aliases.some((alias) => cleanedText.includes(alias))) {
      const offset = getDeterministicOffset(cleanedText, 35e-4, 45e-4);
      return {
        district: item.name,
        lat: Number((item.lat + offset.dLat).toFixed(6)),
        lng: Number((item.lng + offset.dLng).toFixed(6))
      };
    }
  }
  const fallbackOffset = getDeterministicOffset(cleanedText || "tbilisi", 35e-4, 45e-4);
  return {
    district: "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E (Saburtalo)",
    lat: Number((41.7254 + fallbackOffset.dLat).toFixed(6)),
    lng: Number((44.7568 + fallbackOffset.dLng).toFixed(6))
  };
}
function getAccurateApartmentDistrict(apartment) {
  const city = getApartmentCity(apartment);
  if (city === "yerevan") {
    const combined = `${apartment.district || ""} ${apartment.title || ""} ${apartment.address || ""}`.toLowerCase();
    for (const item of YEREVAN_DISTRICT_LIST) {
      if (item.name === apartment.district || item.shortRu === apartment.district || item.aliases.some((alias) => combined.includes(alias))) {
        return item.name;
      }
    }
    return apartment.district || "\u041A\u0435\u043D\u0442\u0440\u043E\u043D / \u0426\u0435\u043D\u0442\u0440 (Kentron)";
  }
  if (city === "belgrade") {
    const combined = `${apartment.district || ""} ${apartment.title || ""} ${apartment.address || ""}`.toLowerCase();
    for (const item of BELGRADE_DISTRICT_LIST) {
      if (item.name === apartment.district || item.shortRu === apartment.district || item.aliases.some((alias) => combined.includes(alias))) {
        return item.name;
      }
    }
    return apartment.district || "\u0421\u0442\u0430\u0440\u0438 \u0413\u0440\u0430\u0434 / \u0414\u043E\u0440\u0447\u043E\u043B (Stari Grad / Dor\u0107ol)";
  }
  const titleAndAddress = `${apartment.title || ""} ${apartment.address || ""}`.replace(/ვაკე-საბურთალო|ваке-сабуртало|vake-saburtalo/gi, "").toLowerCase();
  for (const item of TBILISI_DISTRICT_LIST) {
    if (item.aliases.some((alias) => titleAndAddress.includes(alias))) {
      return item.name;
    }
  }
  for (const street of TBILISI_STREET_COORDS) {
    if (street.keywords.some((kw) => titleAndAddress.includes(kw))) {
      return street.district;
    }
  }
  if (apartment.district) {
    const matched = TBILISI_DISTRICT_LIST.find(
      (d) => d.name === apartment.district || d.shortRu === apartment.district || apartment.district?.includes(d.shortRu)
    );
    if (matched) return matched.name;
  }
  return "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E (Saburtalo)";
}
function getAccurateApartmentCoordinates(apartment) {
  const city = getApartmentCity(apartment);
  const accurateDistrict = getAccurateApartmentDistrict(apartment);
  const lat = Number(apartment.lat);
  const lng = Number(apartment.lng);
  const key = `${lat},${lng}`;
  const seed = `${apartment.id || ""}_${apartment.address || ""}_${apartment.title || ""}`;
  if (city === "yerevan") {
    const hasYerevanGps = !isNaN(lat) && !isNaN(lng) && lat > 40.05 && lat < 40.3 && lng > 44.35 && lng < 44.65;
    if (hasYerevanGps) return { lat, lng, district: accurateDistrict };
    const found = YEREVAN_DISTRICT_LIST.find((d) => d.name === accurateDistrict) || YEREVAN_DISTRICT_LIST[0];
    const offset2 = getDeterministicOffset(seed, 35e-4, 45e-4);
    return {
      lat: Number((found.lat + offset2.dLat).toFixed(6)),
      lng: Number((found.lng + offset2.dLng).toFixed(6)),
      district: accurateDistrict
    };
  }
  if (city === "belgrade") {
    const hasBelgradeGps = !isNaN(lat) && !isNaN(lng) && lat > 44.65 && lat < 44.95 && lng > 20.25 && lng < 20.65;
    if (hasBelgradeGps) return { lat, lng, district: accurateDistrict };
    const found = BELGRADE_DISTRICT_LIST.find((d) => d.name === accurateDistrict) || BELGRADE_DISTRICT_LIST[0];
    const offset2 = getDeterministicOffset(seed, 35e-4, 45e-4);
    return {
      lat: Number((found.lat + offset2.dLat).toFixed(6)),
      lng: Number((found.lng + offset2.dLng).toFixed(6)),
      district: accurateDistrict
    };
  }
  const hasRealGps = !isNaN(lat) && !isNaN(lng) && lat > 41.6 && lat < 41.88 && lng > 44.65 && lng < 44.98 && !GENERIC_FALLBACK_CENTERS.has(key);
  if (hasRealGps) {
    return { lat, lng, district: accurateDistrict };
  }
  const combined = `${apartment.address || ""} ${apartment.title || ""}`.toLowerCase();
  for (const street of TBILISI_STREET_COORDS) {
    if (street.keywords.some((kw) => combined.includes(kw))) {
      const offset2 = getDeterministicOffset(seed, 14e-4, 18e-4);
      return {
        lat: Number((street.lat + offset2.dLat).toFixed(6)),
        lng: Number((street.lng + offset2.dLng).toFixed(6)),
        district: accurateDistrict
      };
    }
  }
  const distCoords = DISTRICT_COORDS[accurateDistrict] || { lat: 41.7254, lng: 44.7568 };
  const offset = getDeterministicOffset(seed, 42e-4, 52e-4);
  return {
    lat: Number((distCoords.lat + offset.dLat).toFixed(6)),
    lng: Number((distCoords.lng + offset.dLng).toFixed(6)),
    district: accurateDistrict
  };
}

// src/utils/myhomeParser.ts
function getMyHomeStatementId(idOrUrl) {
  if (!idOrUrl) return null;
  const match = String(idOrUrl).match(/(?:^myhome-|statements?\/|-)(\d{6,10})(?:\/|\?|$)/i) || String(idOrUrl).match(/^(\d{6,10})$/);
  return match ? match[1] : null;
}
function slugifyMyHomeTitle(title) {
  if (!title) return "sdaetsia-kvartira-v-tbilisi";
  const cyrToLat = {
    \u0430: "a",
    \u0431: "b",
    \u0432: "v",
    \u0433: "g",
    \u0434: "d",
    \u0435: "e",
    \u0451: "e",
    \u0436: "zh",
    \u0437: "z",
    \u0438: "i",
    \u0439: "i",
    \u043A: "k",
    \u043B: "l",
    \u043C: "m",
    \u043D: "n",
    \u043E: "o",
    \u043F: "p",
    \u0440: "r",
    \u0441: "s",
    \u0442: "t",
    \u0443: "u",
    \u0444: "f",
    \u0445: "kh",
    \u0446: "ts",
    \u0447: "ch",
    \u0448: "sh",
    \u0449: "shch",
    \u044A: "",
    \u044B: "y",
    \u044C: "",
    \u044D: "e",
    \u044E: "iu",
    \u044F: "ia"
  };
  const lower = title.toLowerCase();
  let out = "";
  for (const ch of lower) {
    if (cyrToLat[ch] !== void 0) {
      out += cyrToLat[ch];
    } else if (/[a-z0-9]/.test(ch)) {
      out += ch;
    } else {
      out += "-";
    }
  }
  const cleaned = out.replace(/-+/g, "-").replace(/^-|-$/g, "");
  return cleaned || "sdaetsia-kvartira-v-tbilisi";
}
function getMyHomeOriginalUrl(apt) {
  if (!apt) return null;
  if (apt.sourceUrl && /^https?:\/\//i.test(apt.sourceUrl)) {
    return apt.sourceUrl;
  }
  const statementId = getMyHomeStatementId(apt.id);
  if (!statementId) return null;
  const slug = slugifyMyHomeTitle(apt.title);
  const fullSlug = slug.endsWith(`-${statementId}`) ? slug : `${slug}-${statementId}`;
  return `https://www.myhome.ge/ru/nedvizhimost/${fullSlug}/`;
}
function isStatementObject(item) {
  if (!item || typeof item !== "object" || Array.isArray(item)) return false;
  return Boolean(
    (item.id || item.statement_id || item.product_id) && (item.price || item.total_price || item.price_total || item.price_usd || item.area || item.images || item.photos || item.dynamic_title)
  );
}
function findStatementObject(obj) {
  if (!obj || typeof obj !== "object") return null;
  if (obj.statement && isStatementObject(obj.statement)) {
    return obj.statement;
  }
  if (isStatementObject(obj)) {
    return obj;
  }
  const queries = obj.props?.pageProps?.dehydratedState?.queries || obj.pageProps?.dehydratedState?.queries || obj.dehydratedState?.queries;
  if (Array.isArray(queries)) {
    for (const q of queries) {
      const stmt = q?.state?.data?.data?.statement || q?.state?.data?.statement || q?.state?.data?.result?.data?.statement;
      if (isStatementObject(stmt)) {
        return stmt;
      }
    }
  }
  if (isStatementObject(obj.props?.pageProps?.statement)) return obj.props.pageProps.statement;
  if (isStatementObject(obj.props?.pageProps?.data?.statement)) return obj.props.pageProps.data.statement;
  if (isStatementObject(obj.pageProps?.statement)) return obj.pageProps.statement;
  if (isStatementObject(obj.data?.statement)) return obj.data.statement;
  if (isStatementObject(obj.result?.data?.statement)) return obj.result.data.statement;
  for (const key of Object.keys(obj)) {
    const val = obj[key];
    if (val && typeof val === "object") {
      if (isStatementObject(val.statement)) return val.statement;
      if (isStatementObject(val)) return val;
    }
  }
  return null;
}
function findAllStatements(obj) {
  if (!obj) return [];
  const results = [];
  const seenIds = /* @__PURE__ */ new Set();
  const addIfUnique = (item) => {
    if (!item) return;
    const stmt = item.statement || item;
    if (isStatementObject(stmt)) {
      const id = String(stmt.id || stmt.statement_id || stmt.product_id);
      if (id && !seenIds.has(id)) {
        seenIds.add(id);
        results.push(stmt);
      }
    }
  };
  if (Array.isArray(obj)) {
    for (const item of obj) {
      addIfUnique(item);
    }
    if (results.length > 0) return results;
  }
  const queries = obj.props?.pageProps?.dehydratedState?.queries || obj.pageProps?.dehydratedState?.queries || obj.dehydratedState?.queries;
  if (Array.isArray(queries)) {
    for (const q of queries) {
      const data = q?.state?.data;
      if (!data) continue;
      const arraysToCheck = [
        data?.data?.pr_statement_list,
        data?.data?.statements,
        data?.data?.items,
        data?.data?.result?.data,
        data?.result?.data,
        data?.pr_statement_list,
        data?.statements,
        data?.items,
        Array.isArray(data?.data) ? data.data : null,
        Array.isArray(data) ? data : null
      ];
      for (const arr of arraysToCheck) {
        if (Array.isArray(arr) && arr.length > 0) {
          for (const item of arr) {
            addIfUnique(item);
          }
        }
      }
      const single2 = data?.data?.statement || data?.statement || data?.result?.data?.statement;
      addIfUnique(single2);
    }
    if (results.length > 0) return results;
  }
  const pageProps = obj.props?.pageProps || obj.pageProps || obj;
  const pageArrays = [
    pageProps.data?.pr_statement_list,
    pageProps.data?.statements,
    pageProps.data?.items,
    pageProps.statements,
    pageProps.pr_statement_list,
    Array.isArray(pageProps.data) ? pageProps.data : null
  ];
  for (const arr of pageArrays) {
    if (Array.isArray(arr) && arr.length > 0) {
      for (const item of arr) {
        addIfUnique(item);
      }
    }
  }
  if (results.length > 0) return results;
  const single = findStatementObject(obj);
  if (single) {
    results.push(single);
  }
  return results;
}
function convertRawStatementToApartment(stmt, agentPhone = DEFAULT_AGENT_PHONE) {
  const rawImages = stmt.images || stmt.photos || stmt.gallery || [];
  const images = [];
  for (const item of rawImages) {
    let url;
    if (typeof item === "string") {
      url = item;
    } else if (item && typeof item === "object") {
      url = item.large || item.url || item.thumb || item.path || item.src;
    }
    if (url && typeof url === "string") {
      let cleanUrl = url.startsWith("//") ? `https:${url}` : url;
      cleanUrl = cleanUrl.replace(/static-statements\.tnet\.ge/g, "static-api-statements.tnet.ge");
      images.push(cleanUrl);
    }
  }
  if (images.length === 0 && stmt.photo) {
    const photoUrl = String(stmt.photo).replace(/static-statements\.tnet\.ge/g, "static-api-statements.tnet.ge");
    images.push(photoUrl);
  }
  const statementId = String(stmt.id || stmt.statement_id || stmt.product_id || Date.now());
  const urbanName = stmt.urban_name || stmt.urban || "";
  const rawDistrictName = stmt.district_name || stmt.district || stmt.region || stmt.city_district || "";
  const districtName = urbanName || rawDistrictName.replace(/ვაკე-საბურთალო|დიდუბე-ჩუღურეთი|გლდანი-ნაძალადევი|ისანი-სამგორი/g, "") || stmt.city_name || "";
  const streetName = stmt.address || stmt.street_name || stmt.street || "";
  let priceUsd = 0;
  let priceGel = 0;
  if (stmt.price && typeof stmt.price === "object") {
    if (stmt.price["2"]?.price_total) {
      priceUsd = Number(stmt.price["2"].price_total);
    }
    if (stmt.price["1"]?.price_total) {
      priceGel = Number(stmt.price["1"].price_total);
    }
  }
  if (!priceUsd) {
    if (stmt.currency_id === 2 || stmt.currency === "USD") {
      priceUsd = Number(stmt.total_price || stmt.price_total || stmt.price_usd || stmt.price) || 0;
    } else {
      priceUsd = Number(stmt.price_usd || stmt.price_total_usd || stmt.total_price) || 800;
    }
  }
  if (!priceGel) {
    priceGel = Number(stmt.price_gel || stmt.price_total_gel) || Math.round(priceUsd * 2.72);
  }
  const rooms = Number(stmt.room || stmt.room_type_id || stmt.rooms || stmt.room_count) || 2;
  const bedrooms = Number(stmt.bedroom || stmt.bedroom_type_id || stmt.bedrooms || stmt.bedroom_count) || Math.max(rooms - 1, 1);
  const areaSqm = Number(stmt.area || stmt.total_area || stmt.areaSqm) || 55;
  const floor = Number(stmt.floor) || 3;
  const totalFloors = Number(stmt.total_floors || stmt.floors || stmt.totalFloors) || 8;
  const amenities = ["\u041A\u043E\u043D\u0434\u0438\u0446\u0438\u043E\u043D\u0435\u0440", "\u0421\u0442\u0438\u0440\u0430\u043B\u044C\u043D\u0430\u044F \u043C\u0430\u0448\u0438\u043D\u0430", "Wi-Fi", "\u0426\u0435\u043D\u0442\u0440\u0430\u043B\u044C\u043D\u043E\u0435 \u043E\u0442\u043E\u043F\u043B\u0435\u043D\u0438\u0435"];
  if (stmt.balconies || stmt.balcony || stmt.has_balcony || stmt.hasBalcony) amenities.push("\u0411\u0430\u043B\u043A\u043E\u043D");
  if (stmt.dishwasher || stmt.has_dishwasher) amenities.push("\u041F\u043E\u0441\u0443\u0434\u043E\u043C\u043E\u0435\u0447\u043D\u0430\u044F \u043C\u0430\u0448\u0438\u043D\u0430");
  if (stmt.elevator || stmt.has_elevator) amenities.push("\u041B\u0438\u0444\u0442");
  if (stmt.parking_type_id || stmt.parking || stmt.has_parking) amenities.push("\u041F\u0430\u0440\u043A\u0438\u043D\u0433");
  if (stmt.swimming_pool_type) amenities.push("\u0411\u0430\u0441\u0441\u0435\u0439\u043D");
  if (stmt.pets_allowed || stmt.petsAllowed) amenities.push("\u041C\u043E\u0436\u043D\u043E \u0441 \u043F\u0438\u0442\u043E\u043C\u0446\u0430\u043C\u0438");
  const dynamicTitle = stmt.dynamic_title || stmt.user_title || stmt.seo?.h1 || stmt.title || `\u0421\u0434\u0430\u0435\u0442\u0441\u044F ${rooms}-\u043A\u043E\u043C\u043D\u0430\u0442\u043D\u0430\u044F \u043A\u0432\u0430\u0440\u0442\u0438\u0440\u0430, ${streetName || districtName || "\u0422\u0431\u0438\u043B\u0438\u0441\u0438"}`;
  const address = streetName ? streetName : districtName ? `\u0422\u0431\u0438\u043B\u0438\u0441\u0438, ${districtName}` : "\u0422\u0431\u0438\u043B\u0438\u0441\u0438";
  const detectedGeo = detectDistrictFromText(`${urbanName} ${dynamicTitle} ${address} ${districtName}`);
  let district = detectedGeo.district;
  district = getAccurateApartmentDistrict({ district, address, title: dynamicTitle });
  const rawLat = stmt.lat ? Number(stmt.lat) : Array.isArray(stmt.point?.coordinates) ? Number(stmt.point.coordinates[1]) : void 0;
  const rawLng = stmt.lng ? Number(stmt.lng) : Array.isArray(stmt.point?.coordinates) ? Number(stmt.point.coordinates[0]) : void 0;
  const resolvedCoords = getAccurateApartmentCoordinates({
    id: `myhome-${statementId}`,
    district,
    address,
    title: dynamicTitle,
    lat: rawLat,
    lng: rawLng
  });
  const hasPets = Boolean(stmt.pets_allowed ?? stmt.petsAllowed ?? false);
  const petPolicy = hasPets ? "allowed" : "no_pets";
  const description = stmt.comment || stmt.description || stmt.seo?.meta_description || "\u041A\u0432\u0430\u0440\u0442\u0438\u0440\u0430 \u0438\u043C\u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0430 \u0441 \u043F\u043E\u0440\u0442\u0430\u043B\u0430 MyHome.ge.";
  const rawRuSlug = stmt.href_lang?.ru || stmt.dynamic_slug || "";
  const cleanSlug = rawRuSlug ? rawRuSlug.endsWith(`-${statementId}`) ? rawRuSlug : `${rawRuSlug}-${statementId}` : `${slugifyMyHomeTitle(dynamicTitle)}-${statementId}`;
  const sourceUrl = stmt.sourceUrl && /^https?:\/\//i.test(stmt.sourceUrl) ? stmt.sourceUrl : `https://www.myhome.ge/ru/nedvizhimost/${cleanSlug}/`;
  const apartment = {
    id: `myhome-${statementId}`,
    title: stripPhoneAndContactMentions(dynamicTitle.trim()),
    address: address.trim(),
    district: resolvedCoords.district,
    priceUsd,
    priceGel,
    rooms,
    bedrooms,
    areaSqm,
    floor,
    totalFloors,
    furniture: "full",
    petPolicy,
    minPeriod: "year_plus",
    maxResidents: Math.max(rooms * 2, 2),
    images: images.length > 0 ? images : [
      "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=1200&q=80"
    ],
    description: stripPhoneAndContactMentions(description.trim()),
    amenities: Array.from(new Set(amenities)),
    lat: resolvedCoords.lat,
    lng: resolvedCoords.lng,
    landlord: {
      id: `landlord-${statementId}`,
      name: stmt.owner_name || stmt.client_name || stmt.author || "\u0421\u043E\u0431\u0441\u0442\u0432\u0435\u043D\u043D\u0438\u043A (Rentch)",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80",
      phone: agentPhone || DEFAULT_AGENT_PHONE,
      verified: true,
      responseTime: "\u0434\u043E 15 \u043C\u0438\u043D\u0443\u0442",
      rating: 4.9
    },
    metro: stmt.metro_station_id ? `\u041C\u0435\u0442\u0440\u043E (ID ${stmt.metro_station_id})` : void 0,
    isNew: true,
    sourceUrl
  };
  return apartment;
}
function parseMyHomeBatch(rawText, agentPhone = DEFAULT_AGENT_PHONE) {
  let cleaned = (rawText || "").trim();
  const scriptMatch = cleaned.match(/<script[^>]*id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/i);
  if (scriptMatch && scriptMatch[1]) {
    cleaned = scriptMatch[1].trim();
  }
  if (cleaned.startsWith("copy(") && cleaned.endsWith(")")) {
    cleaned = cleaned.slice(5, -1).trim();
  }
  let parsed;
  try {
    parsed = JSON.parse(cleaned);
  } catch (err) {
    const startIdx = cleaned.indexOf("{");
    const endIdx = cleaned.lastIndexOf("}");
    if (startIdx !== -1 && endIdx !== -1 && endIdx > startIdx) {
      try {
        parsed = JSON.parse(cleaned.slice(startIdx, endIdx + 1));
      } catch (nestedErr) {
        throw new Error("\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u0440\u043E\u0447\u0438\u0442\u0430\u0442\u044C JSON. \u0423\u0431\u0435\u0434\u0438\u0442\u0435\u0441\u044C, \u0447\u0442\u043E \u0441\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u043B\u0438 \u0442\u0435\u043A\u0441\u0442 \u0446\u0435\u043B\u0438\u043A\u043E\u043C \u0441\u043E \u0432\u0441\u0435\u043C\u0438 \u0444\u0438\u0433\u0443\u0440\u043D\u044B\u043C\u0438 \u0441\u043A\u043E\u0431\u043A\u0430\u043C\u0438 { ... }");
      }
    } else {
      throw new Error("\u0412 \u0442\u0435\u043A\u0441\u0442\u0435 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D JSON \u043E\u0431\u044A\u0435\u043A\u0442. \u041F\u043E\u0436\u0430\u043B\u0443\u0439\u0441\u0442\u0430, \u0441\u043A\u043E\u043F\u0438\u0440\u0443\u0439\u0442\u0435 \u0442\u0435\u043A\u0441\u0442 \u0441\u043E \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B \u0438\u043B\u0438 \u0438\u0437 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430.");
    }
  }
  const statements = findAllStatements(parsed);
  if (!statements || statements.length === 0) {
    throw new Error("\u0412 \u043F\u0435\u0440\u0435\u0434\u0430\u043D\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u044B \u043E\u0431\u044A\u0435\u043A\u0442\u044B \u043E\u0431\u044A\u044F\u0432\u043B\u0435\u043D\u0438\u0439 MyHome. \u0423\u0431\u0435\u0434\u0438\u0442\u0435\u0441\u044C, \u0447\u0442\u043E \u0441\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u043B\u0438 \u0434\u0430\u043D\u043D\u044B\u0435 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B \u043E\u0431\u044A\u044F\u0432\u043B\u0435\u043D\u0438\u044F \u0438\u043B\u0438 \u043A\u0430\u0442\u0430\u043B\u043E\u0433\u0430.");
  }
  return statements.map((stmt) => convertRawStatementToApartment(stmt, agentPhone));
}

// src/utils/haloOglasiParser.ts
var DEFAULT_HALO_OGLASI_URL = "https://www.halooglasi.com/nekretnine/izdavanje-stanova/beograd?oglasivac_nekretnine_id_l=387237";
var HALO_IMAGE_ROOT = "https://img.halooglasi.com";
var SERBIAN_AMENITIES_MAP = {
  "Klima": "\u041A\u043E\u043D\u0434\u0438\u0446\u0438\u043E\u043D\u0435\u0440",
  "Lift": "\u041B\u0438\u0444\u0442",
  "Terasa": "\u0422\u0435\u0440\u0440\u0430\u0441\u0430",
  "Lo\u0111a": "\u041B\u043E\u0434\u0436\u0438\u044F",
  "Francuski balkon": "\u0424\u0440\u0430\u043D\u0446\u0443\u0437\u0441\u043A\u0438\u0439 \u0431\u0430\u043B\u043A\u043E\u043D",
  "Parking": "\u041F\u0430\u0440\u043A\u0438\u043D\u0433",
  "Gara\u017Ea": "\u0413\u0430\u0440\u0430\u0436",
  "Internet": "Wi-Fi / \u0418\u043D\u0442\u0435\u0440\u043D\u0435\u0442",
  "KATV": "\u041A\u0430\u0431\u0435\u043B\u044C\u043D\u043E\u0435 \u0422\u0412",
  "Interfon": "\u0414\u043E\u043C\u043E\u0444\u043E\u043D",
  "Video nadzor": "\u0412\u0438\u0434\u0435\u043E\u043D\u0430\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u0435",
  "Obezbe\u0111enje": "\u041E\u0445\u0440\u0430\u043D\u0430",
  "Recepcija": "\u0420\u0435\u0441\u0435\u043F\u0448\u043D",
  "Topla voda": "\u0413\u043E\u0440\u044F\u0447\u0430\u044F \u0432\u043E\u0434\u0430",
  "CG": "\u0426\u0435\u043D\u0442\u0440\u0430\u043B\u044C\u043D\u043E\u0435 \u043E\u0442\u043E\u043F\u043B\u0435\u043D\u0438\u0435",
  "EG": "\u0418\u043D\u0434\u0438\u0432\u0438\u0434\u0443\u0430\u043B\u044C\u043D\u043E\u0435 \u043E\u0442\u043E\u043F\u043B\u0435\u043D\u0438\u0435",
  "TA": "\u041E\u0442\u043E\u043F\u043B\u0435\u043D\u0438\u0435 (\u0422\u0410 \u043F\u0435\u0447\u044C)",
  "Gas": "\u0413\u0430\u0437\u043E\u0432\u043E\u0435 \u043E\u0442\u043E\u043F\u043B\u0435\u043D\u0438\u0435",
  "Podno grejanje": "\u0422\u0451\u043F\u043B\u044B\u0439 \u043F\u043E\u043B",
  "Kamin": "\u041A\u0430\u043C\u0438\u043D",
  "Telefon": "\u0422\u0435\u043B\u0435\u0444\u043E\u043D\u043D\u0430\u044F \u043B\u0438\u043D\u0438\u044F",
  "Podrum": "\u041A\u043B\u0430\u0434\u043E\u0432\u0430\u044F / \u041F\u043E\u0434\u0432\u0430\u043B",
  "Ostava": "\u0413\u0430\u0440\u0434\u0435\u0440\u043E\u0431\u043D\u0430\u044F / \u041A\u043B\u0430\u0434\u043E\u0432\u0430\u044F",
  "Sa ba\u0161tom": "\u0421\u043E\u0431\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0439 \u0434\u0432\u043E\u0440\u0438\u043A",
  "Bazen": "\u0411\u0430\u0441\u0441\u0435\u0439\u043D",
  "Odmah useljiv": "\u0413\u043E\u0442\u043E\u0432\u0430 \u043A \u0437\u0430\u0435\u0437\u0434\u0443",
  "Depozit": "\u0414\u0435\u043F\u043E\u0437\u0438\u0442",
  "Nije poslednji sprat": "\u041D\u0435 \u043F\u043E\u0441\u043B\u0435\u0434\u043D\u0438\u0439 \u044D\u0442\u0430\u0436",
  "Za studente": "\u041F\u043E\u0434\u0445\u043E\u0434\u0438\u0442 \u0441\u0442\u0443\u0434\u0435\u043D\u0442\u0430\u043C",
  "Za \u043F\u0443\u0448\u0430\u0447\u0435": "\u041C\u043E\u0436\u043D\u043E \u043A\u0443\u0440\u0438\u0442\u044C",
  "Za nepu\u0161a\u010De": "\u0414\u043B\u044F \u043D\u0435\u043A\u0443\u0440\u044F\u0449\u0438\u0445",
  "Ku\u0107ni ljubimci": "\u041C\u043E\u0436\u043D\u043E \u0441 \u0436\u0438\u0432\u043E\u0442\u043D\u044B\u043C\u0438",
  "Pet friendly": "\u041C\u043E\u0436\u043D\u043E \u0441 \u0436\u0438\u0432\u043E\u0442\u043D\u044B\u043C\u0438",
  "Novogradnja": "\u041D\u043E\u0432\u043E\u0441\u0442\u0440\u043E\u0439\u043A\u0430",
  "Lux": "\u041B\u044E\u043A\u0441-\u0440\u0435\u043C\u043E\u043D\u0442",
  "Renovirano": "\u0421\u0432\u0435\u0436\u0438\u0439 \u0440\u0435\u043C\u043E\u043D\u0442"
};
var BELGRADE_LOC_RU_MAP = {
  "Beograd": "\u0411\u0435\u043B\u0433\u0440\u0430\u0434",
  "Op\u0161tina Stari grad": "\u0421\u0442\u0430\u0440\u0438 \u0413\u0440\u0430\u0434",
  "Op\u0161tina Vra\u010Dar": "\u0412\u0440\u0430\u0447\u0430\u0440",
  "Op\u0161tina Novi Beograd": "\u041D\u043E\u0432\u0438 \u0411\u0435\u043E\u0433\u0440\u0430\u0434",
  "Op\u0161tina Savski venac": "\u0421\u0430\u0432\u0441\u043A\u0438 \u0412\u0435\u043D\u0430\u0446",
  "Op\u0161tina Zemun": "\u0417\u0435\u043C\u0443\u043D",
  "Op\u0161tina Palilula": "\u041F\u0430\u043B\u0438\u043B\u0443\u043B\u0430",
  "Op\u0161tina Zvezdara": "\u0417\u0432\u0435\u0437\u0434\u0430\u0440\u0430",
  "Op\u0161tina Vo\u017Edovac": "\u0412\u043E\u0436\u0434\u043E\u0432\u0430\u0446",
  "Op\u0161tina \u010Cukarica": "\u0427\u0443\u043A\u0430\u0440\u0438\u0446\u0430",
  "Op\u0161tina Rakovica": "\u0420\u0430\u043A\u043E\u0432\u0438\u0446\u0430",
  "Dor\u0107ol": "\u0414\u043E\u0440\u0447\u043E\u043B",
  "Donji Dor\u0107ol": "\u041D\u0438\u0436\u043D\u0438\u0439 \u0414\u043E\u0440\u0447\u043E\u043B",
  "Gornji Dor\u0107ol": "\u0412\u0435\u0440\u0445\u043D\u0438\u0439 \u0414\u043E\u0440\u0447\u043E\u043B",
  "Skadarlija": "\u0421\u043A\u0430\u0434\u0430\u0440\u043B\u0438\u044F",
  "Knez Mihailova": "\u041A\u043D\u0435\u0437 \u041C\u0438\u0445\u0430\u0438\u043B\u043E\u0432\u0430",
  "Trg Republike": "\u041F\u043B\u043E\u0449\u0430\u0434\u044C \u0420\u0435\u0441\u043F\u0443\u0431\u043B\u0438\u043A\u0438",
  "Zeleni venac": "\u0417\u0435\u043B\u0435\u043D\u0438 \u0412\u0435\u043D\u0430\u0446",
  "Terazije": "\u0422\u0435\u0440\u0430\u0437\u0438\u0435",
  "Hram svetog Save": "\u0425\u0440\u0430\u043C \u0421\u0432\u044F\u0442\u043E\u0433\u043E \u0421\u0430\u0432\u0432\u044B",
  "Slavija": "\u0421\u043B\u0430\u0432\u0438\u044F",
  "Kaleni\u0107 pijaca": "\u041A\u0430\u043B\u0435\u043D\u0438\u0447",
  "Crveni krst": "\u0426\u0440\u0432\u0435\u043D\u0438 \u041A\u0440\u0441\u0442",
  "\u010Cubura": "\u0427\u0443\u0431\u0443\u0440\u0430",
  "Neimar": "\u041D\u0435\u0438\u043C\u0430\u0440",
  "Cvetni trg": "\u0426\u0432\u0435\u0442\u043D\u0438 \u0422\u0440\u0433",
  "Ju\u017Eni bulevar": "\u042E\u0436\u043D\u044B\u0439 \u0431\u0443\u043B\u044C\u0432\u0430\u0440",
  "Beograd na vodi": "Belgrade Waterfront",
  "Dedinje": "\u0414\u0435\u0434\u0438\u043D\u044C\u0435",
  "Senjak": "\u0421\u0435\u043D\u044F\u043A",
  "Sarajevska": "\u0421\u0430\u0440\u0430\u0435\u0432\u0441\u043A\u0430",
  "Klini\u010Dki centar": "\u041A\u043B\u0438\u043D\u0438\u0447\u043A\u0438 \u0426\u0435\u043D\u0442\u0430\u0440",
  "Be\u017Eanijska kosa": "\u0411\u0435\u0436\u0430\u043D\u0438\u0439\u0441\u043A\u0430 \u041A\u043E\u0441\u0430",
  "Fontana": "\u0424\u043E\u043D\u0442\u0430\u043D\u0430",
  "Arena": "\u0411\u0435\u043B\u0433\u0440\u0430\u0434\u0441\u043A\u0430\u044F \u0410\u0440\u0435\u043D\u0430",
  "Belville": "\u0411\u0435\u043B\u0432\u0438\u043B (Belville)",
  "A Blok": "\u0410 \u0411\u043B\u043E\u043A (A Blok)",
  "West 65": "West 65",
  "Airport City": "Airport City",
  "Savada": "\u0421\u0430\u0432\u0430\u0434\u0430",
  "Paviljoni": "\u041F\u0430\u0432\u0438\u043B\u044C\u043E\u043D\u0438",
  "To\u0161in bunar": "\u0422\u043E\u0448\u0438\u043D \u0411\u0443\u043D\u0430\u0440",
  "Zemun kej": "\u0417\u0435\u043C\u0443\u043D\u0441\u043A\u0438\u0439 \u043A\u0435\u0439",
  "Gardo\u0161": "\u0413\u0430\u0440\u0434\u043E\u0448",
  "Altina": "\u0410\u043B\u0442\u0438\u043D\u0430",
  "Karaburma": "\u041A\u0430\u0440\u0430\u0431\u0443\u0440\u043C\u0430",
  "Ta\u0161majdan": "\u0422\u0430\u0448\u043C\u0430\u0439\u0434\u0430\u043D",
  "Bogoslovija": "\u0411\u043E\u0433\u043E\u0441\u043B\u043E\u0432\u0438\u044F",
  "Bor\u010Da": "\u0411\u043E\u0440\u0447\u0430",
  "Krnja\u010Da": "\u041A\u0440\u043D\u044F\u0447\u0430",
  "Vi\u0161nji\u010Dka banja": "\u0412\u0438\u0448\u043D\u0438\u0447\u043A\u0430 \u0411\u0430\u043D\u044F",
  "Vukov spomenik": "\u0412\u0443\u043A\u043E\u0432 \u0421\u043F\u043E\u043C\u0435\u043D\u0438\u043A",
  "Bulevar kralja Aleksandra": "\u0411\u0443\u043B\u044C\u0432\u0430\u0440 \u041A\u043E\u0440\u043E\u043B\u044F \u0410\u043B\u0435\u043A\u0441\u0430\u043D\u0434\u0440\u0430",
  "Mirijevo": "\u041C\u0438\u0440\u0438\u0435\u0432\u043E",
  "Lion": "\u041B\u0438\u043E\u043D",
  "\u0110eram": "\u0414\u0436\u0435\u0440\u0430\u043C",
  "Konjarnik": "\u041A\u043E\u043D\u044F\u0440\u043D\u0438\u043A",
  "Cvetkova pijaca": "\u0426\u0432\u0435\u0442\u043A\u043E\u0432\u0430 \u041F\u0438\u044F\u0446\u0430",
  "Olimp": "\u041E\u043B\u0438\u043C\u043F",
  "Autokomanda": "\u0410\u0443\u0442\u043E\u043A\u043E\u043C\u0430\u043D\u0434\u0430",
  "Banjica": "\u0411\u0430\u043D\u044C\u0438\u0446\u0430",
  "Medakovi\u0107": "\u041C\u0435\u0434\u0430\u043A\u043E\u0432\u0438\u0447",
  "Bra\u0107e Jerkovi\u0107": "\u0411\u0440\u0430\u0447\u0435 \u0415\u0440\u043A\u043E\u0432\u0438\u0447",
  "Vojvode Stepe": "\u0412\u043E\u0439\u0432\u043E\u0434\u0435 \u0421\u0442\u0435\u043F\u0435",
  "Stepa Stepanovi\u0107": "\u0421\u0442\u0435\u043F\u0430 \u0421\u0442\u0435\u043F\u0430\u043D\u043E\u0432\u0438\u0447",
  "Du\u0161anovac": "\u0414\u0443\u0448\u0430\u043D\u043E\u0432\u0430\u0446",
  "\u0160umice": "\u0428\u0443\u043C\u0438\u0446\u0435",
  "Banovo brdo": "\u0411\u0430\u043D\u043E\u0432\u043E \u0411\u0440\u0434\u043E",
  "Ada Ciganlija": "\u0410\u0434\u0430 \u0426\u0438\u0433\u0430\u043D\u043B\u0438\u044F",
  "\u017Darkovo": "\u0416\u0430\u0440\u043A\u043E\u0432\u043E",
  "Cerak": "\u0426\u0435\u0440\u0430\u043A",
  "Vidikovac": "\u0412\u0438\u0434\u0438\u043A\u043E\u0432\u0430\u0446",
  "Ko\u0161utnjak": "\u041A\u043E\u0448\u0443\u0442\u043D\u044F\u043A",
  "Miljakovac": "\u041C\u0438\u043B\u044F\u043A\u043E\u0432\u0430\u0446"
};
var SERBIAN_PHRASE_DICT = [
  [/\bizdajem\b/gi, "\u0421\u0434\u0430\u0451\u0442\u0441\u044F"],
  [/\bizdaje se\b/gi, "\u0421\u0434\u0430\u0451\u0442\u0441\u044F"],
  [/\bza izdavanje\b/gi, "\u0432 \u0430\u0440\u0435\u043D\u0434\u0443"],
  [/\bizdavanje\b/gi, "\u0430\u0440\u0435\u043D\u0434\u0430"],
  [/\bstan u\b/gi, "\u043A\u0432\u0430\u0440\u0442\u0438\u0440\u0430 \u0432"],
  [/\bstan na\b/gi, "\u043A\u0432\u0430\u0440\u0442\u0438\u0440\u0430 \u0432 \u0440\u0430\u0439\u043E\u043D\u0435"],
  [/\bstan kod\b/gi, "\u043A\u0432\u0430\u0440\u0442\u0438\u0440\u0430 \u0443"],
  [/\bstan\b/gi, "\u043A\u0432\u0430\u0440\u0442\u0438\u0440\u0430"],
  [/\bgarsonjera\b/gi, "\u0441\u0442\u0443\u0434\u0438\u044F (\u0433\u0430\u0440\u0441\u043E\u043D\u044C\u0435\u0440\u0430)"],
  [/\bjednosoban\b/gi, "1-\u043A\u043E\u043C\u043D\u0430\u0442\u043D\u0430\u044F"],
  [/\bjednoiposoban\b/gi, "1.5-\u043A\u043E\u043C\u043D\u0430\u0442\u043D\u0430\u044F"],
  [/\bdvosoban\b/gi, "2-\u043A\u043E\u043C\u043D\u0430\u0442\u043D\u0430\u044F"],
  [/\bdvoiposoban\b/gi, "2.5-\u043A\u043E\u043C\u043D\u0430\u0442\u043D\u0430\u044F"],
  [/\btrosoban\b/gi, "3-\u043A\u043E\u043C\u043D\u0430\u0442\u043D\u0430\u044F"],
  [/\btroiposoban\b/gi, "3.5-\u043A\u043E\u043C\u043D\u0430\u0442\u043D\u0430\u044F"],
  [/\bčetvorosoban\b/gi, "4-\u043A\u043E\u043C\u043D\u0430\u0442\u043D\u0430\u044F"],
  [/\bcetvorosoban\b/gi, "4-\u043A\u043E\u043C\u043D\u0430\u0442\u043D\u0430\u044F"],
  [/\bkompletno namešten\b/gi, "\u043F\u043E\u043B\u043D\u043E\u0441\u0442\u044C\u044E \u043C\u0435\u0431\u043B\u0438\u0440\u043E\u0432\u0430\u043D\u0430"],
  [/\bpotpuno namešten\b/gi, "\u043F\u043E\u043B\u043D\u043E\u0441\u0442\u044C\u044E \u043C\u0435\u0431\u043B\u0438\u0440\u043E\u0432\u0430\u043D\u0430"],
  [/\bnamešten\b/gi, "\u0441 \u043C\u0435\u0431\u0435\u043B\u044C\u044E"],
  [/\bnameštena\b/gi, "\u0441 \u043C\u0435\u0431\u0435\u043B\u044C\u044E"],
  [/\bnamešteno\b/gi, "\u0441 \u043C\u0435\u0431\u0435\u043B\u044C\u044E"],
  [/\bpolunamešten\b/gi, "\u0447\u0430\u0441\u0442\u0438\u0447\u043D\u043E \u043C\u0435\u0431\u043B\u0438\u0440\u043E\u0432\u0430\u043D\u0430"],
  [/\bprazan\b/gi, "\u0431\u0435\u0437 \u043C\u0435\u0431\u0435\u043B\u0438"],
  [/\bnovogradnja\b/gi, "\u043D\u043E\u0432\u043E\u0441\u0442\u0440\u043E\u0439\u043A\u0430"],
  [/\bu novogradnji\b/gi, "\u0432 \u043D\u043E\u0432\u043E\u0441\u0442\u0440\u043E\u0439\u043A\u0435"],
  [/\brenovirano\b/gi, "\u043F\u043E\u0441\u043B\u0435 \u0440\u0435\u043C\u043E\u043D\u0442\u0430"],
  [/\brenoviran\b/gi, "\u0441 \u0440\u0435\u043C\u043E\u043D\u0442\u043E\u043C"],
  [/\bodmah useljiv\b/gi, "\u0433\u043E\u0442\u043E\u0432\u0430 \u043A \u0437\u0430\u0441\u0435\u043B\u0435\u043D\u0438\u044E"],
  [/\buseljiv\b/gi, "\u0433\u043E\u0442\u043E\u0432\u0430 \u043A \u0437\u0430\u0435\u0437\u0434\u0443"],
  [/\bdnevni boravak\b/gi, "\u0433\u043E\u0441\u0442\u0438\u043D\u0430\u044F"],
  [/\bdnevna soba\b/gi, "\u0433\u043E\u0441\u0442\u0438\u043D\u0430\u044F"],
  [/\bspavaća soba\b/gi, "\u0441\u043F\u0430\u043B\u044C\u043D\u044F"],
  [/\bspavaca soba\b/gi, "\u0441\u043F\u0430\u043B\u044C\u043D\u044F"],
  [/\bspavaće sobe\b/gi, "\u0441\u043F\u0430\u043B\u044C\u043D\u0438"],
  [/\bkuhinja\b/gi, "\u043A\u0443\u0445\u043D\u044F"],
  [/\btrpezarija\b/gi, "\u0441\u0442\u043E\u043B\u043E\u0432\u0430\u044F \u0437\u043E\u043D\u0430"],
  [/\bkupatilo\b/gi, "\u0432\u0430\u043D\u043D\u0430\u044F \u043A\u043E\u043C\u043D\u0430\u0442\u0430"],
  [/\bpredsoblje\b/gi, "\u043F\u0440\u0438\u0445\u043E\u0436\u0430\u044F"],
  [/\bходник\b/gi, "\u043A\u043E\u0440\u0438\u0434\u043E\u0440"],
  [/\bhodnik\b/gi, "\u043A\u043E\u0440\u0438\u0434\u043E\u0440"],
  [/\bterasa\b/gi, "\u0442\u0435\u0440\u0440\u0430\u0441\u0430"],
  [/\bsprat\b/gi, "\u044D\u0442\u0430\u0436"],
  [/\bprizemlje\b/gi, "1-\u0439 \u044D\u0442\u0430\u0436 (\u043F\u0440\u0438\u0437\u0435\u043C\u043B\u044C\u0435)"],
  [/\bvisoko prizemlje\b/gi, "\u0432\u044B\u0441\u043E\u043A\u0438\u0439 1-\u0439 \u044D\u0442\u0430\u0436"],
  [/\bsuteren\b/gi, "\u0446\u043E\u043A\u043E\u043B\u044C\u043D\u044B\u0439 \u044D\u0442\u0430\u0436"],
  [/\bpotkrovlje\b/gi, "\u043C\u0430\u043D\u0441\u0430\u0440\u0434\u0430"],
  [/\bcentralno grejanje\b/gi, "\u0446\u0435\u043D\u0442\u0440\u0430\u043B\u044C\u043D\u043E\u0435 \u043E\u0442\u043E\u043F\u043B\u0435\u043D\u0438\u0435"],
  [/\bgrejanje na\b/gi, "\u043E\u0442\u043E\u043F\u043B\u0435\u043D\u0438\u0435:"],
  [/\binverter klimu\b/gi, "\u0438\u043D\u0432\u0435\u0440\u0442\u043E\u0440\u043D\u044B\u0439 \u043A\u043E\u043D\u0434\u0438\u0446\u0438\u043E\u043D\u0435\u0440"],
  [/\bklima uređaj\b/gi, "\u043A\u043E\u043D\u0434\u0438\u0446\u0438\u043E\u043D\u0435\u0440"],
  [/\bklima\b/gi, "\u043A\u043E\u043D\u0434\u0438\u0446\u0438\u043E\u043D\u0435\u0440"],
  [/\bgaražno mesto\b/gi, "\u0433\u0430\u0440\u0430\u0436\u043D\u043E\u0435 \u043C\u0435\u0441\u0442\u043E"],
  [/\bparking mesto\b/gi, "\u043F\u0430\u0440\u043A\u043E\u0432\u043E\u0447\u043D\u043E\u0435 \u043C\u0435\u0441\u0442\u043E"],
  [/\bkućni ljubimci dozvoljeni\b/gi, "\u043C\u043E\u0436\u043D\u043E \u0441 \u0434\u043E\u043C\u0430\u0448\u043D\u0438\u043C\u0438 \u0436\u0438\u0432\u043E\u0442\u043D\u044B\u043C\u0438"],
  [/\bpet friendly\b/gi, "\u043C\u043E\u0436\u043D\u043E \u0441 \u043F\u0438\u0442\u043E\u043C\u0446\u0430\u043C\u0438 (pet-friendly)"],
  [/\bbez posrednika\b/gi, "\u043E\u0442 \u0441\u043E\u0431\u0441\u0442\u0432\u0435\u043D\u043D\u0438\u043A\u0430 (\u0431\u0435\u0437 \u043F\u043E\u0441\u0440\u0435\u0434\u043D\u0438\u043A\u043E\u0432)"],
  [/\bvlasnik\b/gi, "\u0441\u043E\u0431\u0441\u0442\u0432\u0435\u043D\u043D\u0438\u043A"],
  [/\bdepozit obavezan\b/gi, "\u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0434\u0435\u043F\u043E\u0437\u0438\u0442"],
  [/\bdepozit\b/gi, "\u0434\u0435\u043F\u043E\u0437\u0438\u0442"],
  [/\bmesečno\b/gi, "\u0432 \u043C\u0435\u0441\u044F\u0446"],
  [/\bduži vremenski period\b/gi, "\u043D\u0430 \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0439 \u0441\u0440\u043E\u043A"],
  [/\bna duže\b/gi, "\u043D\u0430 \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0439 \u0441\u0440\u043E\u043A"],
  [/\bu blizini\b/gi, "\u0440\u044F\u0434\u043E\u043C \u0441"],
  [/\bstrogi centar\b/gi, "\u0441\u0430\u043C\u044B\u0439 \u0446\u0435\u043D\u0442\u0440"],
  [/\bcentar\b/gi, "\u0446\u0435\u043D\u0442\u0440"],
  [/\bprostran\b/gi, "\u043F\u0440\u043E\u0441\u0442\u043E\u0440\u043D\u0430\u044F"],
  [/\bsvetao\b/gi, "\u0441\u0432\u0435\u0442\u043B\u0430\u044F"],
  [/\bmiran kraj\b/gi, "\u0442\u0438\u0445\u0438\u0439 \u0440\u0430\u0439\u043E\u043D"],
  [/\bmirnom delu\b/gi, "\u0432 \u0442\u0438\u0445\u043E\u0439 \u0447\u0430\u0441\u0442\u0438"],
  [/\bodlična lokacija\b/gi, "\u043E\u0442\u043B\u0438\u0447\u043D\u0430\u044F \u043B\u043E\u043A\u0430\u0446\u0438\u044F"]
];
function stripHtmlTags(html = "") {
  return html.replace(/<br\s*\/?>/gi, "\n").replace(/<\/p>/gi, "\n").replace(/<[^>]+>/g, "").replace(/&nbsp;/gi, " ").replace(/&quot;/gi, '"').replace(/&#39;/gi, "'").replace(/&amp;/gi, "&").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">").replace(/\n{3,}/g, "\n\n").trim();
}
function translateSerbianToRussian(text = "") {
  if (!text) return "";
  let out = stripHtmlTags(text);
  const locEntries = Object.entries(BELGRADE_LOC_RU_MAP).sort((a, b) => b[0].length - a[0].length);
  for (const [sr, ru] of locEntries) {
    const escaped = sr.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    out = out.replace(new RegExp(escaped, "gi"), ru);
  }
  for (const [regex, replacement] of SERBIAN_PHRASE_DICT) {
    out = out.replace(regex, replacement);
  }
  return stripPhoneAndContactMentions(out).trim();
}
function parseRomanOrNumericFloor(rawFloor) {
  if (typeof rawFloor === "number" && !isNaN(rawFloor)) return Math.max(1, Math.round(rawFloor));
  if (!rawFloor) return 2;
  const s = String(rawFloor).trim().toUpperCase();
  if (s === "PR" || s === "VPR" || s === "NPR" || s === "SUT" || s === "PSUT") return 1;
  const num = parseInt(s, 10);
  if (!isNaN(num)) return Math.max(1, num);
  const romanMap = {
    I: 1,
    II: 2,
    III: 3,
    IV: 4,
    V: 5,
    VI: 6,
    VII: 7,
    VIII: 8,
    IX: 9,
    X: 10,
    XI: 11,
    XII: 12,
    XIII: 13,
    XIV: 14,
    XV: 15,
    XVI: 16,
    XVII: 17,
    XVIII: 18,
    XIX: 19,
    XX: 20
  };
  return romanMap[s] || 2;
}
function normalizeHaloImageUrl(rawUrl) {
  if (!rawUrl) return "";
  let clean = rawUrl.trim().replace(/^['"]|['"]$/g, "");
  if (clean.startsWith("//")) clean = `https:${clean}`;
  else if (clean.startsWith("/")) clean = `${HALO_IMAGE_ROOT}${clean}`;
  clean = clean.replace(/\/Thumbs\/(\d+)\/[ms]\//i, "/Thumbs/$1/l/");
  clean = clean.replace("https://img.halooglasi.com//", "https://img.halooglasi.com/");
  return clean;
}
function convertHaloClassifiedToApartment(classified, agentPhone = DEFAULT_AGENT_PHONE) {
  const adId = String(classified.Id || classified.id || Date.now());
  const other = classified.OtherFields || {};
  const priceEur = Math.max(
    100,
    Math.round(Number(other.cena_d || other.defaultunit_cena_d || classified.Price || 450))
  );
  const areaSqm = Math.max(
    15,
    Math.round(Number(other.kvadratura_d || other.defaultunit_kvadratura_d || 48))
  );
  const rawRoomsStr = String(other.broj_soba_s || "2.0").replace(",", ".");
  const rawRoomsFloat = parseFloat(rawRoomsStr) || 2;
  const rooms = Math.max(1, Math.round(rawRoomsFloat));
  const bedrooms = rawRoomsFloat <= 1.2 ? 1 : Math.max(1, Math.floor(rawRoomsFloat));
  const floor = parseRomanOrNumericFloor(other.sprat_s);
  const totalFloors = Math.max(floor, parseRomanOrNumericFloor(other.sprat_od_s || floor + 2));
  const namestenost = String(other.namestenost_s || "").toLowerCase();
  let furniture = "full";
  if (namestenost.includes("polu")) furniture = "partial";
  else if (namestenost.includes("praz")) furniture = "none";
  const opstina = String(other.lokacija_s || "").trim();
  const mikrolokacija = String(other.mikrolokacija_s || "").trim();
  const ulica = String(other.ulica_t || "").trim();
  const opstinaRu = BELGRADE_LOC_RU_MAP[opstina] || opstina.replace(/^Opština\s+/i, "");
  const mikroRu = BELGRADE_LOC_RU_MAP[mikrolokacija] || mikrolokacija;
  const locationHint = `${opstina} ${mikrolokacija} ${ulica} ${classified.Title || ""}`;
  const district = getAccurateApartmentDistrict({
    city: "belgrade",
    district: opstinaRu,
    address: locationHint,
    title: classified.Title || ""
  });
  const addressParts = ["\u0433. \u0411\u0435\u043B\u0433\u0440\u0430\u0434"];
  if (opstinaRu) addressParts.push(opstinaRu);
  if (mikroRu && mikroRu !== opstinaRu) addressParts.push(mikroRu);
  if (ulica) addressParts.push(`\u0443\u043B. ${ulica}`);
  const address = addressParts.join(", ");
  let lat = 0;
  let lng = 0;
  if (typeof classified.GeoLocationRPT === "string" && classified.GeoLocationRPT.includes(",")) {
    const [latStr, lngStr] = classified.GeoLocationRPT.split(",");
    const parsedLat = parseFloat(latStr);
    const parsedLng = parseFloat(lngStr);
    if (!isNaN(parsedLat) && !isNaN(parsedLng) && parsedLat > 44.5 && parsedLat < 45.1) {
      lat = parsedLat;
      lng = parsedLng;
    }
  }
  if (!lat || !lng) {
    const resolved = getAccurateApartmentCoordinates({
      id: `halo-${adId}`,
      city: "belgrade",
      district,
      address,
      title: classified.Title || ""
    });
    lat = resolved.lat;
    lng = resolved.lng;
  }
  const rawImgs = Array.isArray(classified.ImageURLs) ? classified.ImageURLs : [];
  const images = rawImgs.map(normalizeHaloImageUrl).filter((u) => Boolean(u) && !u.includes("no-image"));
  const rawDodatno = Array.isArray(other.dodatno_ss) ? other.dodatno_ss : [];
  const rawOstalo = Array.isArray(other.ostalo_ss) ? other.ostalo_ss : [];
  const combinedRawAmenities = [...rawDodatno, ...rawOstalo];
  const amenitiesSet = /* @__PURE__ */ new Set();
  for (const item of combinedRawAmenities) {
    const mapped = SERBIAN_AMENITIES_MAP[item] || translateSerbianToRussian(item);
    if (mapped) amenitiesSet.add(mapped);
  }
  if (other.grejanje_s || other.tip_objekta_s) {
    if (other.tip_objekta_s === "Novogradnja") amenitiesSet.add("\u041D\u043E\u0432\u043E\u0441\u0442\u0440\u043E\u0439\u043A\u0430");
    if (other.stanje_objekta_s === "Lux") amenitiesSet.add("\u041B\u044E\u043A\u0441-\u0440\u0435\u043C\u043E\u043D\u0442");
    if (other.stanje_objekta_s === "Renovirano") amenitiesSet.add("\u0421\u0432\u0435\u0436\u0438\u0439 \u0440\u0435\u043C\u043E\u043D\u0442");
  }
  if (other.oglasivac_nekretnine_s === "Vlasnik" || other.oglasivac_nekretnine_id_l === 387237) {
    amenitiesSet.add("\u041E\u0442 \u0441\u043E\u0431\u0441\u0442\u0432\u0435\u043D\u043D\u0438\u043A\u0430");
  }
  if (amenitiesSet.size === 0) {
    amenitiesSet.add("\u041A\u043E\u043D\u0434\u0438\u0446\u0438\u043E\u043D\u0435\u0440");
    amenitiesSet.add("Wi-Fi / \u0418\u043D\u0442\u0435\u0440\u043D\u0435\u0442");
    amenitiesSet.add("\u041E\u0442 \u0441\u043E\u0431\u0441\u0442\u0432\u0435\u043D\u043D\u0438\u043A\u0430");
  }
  const rawTextDesc = stripHtmlTags(classified.TextHtml || classified.Text || "");
  const isPetFriendly = combinedRawAmenities.some((a) => /ljubimci|pet/i.test(a)) || /ljubimci|pet\s*friendly/i.test(rawTextDesc);
  const petPolicy = isPetFriendly ? "allowed" : "cats_only";
  const translatedRawTitle = translateSerbianToRussian(classified.Title || "");
  const roomTitlePrefix = rawRoomsFloat <= 1 ? "\u0421\u0442\u0443\u0434\u0438\u044F / 1-\u043A\u043E\u043C\u043D. \u043A\u0432\u0430\u0440\u0442\u0438\u0440\u0430" : `${rooms}-\u043A\u043E\u043C\u043D. \u043A\u0432\u0430\u0440\u0442\u0438\u0440\u0430`;
  const locTitleSuffix = mikroRu || opstinaRu || "\u0411\u0435\u043B\u0433\u0440\u0430\u0434";
  const title = translatedRawTitle.length >= 8 ? `${roomTitlePrefix} (${areaSqm} \u043C\xB2) \u2014 ${locTitleSuffix}` : `${roomTitlePrefix} \u0432 \u0411\u0435\u043B\u0433\u0440\u0430\u0434\u0435 (${locTitleSuffix}), ${areaSqm} \u043C\xB2`;
  const translatedBody = translateSerbianToRussian(rawTextDesc);
  const summaryHeader = `\u041A\u0432\u0430\u0440\u0442\u0438\u0440\u0430 \u043E\u0442 \u0441\u043E\u0431\u0441\u0442\u0432\u0435\u043D\u043D\u0438\u043A\u0430 \u0432 \u0411\u0435\u043B\u0433\u0440\u0430\u0434\u0435 (${address}). \u041F\u043B\u043E\u0449\u0430\u0434\u044C ${areaSqm} \u043C\xB2, \u043A\u043E\u043C\u043D\u0430\u0442: ${rawRoomsStr}, \u044D\u0442\u0430\u0436 ${floor}/${totalFloors}. \u0421\u0442\u043E\u0438\u043C\u043E\u0441\u0442\u044C \u0430\u0440\u0435\u043D\u0434\u044B: \u20AC${priceEur}/\u043C\u0435\u0441.`;
  const description = translatedBody ? `${summaryHeader}

${translatedBody}` : `${summaryHeader}
\u041F\u043E\u043B\u043D\u043E\u0441\u0442\u044C\u044E \u0433\u043E\u0442\u043E\u0432\u0430 \u043A \u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440\u0443 \u0438 \u0437\u0430\u0441\u0435\u043B\u0435\u043D\u0438\u044E.`;
  const relUrl = classified.RelativeUrl || `/nekretnine/izdavanje-stanova/beograd/${adId}`;
  const sourceUrl = relUrl.startsWith("http") ? relUrl : `https://www.halooglasi.com${relUrl.startsWith("/") ? "" : "/"}${relUrl}`;
  return {
    id: `halo-${adId}`,
    city: "belgrade",
    title,
    district,
    address,
    priceUsd: priceEur,
    currency: "EUR",
    originalPrice: priceEur,
    rooms,
    bedrooms,
    areaSqm,
    floor,
    totalFloors,
    furniture,
    petPolicy,
    minPeriod: "month_to_year",
    maxResidents: Math.max(2, rooms * 2),
    images: images.length > 0 ? images : ["https://img.halooglasi.com/slike/oglasi/Thumbs/260925/l/stan---borcasebes-5-minuta-od-stanice-5425647732304-71817134334.jpg"],
    description,
    amenities: Array.from(amenitiesSet),
    lat,
    lng,
    isNew: true,
    sourceUrl,
    landlord: {
      id: `landlord-halo-${adId}`,
      name: "\u0421\u043E\u0431\u0441\u0442\u0432\u0435\u043D\u043D\u0438\u043A \u2022 \u0411\u0435\u043B\u0433\u0440\u0430\u0434 (Rentch)",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80",
      phone: agentPhone,
      verified: true,
      responseTime: "\u0434\u043E 15 \u043C\u0438\u043D\u0443\u0442",
      rating: 4.9
    }
  };
}
function convertHaloListAdToApartment(adItem, agentPhone = DEFAULT_AGENT_PHONE) {
  if (!adItem || typeof adItem !== "object") return null;
  const adId = String(adItem.Id || adItem.id || "").trim();
  if (!adId) return null;
  const rawListHtml = String(adItem.ListHTML || "").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, "&");
  const priceMatch = rawListHtml.match(/data-value=["']([\d.,]+)["']/i) || rawListHtml.match(/([\d.]+)\s*(?:&nbsp;|\s)*€/i);
  const priceEur = priceMatch ? Math.max(100, Math.round(parseFloat(priceMatch[1].replace(/\./g, "").replace(",", ".")) || 450)) : 450;
  const imgMatch = rawListHtml.match(/<img[^>]+src=["']([^"']+)["']/i);
  const mainImg = imgMatch ? normalizeHaloImageUrl(imgMatch[1]) : "";
  const placesBlockMatch = rawListHtml.match(/<ul[^>]*class=["'][^"']*subtitle-places[^"']*["'][^>]*>([\s\S]*?)<\/ul>/i);
  const places = [];
  if (placesBlockMatch) {
    const liMatches = placesBlockMatch[1].matchAll(/<li[^>]*>([\s\S]*?)<\/li>/gi);
    for (const m of liMatches) {
      const cleaned = stripHtmlTags(m[1]).trim();
      if (cleaned) places.push(cleaned);
    }
  }
  const areaMatch = rawListHtml.match(/([\d.,]+)\s*(?:&nbsp;|\s)*m<sup>2<\/sup>/i);
  const areaSqm = areaMatch ? Math.max(15, Math.round(parseFloat(areaMatch[1].replace(",", ".")) || 45)) : 48;
  const roomsMatch = rawListHtml.match(/([\d.,+]+)\s*(?:&nbsp;|\s)*<span[^>]*>Broj soba<\/span>/i);
  const rawRoomsStr = roomsMatch ? roomsMatch[1].replace(",", ".") : "2.0";
  const rawRoomsFloat = parseFloat(rawRoomsStr) || 2;
  const rooms = Math.max(1, Math.round(rawRoomsFloat));
  const bedrooms = rawRoomsFloat <= 1.2 ? 1 : Math.max(1, Math.floor(rawRoomsFloat));
  const floorMatch = rawListHtml.match(/([^<>]+?)\s*(?:&nbsp;|\s)*<span[^>]*>Spratnost<\/span>/i);
  const floorRaw = floorMatch ? stripHtmlTags(floorMatch[1]).trim() : "2/5";
  const [flPart, totPart] = floorRaw.split("/");
  const floor = parseRomanOrNumericFloor(flPart);
  const totalFloors = Math.max(floor, parseRomanOrNumericFloor(totPart || floor + 2));
  const descMatch = rawListHtml.match(/<p[^>]*class=["'][^"']*product-description[^"']*["'][^>]*>([\s\S]*?)<\/p>/i);
  const shortDescSr = descMatch ? stripHtmlTags(descMatch[1]) : "";
  const opstina = places[1] || "";
  const mikrolokacija = places[2] || "";
  const ulica = places[3] || "";
  return convertHaloClassifiedToApartment(
    {
      Id: adId,
      Title: adItem.Title || stripHtmlTags(rawListHtml.match(/<h3[^>]*class=["'][^"']*product-title[^"']*["'][^>]*>([\s\S]*?)<\/h3>/i)?.[1] || ""),
      RelativeUrl: adItem.RelativeUrl || rawListHtml.match(/href=["'](\/nekretnine\/izdavanje-stanova\/[^"']+)["']/i)?.[1] || "",
      TextHtml: shortDescSr,
      ImageURLs: mainImg && !mainImg.includes("no-image") ? [mainImg] : [],
      OtherFields: {
        cena_d: priceEur,
        kvadratura_d: areaSqm,
        broj_soba_s: rawRoomsStr,
        sprat_s: String(floor),
        sprat_od_s: String(totalFloors),
        grad_s: "Beograd",
        lokacija_s: opstina,
        mikrolokacija_s: mikrolokacija,
        ulica_t: ulica,
        namestenost_s: "name\u0161teno",
        oglasivac_nekretnine_s: "Vlasnik"
      }
    },
    agentPhone
  );
}
function extractJsonObjectAfterMarker(source, marker) {
  const escapedMarker = marker.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const assignRegex = new RegExp(`${escapedMarker}\\s*=\\s*\\{`);
  const match = assignRegex.exec(source);
  if (!match) return null;
  const startBrace = source.indexOf("{", match.index + marker.length);
  if (startBrace === -1) return null;
  let depth = 0;
  let inString = false;
  let isEscaped = false;
  for (let i = startBrace; i < source.length; i++) {
    const ch = source[i];
    if (inString) {
      if (isEscaped) {
        isEscaped = false;
      } else if (ch === "\\") {
        isEscaped = true;
      } else if (ch === '"') {
        inString = false;
      }
    } else {
      if (ch === '"') {
        inString = true;
      } else if (ch === "{") {
        depth++;
      } else if (ch === "}") {
        depth--;
        if (depth === 0) {
          const jsonSlice = source.slice(startBrace, i + 1);
          try {
            return JSON.parse(jsonSlice);
          } catch {
            return null;
          }
        }
      }
    }
  }
  return null;
}
function parseHaloOglasiBatch(rawHtmlOrJson, agentPhone = DEFAULT_AGENT_PHONE) {
  if (!rawHtmlOrJson || !rawHtmlOrJson.trim()) {
    throw new Error("\u041F\u0443\u0441\u0442\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u0434\u043B\u044F \u043F\u0430\u0440\u0441\u0438\u043D\u0433\u0430 HaloOglasi");
  }
  const trimmed = rawHtmlOrJson.trim();
  const results = [];
  const seenIds = /* @__PURE__ */ new Set();
  const pushUnique = (apt) => {
    if (!apt || !apt.id || seenIds.has(apt.id)) return;
    seenIds.add(apt.id);
    results.push(apt);
  };
  const classifiedObj = extractJsonObjectAfterMarker(
    trimmed,
    "QuidditaEnvironment.CurrentClassified"
  );
  if (classifiedObj && (classifiedObj.Id || classifiedObj.OtherFields)) {
    pushUnique(convertHaloClassifiedToApartment(classifiedObj, agentPhone));
  }
  const listObj = extractJsonObjectAfterMarker(
    trimmed,
    "QuidditaEnvironment.serverListData"
  );
  if (listObj && Array.isArray(listObj.Ads)) {
    for (const ad of listObj.Ads) {
      pushUnique(convertHaloListAdToApartment(ad, agentPhone));
    }
  }
  if (results.length > 0) return results;
  if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
    try {
      const parsed = JSON.parse(trimmed);
      if (Array.isArray(parsed)) {
        for (const item of parsed) {
          if (item.OtherFields || item.ImageURLs) {
            pushUnique(convertHaloClassifiedToApartment(item, agentPhone));
          } else if (item.ListHTML) {
            pushUnique(convertHaloListAdToApartment(item, agentPhone));
          }
        }
      } else if (parsed.Ads && Array.isArray(parsed.Ads)) {
        for (const ad of parsed.Ads) {
          pushUnique(convertHaloListAdToApartment(ad, agentPhone));
        }
      } else if (parsed.Id || parsed.OtherFields) {
        pushUnique(convertHaloClassifiedToApartment(parsed, agentPhone));
      }
    } catch {
    }
  }
  return results;
}

// src/server/translator.ts
var import_genai = require("@google/genai");
var aiClient = null;
function getAiClient() {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    try {
      aiClient = new import_genai.GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    } catch (err) {
      console.warn("Failed to initialize Gemini AI client:", err);
    }
  }
  return aiClient;
}
function hasNonRussianText(str = "") {
  if (!str) return false;
  if (/[\u10A0-\u10FF]/.test(str)) return true;
  if (/\b(rent|apartment|bedroom|flat|studio|furnished|renovated|floor|balcony|square|street|district|tbilisi|batumi)\b/i.test(str)) {
    return true;
  }
  return false;
}
var GEO_DICT = {
  "\u10E5\u10D8\u10E0\u10D0\u10D5\u10D3\u10D4\u10D1\u10D0": "\u0421\u0434\u0430\u0435\u0442\u0441\u044F",
  "\u10D1\u10D8\u10DC\u10D0": "\u043A\u0432\u0430\u0440\u0442\u0438\u0440\u0430",
  "\u10DD\u10D7\u10D0\u10EE\u10D8\u10D0\u10DC\u10D8": "-\u043A\u043E\u043C\u043D\u0430\u0442\u043D\u0430\u044F",
  "\u10DD\u10D7\u10D0\u10EE\u10D8": "\u043A\u043E\u043C\u043D\u0430\u0442\u0430",
  "\u10D0\u10EE\u10D0\u10DA\u10D0\u10E8\u10D4\u10DC\u10D4\u10D1\u10E3\u10DA": "\u0432 \u043D\u043E\u0432\u043E\u0441\u0442\u0440\u043E\u0439\u043A\u0435",
  "\u10D0\u10EE\u10D0\u10DA\u10D0\u10E8\u10D4\u10DC\u10D4\u10D1\u10E3\u10DA\u10D8": "\u043D\u043E\u0432\u043E\u0441\u0442\u0440\u043E\u0439\u043A\u0430",
  "\u10D9\u10DD\u10E0\u10DE\u10E3\u10E1\u10E8\u10D8": "\u0432 \u043A\u043E\u0440\u043F\u0443\u0441\u0435",
  "\u10D4\u10D5\u10E0\u10DD\u10E0\u10D4\u10DB\u10DD\u10DC\u10E2\u10D8\u10D7": "\u0441 \u0435\u0432\u0440\u043E\u0440\u0435\u043C\u043E\u043D\u0442\u043E\u043C",
  "\u10D2\u10D0\u10E0\u10D4\u10DB\u10DD\u10DC\u10E2\u10D4\u10D1\u10E3\u10DA\u10D8": "\u0441 \u0440\u0435\u043C\u043E\u043D\u0442\u043E\u043C",
  "\u10E3\u10EA\u10EE\u10DD\u10D5\u10E0\u10D4\u10D1\u10D4\u10DA\u10D8": "\u043D\u0438\u043A\u0442\u043E \u043D\u0435 \u0436\u0438\u043B",
  "\u10D0\u10D5\u10D4\u10EF\u10D8\u10D7": "\u0441 \u043C\u0435\u0431\u0435\u043B\u044C\u044E",
  "\u10E2\u10D4\u10E5\u10DC\u10D8\u10D9\u10D8\u10D7": "\u0441 \u0442\u0435\u0445\u043D\u0438\u043A\u043E\u0439",
  "\u10E7\u10D5\u10D4\u10DA\u10D0 \u10E1\u10D0\u10ED\u10D8\u10E0\u10DD": "\u0432\u0441\u0435\u0439 \u043D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E\u0439",
  "\u10E1\u10D0\u10EB\u10D8\u10DC\u10D4\u10D1\u10D4\u10DA\u10D8": "\u0441\u043F\u0430\u043B\u044C\u043D\u044F",
  "\u10E1\u10D0\u10EB\u10D8\u10DC\u10D4\u10D1\u10DA\u10D8\u10D7": "\u0441\u043E \u0441\u043F\u0430\u043B\u044C\u043D\u0435\u0439",
  "\u10E1\u10E2\u10E3\u10D3\u10D8\u10DD": "\u0441\u0442\u0443\u0434\u0438\u044F",
  "\u10D0\u10D8\u10D5\u10DC\u10D8\u10D7": "\u0441 \u0431\u0430\u043B\u043A\u043E\u043D\u043E\u043C",
  "\u10D0\u10D8\u10D5\u10D0\u10DC\u10D8": "\u0431\u0430\u043B\u043A\u043E\u043D",
  "\u10EA\u10D4\u10DC\u10E2\u10E0\u10D0\u10DA\u10E3\u10E0\u10D8 \u10D2\u10D0\u10D7\u10D1\u10DD\u10D1\u10D0": "\u0446\u0435\u043D\u0442\u0440\u0430\u043B\u044C\u043D\u043E\u0435 \u043E\u0442\u043E\u043F\u043B\u0435\u043D\u0438\u0435",
  "\u10EA\u10D4\u10DC\u10E2\u10E0\u10D0\u10DA\u10E3\u10E0\u10D8 \u10D2\u10D0\u10D7\u10D1\u10DD\u10D1\u10D8\u10D7": "\u0441 \u0446\u0435\u043D\u0442\u0440\u0430\u043B\u044C\u043D\u044B\u043C \u043E\u0442\u043E\u043F\u043B\u0435\u043D\u0438\u0435\u043C",
  "\u10D9\u10DD\u10DC\u10D3\u10D8\u10EA\u10D8\u10DD\u10DC\u10D4\u10E0\u10D8": "\u043A\u043E\u043D\u0434\u0438\u0446\u0438\u043E\u043D\u0435\u0440",
  "\u10DA\u10D8\u10E4\u10E2\u10D8": "\u043B\u0438\u0444\u0442",
  "\u10DE\u10D0\u10E0\u10D9\u10D8\u10DC\u10D2\u10D8": "\u043F\u0430\u0440\u043A\u0438\u043D\u0433",
  "\u10E1\u10D0\u10E0\u10D7\u10E3\u10DA\u10D8": "\u044D\u0442\u0430\u0436",
  "\u10E5\u10E3\u10E9\u10D0": "\u0443\u043B.",
  "\u10E5\u10E3\u10E9\u10D0\u10D6\u10D4": "\u043D\u0430 \u0443\u043B.",
  "\u10E5.": "\u0443\u043B.",
  "\u10D2\u10D0\u10DB\u10D6\u10D8\u10E0\u10D8": "\u043F\u0440\u043E\u0441\u043F.",
  "\u10D2\u10D0\u10DB\u10D6.": "\u043F\u0440\u043E\u0441\u043F.",
  "\u10E9\u10D8\u10EE\u10D8": "\u043F\u0435\u0440.",
  "\u10E8\u10D4\u10E1\u10D0\u10EE\u10D5\u10D4\u10D5\u10D8": "\u043F\u0435\u0440.",
  "\u10DB\u10D8\u10D9\u10E0\u10DD\u10E0\u10D0\u10D8\u10DD\u10DC\u10D8": "\u043C\u043A\u0440.",
  "\u10DB/\u10E0": "\u043C\u043A\u0440.",
  "\u10D9\u10D5\u10D0\u10E0\u10E2\u10D0\u10DA\u10D8": "\u043A\u0432\u0430\u0440\u0442\u0430\u043B",
  "\u10E3\u10D1\u10D0\u10DC\u10D8": "\u0440\u0430\u0439\u043E\u043D",
  "\u10D5\u10D0\u10D9\u10D4\u10E8\u10D8": "\u0432 \u0412\u0430\u043A\u0435",
  "\u10D5\u10D0\u10D9\u10D4": "\u0412\u0430\u043A\u0435",
  "\u10E1\u10D0\u10D1\u10E3\u10E0\u10D7\u10D0\u10DA\u10DD\u10D6\u10D4": "\u0432 \u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E",
  "\u10E1\u10D0\u10D1\u10E3\u10E0\u10D7\u10D0\u10DA\u10DD": "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E",
  "\u10D5\u10D4\u10E0\u10D0\u10D6\u10D4": "\u0432 \u0412\u0435\u0440\u0430",
  "\u10D5\u10D4\u10E0\u10D0": "\u0412\u0435\u0440\u0430",
  "\u10DB\u10D7\u10D0\u10EC\u10DB\u10D8\u10DC\u10D3\u10D0\u10D6\u10D4": "\u043D\u0430 \u041C\u0442\u0430\u0446\u043C\u0438\u043D\u0434\u0430",
  "\u10DB\u10D7\u10D0\u10EC\u10DB\u10D8\u10DC\u10D3\u10D0": "\u041C\u0442\u0430\u0446\u043C\u0438\u043D\u0434\u0430",
  "\u10E1\u10DD\u10DA\u10DD\u10DA\u10D0\u10D9\u10E8\u10D8": "\u0432 \u0421\u043E\u043B\u043E\u043B\u0430\u043A\u0438",
  "\u10E1\u10DD\u10DA\u10DD\u10DA\u10D0\u10D9\u10D8": "\u0421\u043E\u043B\u043E\u043B\u0430\u043A\u0438",
  "\u10DD\u10E0\u10D7\u10D0\u10ED\u10D0\u10DA\u10D0\u10E8\u10D8": "\u0432 \u041E\u0440\u0442\u0430\u0447\u0430\u043B\u0430",
  "\u10DD\u10E0\u10D7\u10D0\u10ED\u10D0\u10DA\u10D0": "\u041E\u0440\u0442\u0430\u0447\u0430\u043B\u0430",
  "\u10D0\u10D5\u10DA\u10D0\u10D1\u10D0\u10E0\u10E8\u10D8": "\u0432 \u0410\u0432\u043B\u0430\u0431\u0430\u0440\u0438",
  "\u10D0\u10D5\u10DA\u10D0\u10D1\u10D0\u10E0\u10D8": "\u0410\u0432\u043B\u0430\u0431\u0430\u0440\u0438",
  "\u10E9\u10E3\u10E6\u10E3\u10E0\u10D4\u10D7\u10E8\u10D8": "\u0432 \u0427\u0443\u0433\u0443\u0440\u0435\u0442\u0438",
  "\u10E9\u10E3\u10E6\u10E3\u10E0\u10D4\u10D7\u10D8": "\u0427\u0443\u0433\u0443\u0440\u0435\u0442\u0438",
  "\u10D3\u10D8\u10D3\u10E3\u10D1\u10D4\u10E8\u10D8": "\u0432 \u0414\u0438\u0434\u0443\u0431\u0435",
  "\u10D3\u10D8\u10D3\u10E3\u10D1\u10D4": "\u0414\u0438\u0434\u0443\u0431\u0435",
  "\u10D8\u10E1\u10D0\u10DC\u10E8\u10D8": "\u0432 \u0418\u0441\u0430\u043D\u0438",
  "\u10D8\u10E1\u10D0\u10DC\u10D8": "\u0418\u0441\u0430\u043D\u0438",
  "\u10E1\u10D0\u10DB\u10D2\u10DD\u10E0\u10E8\u10D8": "\u0432 \u0421\u0430\u043C\u0433\u043E\u0440\u0438",
  "\u10E1\u10D0\u10DB\u10D2\u10DD\u10E0\u10D8": "\u0421\u0430\u043C\u0433\u043E\u0440\u0438",
  "\u10D9\u10E0\u10EC\u10D0\u10DC\u10D8\u10E1\u10E8\u10D8": "\u0432 \u041A\u0440\u0446\u0430\u043D\u0438\u0441\u0438",
  "\u10D9\u10E0\u10EC\u10D0\u10DC\u10D8\u10E1\u10D8": "\u041A\u0440\u0446\u0430\u043D\u0438\u0441\u0438",
  "\u10D1\u10D0\u10D2\u10D4\u10D1\u10E8\u10D8": "\u0432 \u0411\u0430\u0433\u0435\u0431\u0438",
  "\u10D1\u10D0\u10D2\u10D4\u10D1\u10D8": "\u0411\u0430\u0433\u0435\u0431\u0438",
  "\u10D3\u10D8\u10D3 \u10D3\u10D8\u10E6\u10DD\u10DB\u10E8\u10D8": "\u0432 \u0414\u0438\u0434\u0438 \u0414\u0438\u0433\u043E\u043C\u0438",
  "\u10D3\u10D8\u10D3\u10D8 \u10D3\u10D8\u10E6\u10DD\u10DB\u10D8": "\u0414\u0438\u0434\u0438 \u0414\u0438\u0433\u043E\u043C\u0438",
  "\u10D3\u10D8\u10E6\u10DD\u10DB\u10E8\u10D8": "\u0432 \u0414\u0438\u0433\u043E\u043C\u0438",
  "\u10D3\u10D8\u10E6\u10DD\u10DB\u10D8": "\u0414\u0438\u0433\u043E\u043C\u0438",
  "\u10D3\u10D8\u10E6\u10DB\u10D8\u10E1 \u10DB\u10D0\u10E1\u10D8\u10D5\u10E8\u10D8": "\u0432 \u0414\u0438\u0433\u043E\u043C\u0441\u043A\u043E\u043C \u043C\u0430\u0441\u0441\u0438\u0432\u0435",
  "\u10D3\u10D8\u10E6\u10DB\u10D8\u10E1 \u10DB\u10D0\u10E1\u10D8\u10D5\u10D8": "\u0414\u0438\u0433\u043E\u043C\u0441\u043A\u0438\u0439 \u043C\u0430\u0441\u0441\u0438\u0432",
  "\u10DC\u10D0\u10EB\u10D0\u10DA\u10D0\u10D3\u10D4\u10D5\u10E8\u10D8": "\u0432 \u041D\u0430\u0434\u0437\u0430\u043B\u0430\u0434\u0435\u0432\u0438",
  "\u10DC\u10D0\u10EB\u10D0\u10DA\u10D0\u10D3\u10D4\u10D5\u10D8": "\u041D\u0430\u0434\u0437\u0430\u043B\u0430\u0434\u0435\u0432\u0438",
  "\u10D2\u10DA\u10D3\u10D0\u10DC\u10E8\u10D8": "\u0432 \u0413\u043B\u0434\u0430\u043D\u0438",
  "\u10D2\u10DA\u10D3\u10D0\u10DC\u10D8": "\u0413\u043B\u0434\u0430\u043D\u0438",
  "\u10D5\u10D0\u10E0\u10D9\u10D4\u10D7\u10D8\u10DA\u10E8\u10D8": "\u0432 \u0412\u0430\u0440\u043A\u0435\u0442\u0438\u043B\u0438",
  "\u10D5\u10D0\u10E0\u10D9\u10D4\u10D7\u10D8\u10DA\u10D8": "\u0412\u0430\u0440\u043A\u0435\u0442\u0438\u043B\u0438",
  "\u10E1\u10D0\u10DC\u10D6\u10DD\u10DC\u10D0\u10E8\u10D8": "\u0432 \u0421\u0430\u043D\u0437\u043E\u043D\u0430",
  "\u10E1\u10D0\u10DC\u10D6\u10DD\u10DC\u10D0": "\u0421\u0430\u043D\u0437\u043E\u043D\u0430",
  "\u10DB\u10E3\u10EE\u10D8\u10D0\u10DC\u10E8\u10D8": "\u0432 \u041C\u0443\u0445\u0438\u0430\u043D\u0438",
  "\u10DB\u10E3\u10EE\u10D8\u10D0\u10DC\u10D8": "\u041C\u0443\u0445\u0438\u0430\u043D\u0438",
  "\u10D1\u10D0\u10D7\u10E3\u10DB\u10D8": "\u0411\u0430\u0442\u0443\u043C\u0438",
  "\u10D7\u10D1\u10D8\u10DA\u10D8\u10E1\u10D8": "\u0422\u0431\u0438\u043B\u0438\u0441\u0438",
  "\u10E1\u10D0\u10E5\u10D0\u10E0\u10D7\u10D5\u10D4\u10DA\u10DD": "\u0413\u0440\u0443\u0437\u0438\u044F",
  "\u10DB\u10D8\u10E0\u10D8\u10D0\u10DC \u10DB\u10D4\u10E4\u10D8\u10E1": "\u0426\u0430\u0440\u044F \u041C\u0438\u0440\u0438\u0430\u043D\u0430",
  "\u10E8\u10E0\u10DD\u10E8\u10D8\u10E1": "\u0428\u0440\u043E\u0448\u0438",
  "\u10EE\u10D8\u10DB\u10E8\u10D8\u10D0\u10E8\u10D5\u10D8\u10DA\u10D8\u10E1": "\u0425\u0438\u043C\u0448\u0438\u0430\u0448\u0432\u0438\u043B\u0438",
  "\u10E0\u10E3\u10E1\u10D7\u10D0\u10D5\u10D4\u10DA\u10D8\u10E1": "\u0420\u0443\u0441\u0442\u0430\u0432\u0435\u043B\u0438",
  "\u10ED\u10D0\u10D5\u10ED\u10D0\u10D5\u10D0\u10EB\u10D8\u10E1": "\u0427\u0430\u0432\u0447\u0430\u0432\u0430\u0434\u0437\u0435",
  "\u10E7\u10D0\u10D6\u10D1\u10D4\u10D2\u10D8\u10E1": "\u041A\u0430\u0437\u0431\u0435\u0433\u0438",
  "\u10DE\u10D4\u10D9\u10D8\u10DC\u10D8\u10E1": "\u041F\u0435\u043A\u0438\u043D\u0430",
  "\u10EC\u10D4\u10E0\u10D4\u10D7\u10DA\u10D8\u10E1": "\u0426\u0435\u0440\u0435\u0442\u0435\u043B\u0438",
  "\u10D0\u10E6\u10DB\u10D0\u10E8\u10D4\u10DC\u10D4\u10D1\u10DA\u10D8\u10E1 \u10EE\u10D4\u10D8\u10D5.": "\u0430\u043B\u043B\u0435\u044F \u0410\u0433\u043C\u0430\u0448\u0435\u043D\u0435\u0431\u0435\u043B\u0438",
  "\u10D0\u10E6\u10DB\u10D0\u10E8\u10D4\u10DC\u10D4\u10D1\u10DA\u10D8\u10E1": "\u0410\u0433\u043C\u0430\u0448\u0435\u043D\u0435\u0431\u0435\u043B\u0438",
  "\u10D9\u10DD\u10E1\u10E2\u10D0\u10D5\u10D0\u10E1": "\u041A\u043E\u0441\u0442\u0430\u0432\u0430",
  "\u10E8\u10D0\u10E0\u10E2\u10D0\u10D5\u10D0\u10E1": "\u0428\u0430\u0440\u0442\u0430\u0432\u0430",
  "\u10DE\u10DD\u10DA\u10D8\u10E2\u10D9\u10DD\u10D5\u10E1\u10D9\u10D0\u10D8\u10D0\u10E1": "\u041F\u043E\u043B\u0438\u0442\u043A\u043E\u0432\u0441\u043A\u043E\u0439",
  "\u10EF\u10D8\u10E5\u10D8\u10D0\u10E1": "\u0414\u0436\u0438\u043A\u0438\u044F",
  "\u10DC\u10E3\u10EA\u10E3\u10D1\u10D8\u10EB\u10D8\u10E1 \u10E4\u10D4\u10E0\u10D3\u10DD\u10D1\u10D6\u10D4": "\u043D\u0430 \u043F\u043B\u0430\u0442\u043E \u041D\u0443\u0446\u0443\u0431\u0438\u0434\u0437\u0435",
  "\u10DC\u10E3\u10EA\u10E3\u10D1\u10D8\u10EB\u10D8\u10E1": "\u041D\u0443\u0446\u0443\u0431\u0438\u0434\u0437\u0435",
  "\u10D5\u10D0\u10DF\u10D0-\u10E4\u10E8\u10D0\u10D5\u10D4\u10DA\u10D0\u10E1": "\u0412\u0430\u0436\u0430-\u041F\u0448\u0430\u0432\u0435\u043B\u0430",
  "\u10D7\u10D0\u10DB\u10D0\u10E0\u10D0\u10E8\u10D5\u10D8\u10DA\u10D8\u10E1": "\u0422\u0430\u043C\u0430\u0440\u0430\u0448\u0432\u0438\u043B\u0438",
  "\u10D0\u10D1\u10D0\u10E8\u10D8\u10EB\u10D8\u10E1": "\u0410\u0431\u0430\u0448\u0438\u0434\u0437\u0435",
  "\u10E4\u10D0\u10DA\u10D8\u10D0\u10E8\u10D5\u10D8\u10DA\u10D8\u10E1": "\u041F\u0430\u043B\u0438\u0430\u0448\u0432\u0438\u043B\u0438",
  "\u10D1\u10D0\u10E0\u10DC\u10DD\u10D5\u10D8\u10E1": "\u0411\u0430\u0440\u043D\u043E\u0432\u0430",
  "\u10D2\u10DD\u10E0\u10D2\u10D0\u10E1\u10DA\u10D8\u10E1": "\u0413\u043E\u0440\u0433\u0430\u0441\u0430\u043B\u0438",
  "\u10EC\u10D8\u10DC\u10D0\u10DB\u10EB\u10E6\u10D5\u10E0\u10D8\u10E8\u10D5\u10D8\u10DA\u10D8\u10E1": "\u0426\u0438\u043D\u0430\u043C\u0434\u0437\u0433\u0432\u0440\u0438\u0448\u0432\u0438\u043B\u0438",
  "\u10DB\u10D0\u10E0\u10EF\u10D0\u10DC\u10D8\u10E8\u10D5\u10D8\u10DA\u10D8\u10E1": "\u041C\u0430\u0440\u0434\u0436\u0430\u043D\u0438\u0448\u0432\u0438\u043B\u0438",
  "\u10E5\u10D0\u10D5\u10D7\u10D0\u10E0\u10D0\u10EB\u10D8\u10E1": "\u041A\u0430\u0432\u0442\u0430\u0440\u0430\u0434\u0437\u0435",
  "\u10EA\u10D8\u10DC\u10EA\u10D0\u10EB\u10D8\u10E1": "\u0426\u0438\u043D\u0446\u0430\u0434\u0437\u0435",
  "\u10E8\u10D0\u10D5\u10D8\u10E8\u10D5\u10D8\u10DA\u10D8\u10E1": "\u0428\u0430\u0432\u0438\u0448\u0432\u0438\u043B\u0438",
  "\u10D0\u10DA\u10D4\u10E5\u10E1\u10D8\u10EB\u10D8\u10E1": "\u0410\u043B\u0435\u043A\u0441\u0438\u0434\u0437\u0435",
  "\u10DF\u10D5\u10D0\u10DC\u10D8\u10D0\u10E1": "\u0416\u0432\u0430\u043D\u0438\u044F",
  "\u10E3\u10DC\u10D8\u10D5\u10D4\u10E0\u10E1\u10D8\u10E2\u10D4\u10E2\u10D8\u10E1": "\u0423\u043D\u0438\u0432\u0435\u0440\u0441\u0438\u0442\u0435\u0442\u0441\u043A\u0430\u044F",
  "\u10D1\u10D0\u10EE\u10E2\u10E0\u10D8\u10DD\u10DC\u10D8\u10E1": "\u0411\u0430\u0445\u0442\u0440\u0438\u043E\u043D\u0438",
  "\u10ED\u10E7\u10DD\u10DC\u10D3\u10D8\u10D3\u10D4\u10DA\u10D8\u10E1": "\u0427\u043A\u043E\u043D\u0434\u0438\u0434\u0435\u043B\u0438",
  "\u10DB\u10D4\u10DA\u10D8\u10E5\u10D8\u10E8\u10D5\u10D8\u10DA\u10D8\u10E1": "\u041C\u0435\u043B\u0438\u043A\u0438\u0448\u0432\u0438\u043B\u0438",
  "\u10D9\u10D4\u10D3\u10D8\u10D0\u10E1": "\u041A\u0435\u0434\u0438\u044F",
  "\u10D5\u10D4\u10D9\u10E3\u10D0\u10E1": "\u0412\u0435\u043A\u0443\u0430",
  "\u10D9\u10E3\u10DE\u10E0\u10D0\u10EB\u10D8\u10E1": "\u041A\u0443\u043F\u0440\u0430\u0434\u0437\u0435",
  "\u10ED\u10D8\u10DA\u10D0\u10EB\u10D8\u10E1": "\u0427\u0438\u043B\u0430\u0434\u0437\u0435",
  "\u10D7\u10D0\u10D5\u10EE\u10D4\u10DA\u10D8\u10EB\u10D8\u10E1": "\u0422\u0430\u0432\u0445\u0435\u043B\u0438\u0434\u0437\u0435",
  "\u10D7\u10D0\u10D5\u10D3\u10D0\u10D3\u10D4\u10D1\u10E3\u10DA\u10D8\u10E1": "\u0414\u0435\u043C\u0435\u0442\u0440\u0435 \u0422\u0430\u0432\u0434\u0430\u0434\u0435\u0431\u0443\u043B\u0438",
  "\u10DE\u10D4\u10E2\u10E0\u10D8\u10EC\u10D8\u10E1": "\u0418\u043E\u0430\u043D\u043D\u0430 \u041F\u0435\u0442\u0440\u0438\u0446\u0438",
  "\u10D2\u10D4\u10DA\u10DD\u10D5\u10D0\u10DC\u10D8\u10E1": "\u041C\u0430\u0440\u0448\u0430\u043B\u0430 \u0413\u0435\u043B\u043E\u0432\u0430\u043D\u0438",
  "\u10D0\u10E2\u10D4\u10DC\u10D8\u10E1": "\u0410\u0442\u0435\u043D\u0438",
  "\u10DB\u10DD\u10E1\u10D0\u10E8\u10D5\u10D8\u10DA\u10D8\u10E1": "\u041C\u043E\u0441\u0430\u0448\u0432\u0438\u043B\u0438",
  "\u10E7\u10D8\u10E4\u10E8\u10D8\u10EB\u10D8\u10E1": "\u041A\u0438\u043F\u0448\u0438\u0434\u0437\u0435",
  "\u10DB\u10D8\u10EA\u10D9\u10D4\u10D5\u10D8\u10E9\u10D8\u10E1": "\u041C\u0438\u0446\u043A\u0435\u0432\u0438\u0447\u0430",
  "\u10E1\u10D0\u10D8\u10E0\u10DB\u10D8\u10E1": "\u0421\u0430\u0438\u0440\u043C\u0435",
  "\u10D2\u10D0\u10D2\u10D0\u10E0\u10D8\u10DC\u10D8\u10E1": "\u0413\u0430\u0433\u0430\u0440\u0438\u043D\u0430",
  "\u10D2\u10E3\u10DA\u10E3\u10D0\u10E1": "\u0413\u0443\u043B\u0443\u0430",
  "\u10D1\u10DD\u10ED\u10DD\u10E0\u10DB\u10D8\u10E1": "\u0411\u043E\u0447\u043E\u0440\u043C\u0430",
  "\u10D5\u10DD\u10DA\u10E1\u10D9\u10D8\u10E1": "\u0413\u0440. \u0412\u043E\u043B\u044C\u0441\u043A\u043E\u0433\u043E",
  "\u10D3\u10D0\u10D3\u10D8\u10D0\u10DC\u10D8\u10E1": "\u0426\u043E\u0442\u043D\u0435 \u0414\u0430\u0434\u0438\u0430\u043D\u0438",
  "\u10D2\u10E3\u10E0\u10D0\u10DB\u10D8\u10E8\u10D5\u10D8\u10DA\u10D8\u10E1": "\u0413\u0443\u0440\u0430\u043C\u0438\u0448\u0432\u0438\u043B\u0438",
  "\u10EE\u10D8\u10D6\u10D0\u10DC\u10D8\u10E8\u10D5\u10D8\u10DA\u10D8\u10E1": "\u0425\u0438\u0437\u0430\u043D\u0438\u0448\u0432\u0438\u043B\u0438",
  "\u10EF\u10D0\u10D5\u10D0\u10EE\u10D4\u10D7\u10D8\u10E1": "\u0414\u0436\u0430\u0432\u0430\u0445\u0435\u0442\u0438",
  "For Rent": "\u0421\u0434\u0430\u0435\u0442\u0441\u044F",
  "Apartment for rent": "\u0421\u0434\u0430\u0435\u0442\u0441\u044F \u043A\u0432\u0430\u0440\u0442\u0438\u0440\u0430",
  "Flat for rent": "\u0421\u0434\u0430\u0435\u0442\u0441\u044F \u043A\u0432\u0430\u0440\u0442\u0438\u0440\u0430"
};
var GEO_CHAR_MAP = {
  "\u10D0": "\u0430",
  "\u10D1": "\u0431",
  "\u10D2": "\u0433",
  "\u10D3": "\u0434",
  "\u10D4": "\u0435",
  "\u10D5": "\u0432",
  "\u10D6": "\u0437",
  "\u10D7": "\u0442",
  "\u10D8": "\u0438",
  "\u10D9": "\u043A",
  "\u10DA": "\u043B",
  "\u10DB": "\u043C",
  "\u10DC": "\u10DC",
  "\u10DD": "\u043E",
  "\u10DE": "\u043F",
  "\u10DF": "\u0436",
  "\u10E0": "\u0440",
  "\u10E1": "\u0441",
  "\u10E2": "\u0442",
  "\u10E3": "\u0443",
  "\u10E4": "\u0444",
  "\u10E5": "\u043A",
  "\u10E6": "\u0433",
  "\u10E7": "\u043A",
  "\u10E8": "\u0448",
  "\u10E9": "\u0447",
  "\u10EA": "\u0446",
  "\u10EB": "\u0434\u0437",
  "\u10EC": "\u0446",
  "\u10ED": "\u0447",
  "\u10EE": "\u0445",
  "\u10EF": "\u0434\u0436",
  "\u10F0": "\u0445"
};
GEO_CHAR_MAP["\u10DC"] = "\u043D";
var RU_POST_FIXES = [
  [/Сабурталозе/gi, "\u0432 \u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E"],
  [/Вакеши/gi, "\u0432 \u0412\u0430\u043A\u0435"],
  [/Веразе/gi, "\u0432 \u0412\u0435\u0440\u0430"],
  [/Дидубеши/gi, "\u0432 \u0414\u0438\u0434\u0443\u0431\u0435"],
  [/дид дигомши/gi, "\u0432 \u0414\u0438\u0434\u0438 \u0414\u0438\u0433\u043E\u043C\u0438"],
  [/Дигоми 1-9-ши/gi, "\u0432 \u0414\u0438\u0433\u043E\u043C\u0438 1-9"],
  [/дигомши/gi, "\u0432 \u0414\u0438\u0433\u043E\u043C\u0438"],
  [/багебши/gi, "\u0432 \u0411\u0430\u0433\u0435\u0431\u0438"],
  [/варкетилши/gi, "\u0432 \u0412\u0430\u0440\u043A\u0435\u0442\u0438\u043B\u0438"],
  [/крцанисши/gi, "\u0432 \u041A\u0440\u0446\u0430\u043D\u0438\u0441\u0438"],
  [/надзаладевши/gi, "\u0432 \u041D\u0430\u0434\u0437\u0430\u043B\u0430\u0434\u0435\u0432\u0438"],
  [/глданши/gi, "\u0432 \u0413\u043B\u0434\u0430\u043D\u0438"],
  [/самгорши/gi, "\u0432 \u0421\u0430\u043C\u0433\u043E\u0440\u0438"],
  [/исанши/gi, "\u0432 \u0418\u0441\u0430\u043D\u0438"],
  [/ортачалаши/gi, "\u0432 \u041E\u0440\u0442\u0430\u0447\u0430\u043B\u0430"],
  [/чугуретши/gi, "\u0432 \u0427\u0443\u0433\u0443\u0440\u0435\u0442\u0438"],
  [/сололакши/gi, "\u0432 \u0421\u043E\u043B\u043E\u043B\u0430\u043A\u0438"],
  [/авлабарши/gi, "\u0432 \u0410\u0432\u043B\u0430\u0431\u0430\u0440\u0438"],
  [/мтацминдазе/gi, "\u043D\u0430 \u041C\u0442\u0430\u0446\u043C\u0438\u043D\u0434\u0430"],
  [/санзонаши/gi, "\u0432 \u0421\u0430\u043D\u0437\u043E\u043D\u0430"],
  [/мухианши/gi, "\u0432 \u041C\u0443\u0445\u0438\u0430\u043D\u0438"],
  [/Нуцубидзе фердобзе/gi, "\u043D\u0430 \u043F\u043B\u0430\u0442\u043E \u041D\u0443\u0446\u0443\u0431\u0438\u0434\u0437\u0435"],
  [/сакартвело/gi, "\u0422\u0431\u0438\u043B\u0438\u0441\u0438"],
  [/Tbilisi/gi, "\u0422\u0431\u0438\u043B\u0438\u0441\u0438"],
  [/(\d+)\s+-комнатная/g, "$1-\u043A\u043E\u043C\u043D\u0430\u0442\u043D\u0430\u044F"]
];
function fallbackGeoToRu(text) {
  if (!text) return "";
  let result = text;
  const sortedEntries = Object.entries(GEO_DICT).sort((a, b) => b[0].length - a[0].length);
  for (const [geo, ru] of sortedEntries) {
    result = result.split(geo).join(ru);
  }
  result = result.replace(/[\u10A0-\u10FF]/g, (char) => GEO_CHAR_MAP[char] || char);
  for (const [pattern, replacement] of RU_POST_FIXES) {
    result = result.replace(pattern, replacement);
  }
  return result;
}
function translateApartmentFast(apt) {
  if (!apt) return apt;
  const fallbackApt = {
    ...apt,
    title: stripPhoneAndContactMentions(fallbackGeoToRu(apt.title)),
    address: fallbackGeoToRu(apt.address),
    description: stripPhoneAndContactMentions(fallbackGeoToRu(apt.description)),
    amenities: (apt.amenities || []).map(fallbackGeoToRu)
  };
  return sanitizeApartmentPhones(fallbackApt);
}
async function translateApartmentToRussian(apt) {
  if (!apt) return apt;
  const needsTranslation = hasNonRussianText(apt.title) || hasNonRussianText(apt.address) || hasNonRussianText(apt.description) || apt.amenities?.some(hasNonRussianText);
  if (!needsTranslation) {
    return sanitizeApartmentPhones(apt);
  }
  const ai = getAiClient();
  if (ai) {
    try {
      const prompt = `\u0422\u044B \u2014 \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0439 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440 \u0438 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0447\u0438\u043A \u043F\u043E\u0440\u0442\u0430\u043B\u0430 \u044D\u043B\u0438\u0442\u043D\u043E\u0439 \u0438 \u043A\u043E\u043C\u0444\u043E\u0440\u0442\u043D\u043E\u0439 \u043D\u0435\u0434\u0432\u0438\u0436\u0438\u043C\u043E\u0441\u0442\u0438 Rentch \u0432 \u0422\u0431\u0438\u043B\u0438\u0441\u0438 \u0438 \u0411\u0430\u0442\u0443\u043C\u0438.
\u041F\u0435\u0440\u0435\u0432\u0435\u0434\u0438 \u0432\u0441\u0435 \u0442\u0435\u043A\u0441\u0442\u044B \u043E\u0431 \u043E\u0431\u044A\u0435\u043A\u0442\u0435 \u043D\u0435\u0434\u0432\u0438\u0436\u0438\u043C\u043E\u0441\u0442\u0438 \u043D\u0430 \u0431\u0435\u0437\u0443\u043F\u0440\u0435\u0447\u043D\u044B\u0439, \u0447\u0438\u0441\u0442\u044B\u0439, \u0433\u0440\u0430\u043C\u043E\u0442\u043D\u044B\u0439 \u0440\u0443\u0441\u0441\u043A\u0438\u0439 \u044F\u0437\u044B\u043A.

\u0418\u0421\u0425\u041E\u0414\u041D\u042B\u0415 \u0414\u0410\u041D\u041D\u042B\u0415 (JSON):
${JSON.stringify({
        title: apt.title,
        address: apt.address,
        description: apt.description,
        amenities: apt.amenities || []
      }, null, 2)}

\u041F\u0420\u0410\u0412\u0418\u041B\u0410 \u041F\u0415\u0420\u0415\u0412\u041E\u0414\u0410:
1. "title": \u0421\u0434\u0435\u043B\u0430\u0439 \u043B\u0430\u043A\u043E\u043D\u0438\u0447\u043D\u044B\u043C \u0438 \u043F\u0440\u043E\u0434\u0430\u044E\u0449\u0438\u043C \u043D\u0430 \u0440\u0443\u0441\u0441\u043A\u043E\u043C \u044F\u0437\u044B\u043A\u0435 (\u043D\u0430\u043F\u0440\u0438\u043C\u0435\u0440: "\u0421\u0434\u0430\u0435\u0442\u0441\u044F 3-\u043A\u043E\u043C\u043D\u0430\u0442\u043D\u0430\u044F \u043A\u0432\u0430\u0440\u0442\u0438\u0440\u0430 \u0432 \u0412\u0430\u043A\u0435, \u0443\u043B. \u0428\u0440\u043E\u0448\u0438" \u0438\u043B\u0438 "\u0423\u044E\u0442\u043D\u0430\u044F 2-\u043A\u043E\u043C\u043D\u0430\u0442\u043D\u0430\u044F \u043A\u0432\u0430\u0440\u0442\u0438\u0440\u0430 \u043D\u0430 \u0443\u043B. \u0426\u0430\u0440\u044F \u041C\u0438\u0440\u0438\u0430\u043D\u0430").
2. "address": \u041F\u0435\u0440\u0435\u0432\u0435\u0434\u0438 \u0433\u0440\u0443\u0437\u0438\u043D\u0441\u043A\u0438\u0435 \u0438\u043B\u0438 \u0430\u043D\u0433\u043B\u0438\u0439\u0441\u043A\u0438\u0435 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044F \u0443\u043B\u0438\u0446 \u0438 \u0440\u0430\u0439\u043E\u043D\u043E\u0432 \u043D\u0430 \u0440\u0443\u0441\u0441\u043A\u0438\u0439 (\u043D\u0430\u043F\u0440\u0438\u043C\u0435\u0440: "\u10DB\u10D8\u10E0\u10D8\u10D0\u10DC \u10DB\u10D4\u10E4\u10D8\u10E1 \u10E5. 106" -> "\u0443\u043B. \u0426\u0430\u0440\u044F \u041C\u0438\u0440\u0438\u0430\u043D\u0430, 106"; "\u10E8\u10E0\u10DD\u10E8\u10D8\u10E1 \u10E5\u10E3\u10E9\u10D0 2" -> "\u0443\u043B. \u0428\u0440\u043E\u0448\u0438, 2"; "\u10DB\u10D0\u10E0\u10E8\u10D0\u10DA\u10D8 \u10D2\u10D4\u10DA\u10DD\u10D5\u10D0\u10DC\u10D8 \u10D2\u10D0\u10DB\u10D6\u10D8\u10E0\u10D8" -> "\u043F\u0440\u043E\u0441\u043F\u0435\u043A\u0442 \u041C\u0430\u0440\u0448\u0430\u043B\u0430 \u0413\u0435\u043B\u043E\u0432\u0430\u043D\u0438"; "\u10EE\u10D8\u10DB\u10E8\u10D8\u10D0\u10E8\u10D5\u10D8\u10DA\u10D8\u10E1 \u10E3\u10D1\u10D0\u10DC\u10D8" -> "\u0443\u043B. \u0428\u0435\u0440\u0438\u0444\u0430 \u0425\u0438\u043C\u0448\u0438\u0430\u0448\u0432\u0438\u043B\u0438, \u0411\u0430\u0442\u0443\u043C\u0438").
3. "description": \u0421\u0434\u0435\u043B\u0430\u0439 \u0441\u0432\u044F\u0437\u043D\u044B\u043C, \u043F\u0440\u0438\u044F\u0442\u043D\u044B\u043C \u0438 \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u043C \u0440\u0443\u0441\u0441\u043A\u0438\u043C \u0442\u0435\u043A\u0441\u0442\u043E\u043C. \u0423\u0431\u0435\u0440\u0438 \u0433\u0440\u0443\u0437\u0438\u043D\u0441\u043A\u0438\u0435 \u0441\u0438\u043C\u0432\u043E\u043B\u044B. \u0421\u043E\u0445\u0440\u0430\u043D\u0438 \u0432\u0441\u0435 \u0432\u0430\u0436\u043D\u044B\u0435 \u0434\u0435\u0442\u0430\u043B\u0438 (\u0440\u0435\u043C\u043E\u043D\u0442, \u0442\u0435\u0445\u043D\u0438\u043A\u0430, \u0432\u0438\u0434, \u043E\u0442\u043E\u043F\u043B\u0435\u043D\u0438\u0435, \u0443\u0441\u043B\u043E\u0432\u0438\u044F).
4. "amenities": \u0421\u043F\u0438\u0441\u043E\u043A \u0443\u0434\u043E\u0431\u0441\u0442\u0432 \u043D\u0430 \u0440\u0443\u0441\u0441\u043A\u043E\u043C \u044F\u0437\u044B\u043A\u0435 (\u043D\u0430\u043F\u0440\u0438\u043C\u0435\u0440: ["\u041A\u043E\u043D\u0434\u0438\u0446\u0438\u043E\u043D\u0435\u0440", "\u0411\u0430\u043B\u043A\u043E\u043D", "\u0421\u0442\u0438\u0440\u0430\u043B\u044C\u043D\u0430\u044F \u043C\u0430\u0448\u0438\u043D\u0430", "\u041F\u043E\u0441\u0443\u0434\u043E\u043C\u043E\u0439\u043A\u0430", "\u0426\u0435\u043D\u0442\u0440\u0430\u043B\u044C\u043D\u043E\u0435 \u043E\u0442\u043E\u043F\u043B\u0435\u043D\u0438\u0435"]).
5. \u0421\u0422\u0420\u041E\u0413\u041E \u0423\u0414\u0410\u041B\u0418 \u043B\u044E\u0431\u044B\u0435 \u043D\u043E\u043C\u0435\u0440\u0430 \u0442\u0435\u043B\u0435\u0444\u043E\u043D\u043E\u0432 (\u043D\u0430\u043F\u0440\u0438\u043C\u0435\u0440: +995..., 599..., 5xx...), \u0443\u043F\u043E\u043C\u0438\u043D\u0430\u043D\u0438\u044F \u0442\u0435\u043B\u0435\u0444\u043E\u043D\u043E\u0432, WhatsApp, Viber, Telegram, \u043F\u0440\u0438\u0437\u044B\u0432\u044B "\u0437\u0432\u043E\u043D\u0438\u0442\u0435", "\u043F\u0438\u0448\u0438\u0442\u0435 \u043C\u043D\u0435 \u0432 \u0432\u043E\u0442\u0441\u0430\u043F", "\u0441\u0432\u044F\u0436\u0438\u0442\u0435\u0441\u044C \u043F\u043E \u043D\u043E\u043C\u0435\u0440\u0443", "\u043D\u0435 \u0437\u0432\u043E\u043D\u0438\u0442\u0435 \u0438\u0437 \u0430\u0433\u0435\u043D\u0442\u0441\u0442\u0432" \u0438 \u0442.\u0434. \u0412 \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u0438 \u0438 \u0437\u0430\u0433\u043E\u043B\u043E\u0432\u043A\u0435 \u041D\u0415 \u0414\u041E\u041B\u0416\u041D\u041E \u0411\u042B\u0422\u042C \u041D\u0418 \u041E\u0414\u041D\u041E\u0413\u041E \u0422\u0415\u041B\u0415\u0424\u041E\u041D\u0410 \u0418 \u041D\u0418 \u041E\u0414\u041D\u041E\u0413\u041E \u0423\u041F\u041E\u041C\u0418\u041D\u0410\u041D\u0418\u042F \u0421\u0412\u042F\u0417\u0418.

\u0412\u0415\u0420\u041D\u0418 \u0422\u041E\u041B\u042C\u041A\u041E \u0427\u0418\u0421\u0422\u042B\u0419 JSON \u0411\u0415\u0417 \u041B\u0418\u0428\u041D\u0415\u0413\u041E \u0422\u0415\u041A\u0421\u0422\u0410 \u0418 \u0411\u0415\u0417 MARKDOWN-\u0420\u0410\u0417\u041C\u0415\u0422\u041A\u0418 \u0412 \u0422\u0410\u041A\u041E\u041C \u0424\u041E\u0420\u041C\u0410\u0422\u0415:
{
  "title": "...",
  "address": "...",
  "description": "...",
  "amenities": ["...", "..."]
}`;
      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: prompt
      });
      const responseText = response.text ? response.text.trim() : "";
      const cleanJson = responseText.replace(/^```json\s*/i, "").replace(/^```\s*/i, "").replace(/```$/i, "").trim();
      const parsed = JSON.parse(cleanJson);
      const translatedApt = {
        ...apt,
        title: stripPhoneAndContactMentions(parsed.title || fallbackGeoToRu(apt.title)),
        address: parsed.address || fallbackGeoToRu(apt.address),
        description: stripPhoneAndContactMentions(parsed.description || fallbackGeoToRu(apt.description)),
        amenities: Array.isArray(parsed.amenities) && parsed.amenities.length > 0 ? parsed.amenities : apt.amenities
      };
      return sanitizeApartmentPhones(translatedApt);
    } catch (err) {
      console.warn(`[Translator] Gemini API error for apartment ${apt.id}:`, err.message || err);
    }
  }
  const fallbackApt = {
    ...apt,
    title: stripPhoneAndContactMentions(fallbackGeoToRu(apt.title)),
    address: fallbackGeoToRu(apt.address),
    description: stripPhoneAndContactMentions(fallbackGeoToRu(apt.description)),
    amenities: (apt.amenities || []).map(fallbackGeoToRu)
  };
  return sanitizeApartmentPhones(fallbackApt);
}

// src/data/seedMyHome.ts
var SEED_MYHOME_APARTMENTS = [];

// server.ts
var DATA_DIR = import_path.default.join(process.cwd(), "data");
var APARTMENTS_FILE = import_path.default.join(DATA_DIR, "apartments.json");
var CRM_LEADS_FILE = import_path.default.join(DATA_DIR, "crm_leads.json");
var CRM_LEADS_BACKUP_FILE = import_path.default.join(DATA_DIR, "crm_leads.backup.json");
var CHATS_FILE = import_path.default.join(DATA_DIR, "chats.json");
var CHATS_BACKUP_FILE = import_path.default.join(DATA_DIR, "chats.backup.json");
var ANALYTICS_FILE = import_path.default.join(DATA_DIR, "analytics.json");
var ROOMMATES_FILE = import_path.default.join(DATA_DIR, "roommates.json");
var ADMIN_AUDIT_FILE = import_path.default.join(DATA_DIR, "admin_audit.json");
var ADMIN_SESSIONS_FILE = import_path.default.join(DATA_DIR, "admin_sessions.json");
var ADMIN_EMAIL = (process.env.ADMIN_EMAIL || "ai9292@mail.ru").trim().toLowerCase();
var ADMIN_PASSWORD = (process.env.ADMIN_PASSWORD || "redmay1968!").trim();
if (!import_fs.default.existsSync(DATA_DIR)) {
  import_fs.default.mkdirSync(DATA_DIR, { recursive: true });
}
if (!import_fs.default.existsSync(APARTMENTS_FILE)) {
  import_fs.default.writeFileSync(APARTMENTS_FILE, "[]", "utf-8");
}
if (!import_fs.default.existsSync(CRM_LEADS_FILE)) {
  import_fs.default.writeFileSync(CRM_LEADS_FILE, "[]", "utf-8");
}
if (!import_fs.default.existsSync(CHATS_FILE)) {
  import_fs.default.writeFileSync(CHATS_FILE, "{}", "utf-8");
}
if (!import_fs.default.existsSync(ANALYTICS_FILE)) {
  import_fs.default.writeFileSync(ANALYTICS_FILE, "{}", "utf-8");
}
if (!import_fs.default.existsSync(ROOMMATES_FILE)) {
  import_fs.default.writeFileSync(ROOMMATES_FILE, "[]", "utf-8");
}
if (!import_fs.default.existsSync(ADMIN_AUDIT_FILE)) {
  const initialAudit = [
    {
      id: "audit-init-1",
      timestamp: "28.09.2026, 20:25",
      isoTime: (/* @__PURE__ */ new Date()).toISOString(),
      event: "security_init",
      email: "ai9292@mail.ru",
      ip: "\u0421\u0438\u0441\u0442\u0435\u043C\u0430 \u0437\u0430\u0449\u0438\u0442\u044B Rentch",
      userAgent: "Rentch Security Shield v2.0",
      deviceSummary: "\u0421\u0435\u0440\u0432\u0435\u0440\u043D\u0430\u044F \u0437\u0430\u0449\u0438\u0442\u0430 \u0430\u043A\u0442\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0430",
      details: "\u0412\u043A\u043B\u044E\u0447\u0451\u043D \u0430\u0443\u0434\u0438\u0442 \u0432\u0445\u043E\u0434\u043E\u0432 \u0432 \u0430\u0434\u043C\u0438\u043D-\u043F\u0430\u043D\u0435\u043B\u044C, \u043A\u0440\u0438\u043F\u0442\u043E\u0433\u0440\u0430\u0444\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u0442\u043E\u043A\u0435\u043D\u044B \u0441\u0435\u0441\u0441\u0438\u0439, \u0437\u0430\u0449\u0438\u0442\u0430 \u043E\u0442 \u043F\u043E\u0434\u0431\u043E\u0440\u0430 \u043F\u0430\u0440\u043E\u043B\u044F (Brute-Force Lockout), \u0437\u0430\u0449\u0438\u0442\u0430 \u043E\u0442 SSRF/XSS \u0438 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u043E\u0435 \u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435 \u043B\u0438\u0434\u043E\u0432 (\u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D \u043B\u0438\u0434 \u043E\u0442 \u0420\u043E\u0434\u0438\u043E\u043D\u0430).",
      status: "info"
    }
  ];
  import_fs.default.writeFileSync(ADMIN_AUDIT_FILE, JSON.stringify(initialAudit, null, 2), "utf-8");
}
if (!import_fs.default.existsSync(ADMIN_SESSIONS_FILE)) {
  import_fs.default.writeFileSync(ADMIN_SESSIONS_FILE, "{}", "utf-8");
}
function summarizeUserAgent(ua) {
  if (!ua) return "\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u043E\u0435 \u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u043E";
  const lower = ua.toLowerCase();
  let os = "Desktop";
  if (lower.includes("iphone") || lower.includes("ipad")) os = "iOS (iPhone/iPad)";
  else if (lower.includes("android")) os = "Android";
  else if (lower.includes("mac os") || lower.includes("macintosh")) os = "macOS";
  else if (lower.includes("windows")) os = "Windows";
  else if (lower.includes("linux")) os = "Linux";
  let browser = "\u0411\u0440\u0430\u0443\u0437\u0435\u0440";
  if (lower.includes("telegram")) browser = "Telegram WebApp";
  else if (lower.includes("edg/")) browser = "Edge";
  else if (lower.includes("opr/") || lower.includes("opera")) browser = "Opera";
  else if (lower.includes("chrome/") && !lower.includes("edg/")) browser = "Chrome";
  else if (lower.includes("safari/") && !lower.includes("chrome/")) browser = "Safari";
  else if (lower.includes("firefox/")) browser = "Firefox";
  return `${browser} \u2022 ${os}`;
}
function getClientIp(req) {
  const xff = req.headers?.["x-forwarded-for"];
  if (typeof xff === "string" && xff.trim()) {
    return xff.split(",")[0].trim();
  }
  return String(req.ip || req.socket?.remoteAddress || "unknown");
}
function readAdminAudit() {
  try {
    if (import_fs.default.existsSync(ADMIN_AUDIT_FILE)) {
      const parsed = JSON.parse(import_fs.default.readFileSync(ADMIN_AUDIT_FILE, "utf-8"));
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) {
  }
  return [];
}
function appendAdminAudit(req, entry) {
  try {
    const existing = readAdminAudit();
    const ua = String(req?.headers?.["user-agent"] || "");
    const now = /* @__PURE__ */ new Date();
    const record = {
      id: `audit-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      timestamp: now.toLocaleString("ru-RU", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit"
      }),
      isoTime: now.toISOString(),
      event: entry.event,
      email: entry.email,
      ip: getClientIp(req),
      userAgent: ua,
      deviceSummary: summarizeUserAgent(ua),
      details: entry.details,
      status: entry.status
    };
    const updated = [record, ...existing].slice(0, 250);
    import_fs.default.writeFileSync(ADMIN_AUDIT_FILE, JSON.stringify(updated, null, 2), "utf-8");
  } catch (e) {
    console.error("Failed to write admin audit log:", e);
  }
}
function readAdminSessions() {
  try {
    if (import_fs.default.existsSync(ADMIN_SESSIONS_FILE)) {
      const parsed = JSON.parse(import_fs.default.readFileSync(ADMIN_SESSIONS_FILE, "utf-8"));
      if (parsed && typeof parsed === "object") return parsed;
    }
  } catch (e) {
  }
  return {};
}
function writeAdminSessions(sessions) {
  try {
    import_fs.default.writeFileSync(ADMIN_SESSIONS_FILE, JSON.stringify(sessions, null, 2), "utf-8");
  } catch (e) {
  }
}
function timingSafeMatch(a, b) {
  const bufA = Buffer.from(String(a));
  const bufB = Buffer.from(String(b));
  if (bufA.length !== bufB.length) return false;
  return import_crypto.default.timingSafeEqual(bufA, bufB);
}
var loginRateLimiter = /* @__PURE__ */ new Map();
function escapeHtml(unsafe) {
  return String(unsafe || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}
function isSafeExternalUrl(rawUrl) {
  try {
    const parsed = new URL(rawUrl);
    if (parsed.protocol !== "https:" && parsed.protocol !== "http:") return false;
    const host = parsed.hostname.toLowerCase();
    if (host === "localhost" || host === "127.0.0.1" || host === "0.0.0.0" || host === "::1" || host === "[::1]" || host.startsWith("169.254.") || host.startsWith("10.") || host.startsWith("192.168.") || /^172\.(1[6-9]|2[0-9]|3[0-1])\./.test(host) || host.endsWith(".internal") || host.endsWith(".local")) {
      return false;
    }
    return true;
  } catch {
    return false;
  }
}
function getTodayKey() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
function readAllAnalytics() {
  try {
    if (import_fs.default.existsSync(ANALYTICS_FILE)) {
      const parsed = JSON.parse(import_fs.default.readFileSync(ANALYTICS_FILE, "utf-8"));
      if (parsed && typeof parsed === "object") return parsed;
    }
  } catch (e) {
    console.error("Error reading analytics file:", e);
  }
  return {};
}
function getTodayAnalytics() {
  const all = readAllAnalytics();
  const today = getTodayKey();
  if (!all[today]) {
    all[today] = {
      date: today,
      pageViews: 0,
      landingViews: 0,
      catalogViews: 0,
      uniqueVisitorIds: [],
      apartmentViews: 0,
      swipesRight: 0,
      swipesLeft: 0,
      telegramClicks: 0,
      apartmentBreakdown: {}
    };
  }
  return all[today];
}
function saveTodayAnalytics(todayData) {
  try {
    const all = readAllAnalytics();
    all[todayData.date] = todayData;
    import_fs.default.writeFileSync(ANALYTICS_FILE, JSON.stringify(all, null, 2), "utf-8");
  } catch (e) {
    console.error("Error writing analytics file:", e);
  }
}
function isValidCrmLead(l) {
  if (!l || typeof l !== "object") return false;
  if (!l.id || typeof l.id !== "string" || /^lead-[0-9]+$/.test(l.id)) return false;
  if ("rooms" in l || "areaSqm" in l || "totalFloors" in l) return false;
  if (!l.stage || !l.clientName) return false;
  return true;
}
function isValidChatEntry(key, chat) {
  if (!key || /^[0-9]+$/.test(key)) return false;
  if (!chat || typeof chat !== "object") return false;
  if ("rooms" in chat || "areaSqm" in chat || "totalFloors" in chat) return false;
  if (!Array.isArray(chat.messages)) return false;
  return true;
}
function readCrmLeads() {
  try {
    if (import_fs.default.existsSync(CRM_LEADS_FILE)) {
      const data = import_fs.default.readFileSync(CRM_LEADS_FILE, "utf-8");
      const parsed = JSON.parse(data);
      if (Array.isArray(parsed)) {
        return parsed.filter(isValidCrmLead);
      }
    }
  } catch (err) {
    console.error("Error reading CRM leads file:", err);
  }
  return [];
}
function writeCrmLeads(leads) {
  try {
    const clean = Array.isArray(leads) ? leads.filter(isValidCrmLead) : [];
    if (clean.length > 0) {
      import_fs.default.writeFileSync(CRM_LEADS_BACKUP_FILE, JSON.stringify(clean, null, 2), "utf-8");
    } else if (import_fs.default.existsSync(CRM_LEADS_FILE)) {
      const prevRaw = import_fs.default.readFileSync(CRM_LEADS_FILE, "utf-8");
      try {
        const prevParsed = JSON.parse(prevRaw);
        if (Array.isArray(prevParsed) && prevParsed.length > 0) {
          import_fs.default.writeFileSync(CRM_LEADS_BACKUP_FILE, JSON.stringify(prevParsed, null, 2), "utf-8");
        }
      } catch {
      }
    }
    import_fs.default.writeFileSync(CRM_LEADS_FILE, JSON.stringify(clean, null, 2), "utf-8");
  } catch (err) {
    console.error("Error writing CRM leads file:", err);
  }
}
function readChats() {
  try {
    if (import_fs.default.existsSync(CHATS_FILE)) {
      const data = import_fs.default.readFileSync(CHATS_FILE, "utf-8");
      const parsed = JSON.parse(data);
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
        const clean = {};
        for (const [k, v] of Object.entries(parsed)) {
          if (isValidChatEntry(k, v)) {
            clean[k] = v;
          }
        }
        return clean;
      }
    }
  } catch (err) {
    console.error("Error reading chats file:", err);
  }
  return {};
}
function writeChats(chats) {
  try {
    const clean = {};
    if (chats && typeof chats === "object" && !Array.isArray(chats)) {
      for (const [k, v] of Object.entries(chats)) {
        if (isValidChatEntry(k, v)) {
          clean[k] = v;
        }
      }
    }
    if (Object.keys(clean).length > 0) {
      import_fs.default.writeFileSync(CHATS_BACKUP_FILE, JSON.stringify(clean, null, 2), "utf-8");
    }
    import_fs.default.writeFileSync(CHATS_FILE, JSON.stringify(clean, null, 2), "utf-8");
  } catch (err) {
    console.error("Error writing chats file:", err);
  }
}
function mergeMessages(existingMsgs = [], incomingMsgs = []) {
  const map = /* @__PURE__ */ new Map();
  if (Array.isArray(existingMsgs)) {
    for (const m of existingMsgs) {
      if (m && m.id) map.set(m.id, m);
    }
  }
  if (Array.isArray(incomingMsgs)) {
    for (const m of incomingMsgs) {
      if (m && m.id) map.set(m.id, m);
    }
  }
  return Array.from(map.values());
}
function mergeChatsData(existingChats, incomingChats) {
  const result = { ...existingChats };
  if (!incomingChats || typeof incomingChats !== "object" || Array.isArray(incomingChats)) return result;
  for (const [aptId, incChat] of Object.entries(incomingChats)) {
    if (!isValidChatEntry(aptId, incChat)) continue;
    const exChat = result[aptId];
    if (!exChat) {
      result[aptId] = incChat;
    } else {
      result[aptId] = {
        ...exChat,
        ...incChat,
        apartmentId: aptId,
        messages: mergeMessages(exChat.messages, incChat.messages),
        viewingConfirmed: Boolean(exChat.viewingConfirmed || incChat.viewingConfirmed),
        viewingSlot: incChat.viewingSlot || exChat.viewingSlot,
        lastActivity: incChat.lastActivity || exChat.lastActivity || "\u0442\u043E\u043B\u044C\u043A\u043E \u0447\u0442\u043E"
      };
    }
  }
  return result;
}
var STAGE_PRIORITY = {
  registered: 1,
  viewing_scheduled: 2,
  viewing_done_thinking: 3,
  paid: 4
};
function mergeLeadsData(existingLeads, incomingLeads, isAdminUpdate = false) {
  const cleanExisting = Array.isArray(existingLeads) ? existingLeads.filter(isValidCrmLead) : [];
  const cleanIncoming = Array.isArray(incomingLeads) ? incomingLeads.filter(isValidCrmLead) : [];
  if (cleanIncoming.length === 0 && !isAdminUpdate) {
    return cleanExisting;
  }
  const map = /* @__PURE__ */ new Map();
  for (const ex of cleanExisting) {
    map.set(ex.id, ex);
  }
  for (const inc of cleanIncoming) {
    let matchedKey = map.has(inc.id) ? inc.id : null;
    if (!matchedKey && inc.apartmentId) {
      for (const [k, v] of map.entries()) {
        if (v.apartmentId === inc.apartmentId) {
          matchedKey = k;
          break;
        }
      }
    }
    if (!matchedKey) {
      map.set(inc.id, inc);
    } else {
      const ex = map.get(matchedKey);
      const exPriority = STAGE_PRIORITY[ex.stage] || 1;
      const incPriority = STAGE_PRIORITY[inc.stage] || 1;
      const mergedStage = isAdminUpdate ? inc.stage || ex.stage : incPriority >= exPriority ? inc.stage : ex.stage;
      const mergedMessages = mergeMessages(ex.messages, inc.messages);
      const exUserCount = (ex.messages || []).filter((m) => m?.sender === "user").length;
      const mergedUserCount = mergedMessages.filter((m) => m?.sender === "user").length;
      const newUnread = isAdminUpdate ? inc.unreadByAdmin ?? 0 : mergedUserCount > exUserCount ? (ex.unreadByAdmin || 0) + (mergedUserCount - exUserCount) : Math.max(ex.unreadByAdmin || 0, inc.unreadByAdmin || 0);
      map.set(matchedKey, {
        ...ex,
        ...inc,
        id: matchedKey,
        clientName: inc.clientName && inc.clientName !== "\u041A\u043B\u0438\u0435\u043D\u0442 \u0438\u0437 \u0447\u0430\u0442\u0430" && inc.clientName !== "\u041D\u043E\u0432\u044B\u0439 \u0430\u0440\u0435\u043D\u0434\u0430\u0442\u043E\u0440" ? inc.clientName : ex.clientName || inc.clientName || "\u041A\u043B\u0438\u0435\u043D\u0442 Rentch",
        clientPhone: inc.clientPhone && inc.clientPhone !== "+995 599 00-00-00" ? inc.clientPhone : ex.clientPhone || inc.clientPhone || "+995 599 00-00-00",
        clientTelegram: inc.clientTelegram || ex.clientTelegram,
        stage: mergedStage,
        apartmentId: inc.apartmentId || ex.apartmentId,
        apartmentTitle: inc.apartmentTitle || ex.apartmentTitle,
        apartmentDistrict: inc.apartmentDistrict || ex.apartmentDistrict,
        apartmentAddress: inc.apartmentAddress || ex.apartmentAddress,
        apartmentPriceUsd: inc.apartmentPriceUsd || ex.apartmentPriceUsd,
        apartmentImage: inc.apartmentImage || ex.apartmentImage,
        apartmentSourceUrl: inc.apartmentSourceUrl || ex.apartmentSourceUrl,
        viewingSlot: inc.viewingSlot || ex.viewingSlot,
        questionnaireSummary: inc.questionnaireSummary || ex.questionnaireSummary,
        notes: inc.notes || ex.notes,
        messages: mergedMessages,
        unreadByAdmin: newUnread
      });
    }
  }
  return Array.from(map.values());
}
function reconcileChatsIntoLeads(chats, leads, apartments) {
  let changed = false;
  const updatedLeads = [...leads];
  for (const [aptId, chat] of Object.entries(chats || {})) {
    if (!chat || !Array.isArray(chat.messages)) continue;
    const userMsgs = chat.messages.filter((m) => m && m.sender === "user");
    const hasWelcomeSwipe = chat.messages.some(
      (m) => m && m.sender === "bot" && String(m.id || "").startsWith("bot-welcome-")
    );
    const hasActivity = userMsgs.length > 0 || Boolean(chat.viewingConfirmed) || Boolean(chat.roommate) || Boolean(chat.swipedRight) || hasWelcomeSwipe;
    if (!hasActivity) continue;
    let extractedName = chat.clientName || "";
    let extractedPhone = chat.clientPhone || "";
    for (const m of userMsgs) {
      if (m.senderName && m.senderName !== "\u041A\u043B\u0438\u0435\u043D\u0442" && m.senderName !== "\u0412\u044B" && m.senderName !== "\u041A\u043B\u0438\u0435\u043D\u0442 Rentch") {
        extractedName = m.senderName;
      }
      if (typeof m.text === "string") {
        const match = m.text.match(/Мои контактные данные:\s*([^\(\n\.]+?)(?:\s*\(([^\)\n]+)\)|\.)/i);
        if (match) {
          if (match[1]?.trim()) extractedName = match[1].trim();
          if (match[2]?.trim()) extractedPhone = match[2].trim();
        }
      }
    }
    const apt = apartments.find((a) => a.id === aptId);
    const aptSourceUrl = apt ? apt.sourceUrl || getMyHomeOriginalUrl(apt) || void 0 : getMyHomeOriginalUrl({ id: aptId }) || void 0;
    const leadIdx = updatedLeads.findIndex((l) => l && l.apartmentId === aptId);
    if (leadIdx === -1) {
      const lastUserMsg = userMsgs[userMsgs.length - 1];
      const newLead = {
        id: `crm-chat-${aptId}`,
        clientName: extractedName || "\u041A\u043B\u0438\u0435\u043D\u0442 Rentch",
        clientPhone: extractedPhone || "+995 599 00-00-00",
        stage: chat.viewingConfirmed ? "viewing_scheduled" : "registered",
        apartmentId: aptId,
        apartmentTitle: apt?.title || (aptId === "rentch-admin-support" ? "\u0427\u0430\u0442 \u0441 \u0430\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u043E\u0440\u043E\u043C Rentch" : "\u041A\u0432\u0430\u0440\u0442\u0438\u0440\u0430 \u0432 \u0422\u0431\u0438\u043B\u0438\u0441\u0438"),
        apartmentDistrict: apt?.district || "\u0421\u0430\u0431\u0443\u0440\u0442\u0430\u043B\u043E (Saburtalo)",
        apartmentAddress: apt?.address || "",
        apartmentPriceUsd: apt?.priceUsd || 0,
        apartmentImage: apt?.images?.[0] || "",
        apartmentSourceUrl: aptSourceUrl,
        viewingSlot: chat.viewingSlot,
        registeredAt: lastUserMsg?.timestamp ? `\u0421\u0435\u0433\u043E\u0434\u043D\u044F \u0432 ${lastUserMsg.timestamp}` : "\u0422\u043E\u043B\u044C\u043A\u043E \u0447\u0442\u043E",
        notes: chat.viewingConfirmed ? `\u0417\u0430\u043F\u0438\u0441\u044C \u0447\u0435\u0440\u0435\u0437 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435 Rentch \u043D\u0430 \u043E\u0441\u043C\u043E\u0442\u0440 \u043E\u0431\u044A\u0435\u043A\u0442\u0430 ${apt?.title || ""} (${chat.viewingSlot?.date || "\u0417\u0430\u0432\u0442\u0440\u0430"} \u0432 ${chat.viewingSlot?.time || "18:00"})` : `\u041D\u0430\u043F\u0438\u0441\u0430\u043B \u0432 \u0447\u0430\u0442 \u043F\u043E \u043E\u0431\u044A\u0435\u043A\u0442\u0443 \xAB${apt?.title || aptId}\xBB`,
        messages: chat.messages,
        unreadByAdmin: userMsgs.length || 1
      };
      updatedLeads.unshift(newLead);
      changed = true;
    } else {
      const existing = updatedLeads[leadIdx];
      const mergedMsgs = mergeMessages(existing.messages, chat.messages);
      const needsStageUpgrade = chat.viewingConfirmed && existing.stage === "registered";
      const needsViewingSlot = chat.viewingSlot && !existing.viewingSlot;
      const needsSourceUrl = aptSourceUrl && !existing.apartmentSourceUrl;
      const needsMsgsUpdate = mergedMsgs.length !== (existing.messages || []).length;
      if (needsStageUpgrade || needsViewingSlot || needsSourceUrl || needsMsgsUpdate) {
        const prevUserCount = (existing.messages || []).filter((m) => m?.sender === "user").length;
        const nextUserCount = mergedMsgs.filter((m) => m?.sender === "user").length;
        updatedLeads[leadIdx] = {
          ...existing,
          clientName: extractedName && (existing.clientName === "\u041A\u043B\u0438\u0435\u043D\u0442 \u0438\u0437 \u0447\u0430\u0442\u0430" || existing.clientName === "\u041D\u043E\u0432\u044B\u0439 \u0430\u0440\u0435\u043D\u0434\u0430\u0442\u043E\u0440" || existing.clientName === "\u041A\u043B\u0438\u0435\u043D\u0442 Rentch") ? extractedName : existing.clientName,
          clientPhone: extractedPhone && existing.clientPhone === "+995 599 00-00-00" ? extractedPhone : existing.clientPhone,
          stage: needsStageUpgrade ? "viewing_scheduled" : existing.stage,
          viewingSlot: existing.viewingSlot || chat.viewingSlot,
          apartmentTitle: existing.apartmentTitle || apt?.title,
          apartmentDistrict: existing.apartmentDistrict || apt?.district,
          apartmentAddress: existing.apartmentAddress || apt?.address,
          apartmentPriceUsd: existing.apartmentPriceUsd || apt?.priceUsd,
          apartmentImage: existing.apartmentImage || apt?.images?.[0],
          apartmentSourceUrl: existing.apartmentSourceUrl || aptSourceUrl,
          messages: mergedMsgs,
          unreadByAdmin: nextUserCount > prevUserCount ? (existing.unreadByAdmin || 0) + (nextUserCount - prevUserCount) : existing.unreadByAdmin ?? 0
        };
        changed = true;
      }
    }
  }
  return { leads: updatedLeads, changed };
}
function isFake(a) {
  if (!a || !a.id) return true;
  const fakeIds = /* @__PURE__ */ new Set([
    "apt-catalog-1",
    "apt-catalog-2",
    "apt-catalog-3",
    "apt-1",
    "apt-2",
    "apt-3",
    "apt-4",
    "apt-5",
    "apt-6",
    "apt-7",
    "apt-8",
    "myhome-25919663",
    "myhome-25884912",
    "myhome-25934105",
    "myhome-25911456",
    "myhome-25870198",
    "myhome-25948210",
    "myhome-25891034",
    "myhome-25920345",
    "myhome-25865091"
  ]);
  if (fakeIds.has(a.id)) return true;
  if (Array.isArray(a.images) && a.images.some((img) => typeof img === "string" && img.includes("unsplash.com"))) {
    return true;
  }
  return false;
}
function readApartments() {
  try {
    if (import_fs.default.existsSync(APARTMENTS_FILE)) {
      const data = import_fs.default.readFileSync(APARTMENTS_FILE, "utf-8");
      const parsed = JSON.parse(data);
      if (Array.isArray(parsed)) {
        return parsed.filter((a) => !isFake(a)).map((a) => {
          const sanitized = sanitizeApartmentPhones(a);
          sanitized.district = getAccurateApartmentDistrict(sanitized);
          const coords = getAccurateApartmentCoordinates(sanitized);
          sanitized.lat = coords.lat;
          sanitized.lng = coords.lng;
          if (Array.isArray(sanitized.images)) {
            sanitized.images = sanitized.images.map(
              (img) => typeof img === "string" ? img.replace(/static-statements\.tnet\.ge/g, "static-api-statements.tnet.ge") : img
            );
          }
          if (!sanitized.sourceUrl) {
            const resolvedUrl = getMyHomeOriginalUrl(sanitized);
            if (resolvedUrl) sanitized.sourceUrl = resolvedUrl;
          }
          return sanitized;
        });
      }
    }
  } catch (err) {
    console.error("Error reading apartments file:", err);
  }
  return [];
}
function writeApartments(apartments) {
  try {
    const sanitized = apartments.map((a) => sanitizeApartmentPhones(a));
    const jsonStr = JSON.stringify(sanitized, null, 2);
    import_fs.default.writeFileSync(APARTMENTS_FILE, jsonStr, "utf-8");
    const publicFile = import_path.default.join(process.cwd(), "public", "apartments.json");
    import_fs.default.writeFileSync(publicFile, jsonStr, "utf-8");
  } catch (err) {
    console.error("Error writing apartments file:", err);
  }
}
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = Number(process.env.PORT) || 3e3;
  app.set("trust proxy", true);
  app.use(import_express.default.json({ limit: "60mb" }));
  app.use(import_express.default.urlencoded({ extended: true, limit: "60mb" }));
  app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    res.header(
      "Access-Control-Allow-Headers",
      "Content-Type, Authorization, X-Requested-With, Accept, Origin, x-admin-token, x-admin-auth"
    );
    res.removeHeader("X-Frame-Options");
    res.header(
      "Content-Security-Policy",
      "frame-ancestors * https://*.telegram.org https://web.telegram.org https://t.me tg:;"
    );
    res.header("Referrer-Policy", "strict-origin-when-cross-origin");
    if (!req.path.startsWith("/assets/")) {
      res.header("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
      res.header("Pragma", "no-cache");
      res.header("Expires", "0");
    }
    if (req.method === "OPTIONS") {
      return res.sendStatus(204);
    }
    next();
  });
  app.get("/google*.html", (req, res) => {
    const filename = req.path.replace(/^\//, "");
    res.type("text/html").send(`google-site-verification: ${filename}`);
  });
  app.get(["/sw.js", "/registerSW.js"], (_req, res) => {
    res.setHeader("Content-Type", "application/javascript; charset=utf-8");
    res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
    res.send(`
      self.addEventListener('install', function() { self.skipWaiting(); });
      self.addEventListener('activate', function(event) {
        event.waitUntil(
          caches.keys().then(function(names) {
            return Promise.all(names.map(function(n) { return caches.delete(n); }));
          }).then(function() {
            return self.registration.unregister();
          })
        );
      });
    `);
  });
  app.get("/manifest.webmanifest", (_req, res) => {
    res.setHeader("Content-Type", "application/manifest+json; charset=utf-8");
    res.json({
      id: "/",
      name: "Rentch \u2014 \u0410\u0440\u0435\u043D\u0434\u0430 \u043A\u0432\u0430\u0440\u0442\u0438\u0440 \u0432 \u0422\u0431\u0438\u043B\u0438\u0441\u0438",
      short_name: "Rentch",
      description: "\u0421\u0435\u0440\u0432\u0438\u0441 \u043F\u043E\u0438\u0441\u043A\u0430 \u0430\u0440\u0435\u043D\u0434\u044B \u043A\u0432\u0430\u0440\u0442\u0438\u0440 \u0432 \u0422\u0431\u0438\u043B\u0438\u0441\u0438 \u0432 \u0444\u043E\u0440\u043C\u0430\u0442\u0435 \u0441\u0432\u0430\u0439\u043F\u043E\u0432 \u0438 \u043E\u043D\u043B\u0430\u0439\u043D-\u0431\u0440\u043E\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u043E\u0441\u043C\u043E\u0442\u0440\u043E\u0432.",
      theme_color: "#f43f5e",
      background_color: "#fafaf9",
      display: "standalone",
      start_url: "/",
      scope: "/",
      icons: [
        { src: "/pwa-192x192.png", sizes: "192x192", type: "image/png", purpose: "any" },
        { src: "/pwa-512x512.png", sizes: "512x512", type: "image/png", purpose: "any" },
        {
          src: "/pwa-maskable-512x512.png",
          sizes: "512x512",
          type: "image/png",
          purpose: "maskable"
        }
      ]
    });
  });
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", time: (/* @__PURE__ */ new Date()).toISOString() });
  });
  app.get("/api/analytics", (_req, res) => {
    const today = getTodayAnalytics();
    const all = readAllAnalytics();
    const allDays = Object.values(all).sort((a, b) => b.date.localeCompare(a.date));
    const allTimeUniqueSet = /* @__PURE__ */ new Set();
    let allTimePageViews = 0;
    let allTimeApartmentViews = 0;
    let allTimeSwipesRight = 0;
    let allTimeSwipesLeft = 0;
    const allTimeBreakdown = {};
    for (const d of allDays) {
      if (Array.isArray(d.uniqueVisitorIds)) {
        for (const vid of d.uniqueVisitorIds) {
          if (vid) allTimeUniqueSet.add(vid);
        }
      }
      allTimePageViews += d.pageViews || 0;
      allTimeApartmentViews += d.apartmentViews || 0;
      allTimeSwipesRight += d.swipesRight || 0;
      allTimeSwipesLeft += d.swipesLeft || 0;
      if (d.apartmentBreakdown && typeof d.apartmentBreakdown === "object") {
        for (const [aptId, b] of Object.entries(d.apartmentBreakdown)) {
          if (!b) continue;
          if (!allTimeBreakdown[aptId]) {
            allTimeBreakdown[aptId] = {
              title: b.title || "\u041A\u0432\u0430\u0440\u0442\u0438\u0440\u0430 \u0432 \u0422\u0431\u0438\u043B\u0438\u0441\u0438",
              views: 0,
              likes: 0,
              passes: 0
            };
          }
          allTimeBreakdown[aptId].views += b.views || 0;
          allTimeBreakdown[aptId].likes += b.likes || 0;
          allTimeBreakdown[aptId].passes += b.passes || 0;
        }
      }
    }
    res.json({
      today: {
        ...today,
        uniqueVisitors: Array.isArray(today.uniqueVisitorIds) ? today.uniqueVisitorIds.length : 0,
        apartmentBreakdown: Object.keys(today.apartmentBreakdown || {}).length > 0 ? today.apartmentBreakdown : allTimeBreakdown
      },
      allTime: {
        uniqueVisitors: allTimeUniqueSet.size,
        pageViews: allTimePageViews,
        apartmentViews: allTimeApartmentViews,
        swipesRight: allTimeSwipesRight,
        swipesLeft: allTimeSwipesLeft,
        daysTracked: allDays.length,
        firstDate: allDays.length > 0 ? allDays[allDays.length - 1].date : today.date,
        apartmentBreakdown: allTimeBreakdown
      },
      history: allDays.map((d) => ({
        date: d.date,
        pageViews: d.pageViews || 0,
        uniqueVisitors: Array.isArray(d.uniqueVisitorIds) ? d.uniqueVisitorIds.length : 0,
        apartmentViews: d.apartmentViews || 0,
        swipesRight: d.swipesRight || 0,
        swipesLeft: d.swipesLeft || 0,
        telegramClicks: d.telegramClicks || 0
      }))
    });
  });
  app.post("/api/analytics/event", (req, res) => {
    const { type, visitorId, apartmentId, apartmentTitle } = req.body || {};
    const today = getTodayAnalytics();
    if (visitorId && typeof visitorId === "string") {
      if (!Array.isArray(today.uniqueVisitorIds)) today.uniqueVisitorIds = [];
      if (!today.uniqueVisitorIds.includes(visitorId)) {
        today.uniqueVisitorIds.push(visitorId);
      }
    }
    if (!today.apartmentBreakdown) today.apartmentBreakdown = {};
    if (apartmentId && typeof apartmentId === "string") {
      if (!today.apartmentBreakdown[apartmentId]) {
        today.apartmentBreakdown[apartmentId] = {
          title: apartmentTitle || "\u041A\u0432\u0430\u0440\u0442\u0438\u0440\u0430 \u0432 \u0422\u0431\u0438\u043B\u0438\u0441\u0438",
          views: 0,
          likes: 0,
          passes: 0
        };
      } else if (apartmentTitle) {
        today.apartmentBreakdown[apartmentId].title = apartmentTitle;
      }
    }
    switch (type) {
      case "page_view":
        today.pageViews = (today.pageViews || 0) + 1;
        break;
      case "landing_view":
        today.pageViews = (today.pageViews || 0) + 1;
        today.landingViews = (today.landingViews || 0) + 1;
        break;
      case "catalog_view":
        today.pageViews = (today.pageViews || 0) + 1;
        today.catalogViews = (today.catalogViews || 0) + 1;
        break;
      case "apartment_view":
        today.apartmentViews = (today.apartmentViews || 0) + 1;
        if (apartmentId && today.apartmentBreakdown[apartmentId]) {
          today.apartmentBreakdown[apartmentId].views += 1;
        }
        break;
      case "swipe_right":
        today.swipesRight = (today.swipesRight || 0) + 1;
        today.apartmentViews = (today.apartmentViews || 0) + 1;
        if (apartmentId && today.apartmentBreakdown[apartmentId]) {
          today.apartmentBreakdown[apartmentId].views += 1;
          today.apartmentBreakdown[apartmentId].likes += 1;
        }
        break;
      case "swipe_left":
        today.swipesLeft = (today.swipesLeft || 0) + 1;
        today.apartmentViews = (today.apartmentViews || 0) + 1;
        if (apartmentId && today.apartmentBreakdown[apartmentId]) {
          today.apartmentBreakdown[apartmentId].views += 1;
          today.apartmentBreakdown[apartmentId].passes += 1;
        }
        break;
      case "telegram_click":
        today.telegramClicks = (today.telegramClicks || 0) + 1;
        break;
      default:
        break;
    }
    saveTodayAnalytics(today);
    res.json({
      ok: true,
      today: {
        ...today,
        uniqueVisitors: today.uniqueVisitorIds.length
      }
    });
  });
  const TELEGRAM_CONFIG_FILE = import_path.default.join(DATA_DIR, "telegram_config.json");
  const TELEGRAM_SUBSCRIBERS_FILE = import_path.default.join(DATA_DIR, "telegram_subscribers.json");
  const DOUBLE_RENTCH_NOTIFICATIONS_FILE = import_path.default.join(
    DATA_DIR,
    "double_rentch_notifications.json"
  );
  let activeBotPollingToken = "";
  let lastTelegramUpdateId = 0;
  let activeDirectTunnelUrl = "";
  let tunnelProcess = null;
  function readTelegramConfig() {
    try {
      if (import_fs.default.existsSync(TELEGRAM_CONFIG_FILE)) {
        return JSON.parse(import_fs.default.readFileSync(TELEGRAM_CONFIG_FILE, "utf-8")) || {};
      }
    } catch {
    }
    return {};
  }
  function writeTelegramConfig(cfg) {
    try {
      import_fs.default.writeFileSync(TELEGRAM_CONFIG_FILE, JSON.stringify(cfg, null, 2), "utf-8");
    } catch {
    }
  }
  function readTelegramSubscribers() {
    try {
      if (import_fs.default.existsSync(TELEGRAM_SUBSCRIBERS_FILE)) {
        const parsed = JSON.parse(import_fs.default.readFileSync(TELEGRAM_SUBSCRIBERS_FILE, "utf-8"));
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {
    }
    return [];
  }
  function writeTelegramSubscribers(subs) {
    try {
      import_fs.default.writeFileSync(TELEGRAM_SUBSCRIBERS_FILE, JSON.stringify(subs, null, 2), "utf-8");
    } catch {
    }
  }
  function readDoubleRentchNotifications() {
    try {
      if (import_fs.default.existsSync(DOUBLE_RENTCH_NOTIFICATIONS_FILE)) {
        const parsed = JSON.parse(import_fs.default.readFileSync(DOUBLE_RENTCH_NOTIFICATIONS_FILE, "utf-8"));
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {
    }
    return [];
  }
  function writeDoubleRentchNotifications(items) {
    try {
      import_fs.default.writeFileSync(
        DOUBLE_RENTCH_NOTIFICATIONS_FILE,
        JSON.stringify(items.slice(0, 300), null, 2),
        "utf-8"
      );
    } catch {
    }
  }
  function normalizeTgHandle(handle) {
    if (!handle) return "";
    return String(handle).trim().replace(/^https?:\/\/(t\.me|telegram\.me)\//i, "").replace(/^@/, "").toLowerCase();
  }
  function normalizePhoneDigits(phone) {
    if (!phone) return "";
    return String(phone).replace(/\D/g, "");
  }
  function upsertTelegramSubscriber(input) {
    const subs = readTelegramSubscribers();
    const cleanChatId = String(input.chatId).trim();
    const cleanUsername = normalizeTgHandle(input.username);
    const fullName = input.fullName?.trim() || [input.firstName, input.lastName].filter(Boolean).join(" ").trim();
    let existing = subs.find(
      (s) => s.chatId === cleanChatId || cleanUsername && normalizeTgHandle(s.username) === cleanUsername
    );
    if (existing) {
      existing.chatId = cleanChatId || existing.chatId;
      if (cleanUsername) existing.username = cleanUsername;
      if (input.firstName) existing.firstName = input.firstName;
      if (input.lastName) existing.lastName = input.lastName;
      if (fullName) existing.fullName = fullName;
      if (input.phone) existing.phone = input.phone;
      if (input.offerId) {
        existing.offerIds = Array.from(/* @__PURE__ */ new Set([...existing.offerIds || [], input.offerId]));
      }
      existing.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    } else {
      existing = {
        chatId: cleanChatId,
        username: cleanUsername || void 0,
        firstName: input.firstName,
        lastName: input.lastName,
        fullName: fullName || void 0,
        phone: input.phone,
        offerIds: input.offerId ? [input.offerId] : [],
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      subs.unshift(existing);
    }
    writeTelegramSubscribers(subs);
    try {
      if (import_fs.default.existsSync(ROOMMATES_FILE)) {
        const offers = JSON.parse(import_fs.default.readFileSync(ROOMMATES_FILE, "utf-8"));
        if (Array.isArray(offers)) {
          let changed = false;
          for (const offer of offers) {
            if (!offer) continue;
            const offerTg = normalizeTgHandle(offer.telegram);
            const nameMatch = fullName && offer.userName && offer.userName.trim().toLowerCase() === fullName.toLowerCase();
            const idMatch = input.offerId && offer.id === input.offerId;
            const tgMatch = cleanUsername && offerTg && offerTg === cleanUsername;
            if (idMatch || tgMatch || nameMatch) {
              if (cleanChatId && offer.telegramChatId !== cleanChatId) {
                offer.telegramChatId = cleanChatId;
                changed = true;
              }
              if (cleanUsername && !offer.telegram) {
                offer.telegram = `@${cleanUsername}`;
                changed = true;
              }
            }
          }
          if (changed) {
            import_fs.default.writeFileSync(ROOMMATES_FILE, JSON.stringify(offers, null, 2), "utf-8");
          }
        }
      }
    } catch {
    }
    return existing;
  }
  function findSubscriberChatIdsForOffer(offer) {
    const chatIds = /* @__PURE__ */ new Set();
    if (offer.telegramChatId && /^\d+$/.test(String(offer.telegramChatId).trim())) {
      chatIds.add(String(offer.telegramChatId).trim());
    }
    const subs = readTelegramSubscribers();
    const targetUsername = normalizeTgHandle(offer.telegram);
    const targetPhone = normalizePhoneDigits(offer.phone);
    const targetName = (offer.userName || "").trim().toLowerCase();
    for (const s of subs) {
      if (!s.chatId) continue;
      if (offer.id && Array.isArray(s.offerIds) && s.offerIds.includes(offer.id)) {
        chatIds.add(s.chatId);
      }
      if (targetUsername && normalizeTgHandle(s.username) === targetUsername) {
        chatIds.add(s.chatId);
      }
      if (targetPhone && targetPhone.length >= 6 && normalizePhoneDigits(s.phone) === targetPhone) {
        chatIds.add(s.chatId);
      }
      if (targetName && (s.fullName && s.fullName.trim().toLowerCase() === targetName || s.firstName && s.firstName.trim().toLowerCase() === targetName)) {
        chatIds.add(s.chatId);
      }
    }
    return Array.from(chatIds);
  }
  function buildDoubleRentchTelegramMessage(notif) {
    const applicantTgFormatted = notif.applicantTelegram ? `@${normalizeTgHandle(notif.applicantTelegram)}` : "\u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D";
    return `\u{1F514} *\u041D\u043E\u0432\u0430\u044F \u0437\u0430\u044F\u0432\u043A\u0430 Double Rentch! (\u0421\u043E\u0441\u0435\u0434\u0438 50/50)*

\u0417\u0434\u0440\u0430\u0432\u0441\u0442\u0432\u0443\u0439\u0442\u0435, *${notif.recipientName}*! \u041D\u0430 \u0432\u0430\u0448\u0443 \u0430\u043D\u043A\u0435\u0442\u0443 \u0441\u043E\u0432\u043C\u0435\u0441\u0442\u043D\u043E\u0439 \u0430\u0440\u0435\u043D\u0434\u044B \u0432 \u0441\u0435\u0440\u0432\u0438\u0441\u0435 *Rentch* \u043F\u043E\u0441\u0442\u0443\u043F\u0438\u043B\u0430 \u0437\u0430\u044F\u0432\u043A\u0430:

\u{1F464} *\u041A\u0430\u043D\u0434\u0438\u0434\u0430\u0442 \u0432 \u0441\u043E\u0441\u0435\u0434\u0438:* ${notif.applicantName}
\u{1F4DE} *\u0422\u0435\u043B\u0435\u0444\u043E\u043D (WhatsApp / Telegram):* \`${notif.applicantPhone}\`
\u2708\uFE0F *Telegram \u043A\u0430\u043D\u0434\u0438\u0434\u0430\u0442\u0430:* ${applicantTgFormatted}

\u{1F3E0} *\u041A\u0432\u0430\u0440\u0442\u0438\u0440\u0430:* \xAB${notif.apartmentTitle}\xBB
\u{1F4CD} *\u0420\u0430\u0439\u043E\u043D / \u0410\u0434\u0440\u0435\u0441:* ${notif.apartmentDistrict || "\u0422\u0431\u0438\u043B\u0438\u0441\u0438"}${notif.apartmentAddress ? `, ${notif.apartmentAddress}` : ""}
\u{1F4B0} *\u0421\u0442\u043E\u0438\u043C\u043E\u0441\u0442\u044C 50/50:* *${notif.halfPriceFormatted}/\u043C\u0435\u0441* \u0441 \u0447\u0435\u043B\u043E\u0432\u0435\u043A\u0430 (\u043F\u043E\u043B\u043D\u0430\u044F: ${notif.fullPriceFormatted}/\u043C\u0435\u0441)

\u{1F4AC} \u0412 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0438 Rentch \u0443\u0436\u0435 \u0441\u043E\u0437\u0434\u0430\u043D \u0432\u0430\u0448 \u043E\u0431\u0449\u0438\u0439 \u0434\u0438\u0430\u043B\u043E\u0433 (*\u0412\u044B + ${notif.applicantName} + \u0410\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u043E\u0440 Rentch*) \u0434\u043B\u044F \u0437\u0430\u043F\u0438\u0441\u0438 \u043D\u0430 \u0441\u043E\u0432\u043C\u0435\u0441\u0442\u043D\u044B\u0439 \u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440!`;
  }
  async function dispatchTelegramDoubleRentchNotification(notif, targetChatIds) {
    const cfg = readTelegramConfig();
    const token = (cfg.botToken || process.env.TELEGRAM_BOT_TOKEN || "").trim();
    if (!token) return false;
    const appBaseUrl = cfg.customDomain || activeDirectTunnelUrl || cfg.directTunnelUrl || cfg.webAppUrl || "https://ais-pre-vfmvc5thvz3oa4jztgpvwc-295761084674.europe-west1.run.app";
    const cleanBaseUrl = appBaseUrl.replace(/\/+$/, "");
    const chatDeepLink = `${cleanBaseUrl}/?apartment=${encodeURIComponent(notif.apartmentId)}`;
    const cleanApplicantTg = normalizeTgHandle(notif.applicantTelegram);
    const inlineKeyboard = [
      [
        {
          text: "\u{1F4AC} \u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043E\u0431\u0449\u0438\u0439 \u0447\u0430\u0442 \u0432 Rentch",
          url: chatDeepLink
        }
      ]
    ];
    if (cleanApplicantTg) {
      inlineKeyboard.push([
        {
          text: `\u2708\uFE0F \u041D\u0430\u043F\u0438\u0441\u0430\u0442\u044C ${notif.applicantName} \u0432 Telegram`,
          url: `https://t.me/${cleanApplicantTg}`
        }
      ]);
    }
    const messageText = buildDoubleRentchTelegramMessage(notif);
    let deliveredToRecipient = false;
    for (const chatId of targetChatIds) {
      try {
        const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            chat_id: chatId,
            text: messageText,
            parse_mode: "Markdown",
            reply_markup: { inline_keyboard: inlineKeyboard }
          })
        });
        const data = await res.json();
        if (data?.ok) {
          deliveredToRecipient = true;
        }
      } catch {
      }
    }
    const recipientHandle = normalizeTgHandle(notif.recipientTelegram);
    if (!deliveredToRecipient && recipientHandle) {
      try {
        const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            chat_id: `@${recipientHandle}`,
            text: messageText,
            parse_mode: "Markdown",
            reply_markup: { inline_keyboard: inlineKeyboard }
          })
        });
        const data = await res.json();
        if (data?.ok) {
          deliveredToRecipient = true;
        }
      } catch {
      }
    }
    const allSubs = readTelegramSubscribers();
    for (const sub of allSubs.slice(0, 5)) {
      if (targetChatIds.includes(sub.chatId)) continue;
      try {
        await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            chat_id: sub.chatId,
            text: messageText,
            parse_mode: "Markdown",
            reply_markup: { inline_keyboard: inlineKeyboard }
          })
        });
      } catch {
      }
    }
    return deliveredToRecipient;
  }
  function startDirectTelegramTunnel() {
    if (tunnelProcess) return;
    try {
      const binPath = "/tmp/cloudflared";
      if (!import_fs.default.existsSync(binPath)) {
        (0, import_child_process.execSync)(
          "curl -sL https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o /tmp/cloudflared && chmod +x /tmp/cloudflared",
          { stdio: "ignore", timeout: 2e4 }
        );
      }
      if (!import_fs.default.existsSync(binPath)) return;
      const child = (0, import_child_process.spawn)(
        binPath,
        ["tunnel", "--url", "http://localhost:3000", "--no-autoupdate", "--protocol", "http2"],
        { stdio: ["ignore", "pipe", "pipe"] }
      );
      tunnelProcess = child;
      const handleOutput = (chunk) => {
        const str = chunk.toString("utf-8");
        const match = str.match(/https:\/\/[a-z0-9-]+\.trycloudflare\.com/i);
        if (match && match[0]) {
          const detectedUrl = match[0].trim();
          if (detectedUrl !== activeDirectTunnelUrl) {
            activeDirectTunnelUrl = detectedUrl;
            console.log("[Telegram Direct Tunnel Ready]:", activeDirectTunnelUrl);
            const cfg = readTelegramConfig();
            writeTelegramConfig({
              ...cfg,
              directTunnelUrl: activeDirectTunnelUrl
            });
            const token = (cfg.botToken || process.env.TELEGRAM_BOT_TOKEN || "").trim();
            if (token) {
              fetch(`https://api.telegram.org/bot${token}/setChatMenuButton`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                  menu_button: {
                    type: "web_app",
                    text: (cfg.buttonText || "\u{1F3E0} \u0421\u0432\u0430\u0439\u043F\u0430\u0442\u044C \u043A\u0432\u0430\u0440\u0442\u0438\u0440\u044B").trim(),
                    web_app: { url: cfg.customDomain || activeDirectTunnelUrl }
                  }
                })
              }).catch(() => {
              });
            }
          }
        }
      };
      child.stdout?.on("data", handleOutput);
      child.stderr?.on("data", handleOutput);
      child.on("exit", () => {
        tunnelProcess = null;
        setTimeout(startDirectTelegramTunnel, 5e3);
      });
    } catch (e) {
      console.error("Failed to start cloudflared tunnel:", e);
    }
  }
  startDirectTelegramTunnel();
  app.get("/api/telegram/tunnel-status", (_req, res) => {
    const cfg = readTelegramConfig();
    res.json({
      ok: true,
      directTunnelUrl: activeDirectTunnelUrl || cfg.directTunnelUrl || "",
      customDomain: cfg.customDomain || "",
      botUsername: cfg.botUsername || "rentch_date_bot",
      buttonText: cfg.buttonText || "\u{1F3E0} \u0421\u0432\u0430\u0439\u043F\u0430\u0442\u044C \u043A\u0432\u0430\u0440\u0442\u0438\u0440\u044B",
      hasBotToken: Boolean(cfg.botToken || process.env.TELEGRAM_BOT_TOKEN),
      subscribersCount: readTelegramSubscribers().length
    });
  });
  app.post("/api/telegram/register-user", (req, res) => {
    try {
      const { chatId, username, firstName, lastName, fullName, phone, offerId } = req.body || {};
      if (!chatId && !username) {
        return res.status(400).json({ ok: false, error: "chatId or username required" });
      }
      const sub = upsertTelegramSubscriber({
        chatId: String(chatId || ""),
        username,
        firstName,
        lastName,
        fullName,
        phone,
        offerId
      });
      res.json({ ok: true, subscriber: sub });
    } catch (e) {
      res.status(500).json({ ok: false, error: e?.message || "Error registering Telegram user" });
    }
  });
  app.post("/api/roommates/notify-double-rentch", async (req, res) => {
    try {
      const { offer, apartment, applicant } = req.body || {};
      if (!offer || !apartment || !applicant) {
        return res.status(400).json({ ok: false, error: "Missing offer, apartment, or applicant" });
      }
      const halfUsd = Math.round((Number(apartment.priceUsd) || 0) / 2);
      const halfPriceFormatted = apartment.currency === "EUR" || apartment.city === "belgrade" ? `\u20AC${halfUsd}` : apartment.currency === "GEL" ? `${Math.round((Number(apartment.priceGel) || Number(apartment.priceUsd) * 2.72 || 0) / 2)} \u20BE` : `$${halfUsd}`;
      const fullPriceFormatted = apartment.currency === "EUR" || apartment.city === "belgrade" ? `\u20AC${apartment.priceUsd}` : `$${apartment.priceUsd}`;
      const targetChatIds = findSubscriberChatIdsForOffer(offer);
      const notif = {
        id: "dr-notif-" + Date.now(),
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        offerId: String(offer.id || ""),
        recipientName: String(offer.userName || "\u0421\u043E\u0441\u0435\u0434 50/50"),
        recipientTelegram: offer.telegram || void 0,
        recipientChatId: targetChatIds[0] || offer.telegramChatId || void 0,
        recipientPhone: offer.phone || void 0,
        applicantName: String(applicant.name || "\u041A\u043B\u0438\u0435\u043D\u0442 Rentch"),
        applicantPhone: String(applicant.phone || ""),
        applicantTelegram: applicant.telegramUsername || void 0,
        apartmentId: String(apartment.id || ""),
        apartmentTitle: String(apartment.title || "\u041A\u0432\u0430\u0440\u0442\u0438\u0440\u0430 \u0432 Rentch"),
        apartmentDistrict: apartment.district || void 0,
        apartmentAddress: apartment.address || void 0,
        halfPriceFormatted,
        fullPriceFormatted,
        deliveredViaTelegram: false,
        readInWeb: false
      };
      const deliveredViaBot = await dispatchTelegramDoubleRentchNotification(notif, targetChatIds);
      if (deliveredViaBot) {
        notif.deliveredViaTelegram = true;
        notif.deliveredAt = (/* @__PURE__ */ new Date()).toISOString();
      }
      const existingNotifs = readDoubleRentchNotifications();
      writeDoubleRentchNotifications([notif, ...existingNotifs]);
      const cfg = readTelegramConfig();
      const botUsername = cfg.botUsername || "rentch_date_bot";
      const cleanRecipientTg = normalizeTgHandle(offer.telegram);
      const prefilledText = encodeURIComponent(
        `\u041F\u0440\u0438\u0432\u0435\u0442, ${notif.recipientName}! \u{1F44B} \u042F \u043E\u0442\u043F\u0440\u0430\u0432\u0438\u043B(\u0430) \u0442\u0435\u0431\u0435 \u0437\u0430\u044F\u0432\u043A\u0443 Double Rentch! 50/50 \u0432 \u0441\u0435\u0440\u0432\u0438\u0441\u0435 Rentch \u043F\u043E \u043A\u0432\u0430\u0440\u0442\u0438\u0440\u0435 \xAB${notif.apartmentTitle}\xBB (${notif.halfPriceFormatted}/\u043C\u0435\u0441 \u0441 \u0447\u0435\u043B\u043E\u0432\u0435\u043A\u0430). \u041C\u043E\u0438 \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u044B: ${notif.applicantName}, ${notif.applicantPhone}. \u0414\u0430\u0432\u0430\u0439 \u0441\u043D\u0438\u043C\u0435\u043C \u0435\u0451 \u0432\u043C\u0435\u0441\u0442\u0435 \u0438 \u0441\u0445\u043E\u0434\u0438\u043C \u043D\u0430 \u0441\u043E\u0432\u043C\u0435\u0441\u0442\u043D\u044B\u0439 \u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440!`
      );
      const directTelegramUrl = cleanRecipientTg ? `https://t.me/${cleanRecipientTg}?text=${prefilledText}` : `https://t.me/share/url?url=${encodeURIComponent(
        cfg.customDomain || activeDirectTunnelUrl || cfg.directTunnelUrl || ""
      )}&text=${prefilledText}`;
      res.json({
        ok: true,
        deliveredViaBot,
        recipientName: notif.recipientName,
        recipientTelegram: cleanRecipientTg ? `@${cleanRecipientTg}` : null,
        directTelegramUrl,
        botSubscribeUrl: `https://t.me/${botUsername}?start=notify_${encodeURIComponent(
          notif.offerId || cleanRecipientTg || "roommate"
        )}`,
        notification: notif
      });
    } catch (e) {
      res.status(500).json({ ok: false, error: e?.message || "Error sending Double Rentch notification" });
    }
  });
  app.get("/api/roommates/notifications", (_req, res) => {
    res.json({
      ok: true,
      notifications: readDoubleRentchNotifications()
    });
  });
  app.post("/api/domain/configure", (req, res) => {
    try {
      let rawDomain = String(req.body?.customDomain || "").trim();
      if (rawDomain && !rawDomain.startsWith("http://") && !rawDomain.startsWith("https://")) {
        rawDomain = "https://" + rawDomain;
      }
      rawDomain = rawDomain.replace(/\/+$/, "");
      const cfg = readTelegramConfig();
      writeTelegramConfig({
        ...cfg,
        customDomain: rawDomain || void 0
      });
      res.json({
        ok: true,
        customDomain: rawDomain,
        directTunnelUrl: activeDirectTunnelUrl || cfg.directTunnelUrl || ""
      });
    } catch (e) {
      res.status(500).json({ ok: false, error: e?.message || "Failed to save custom domain" });
    }
  });
  app.get("/privacy", (_req, res) => {
    res.sendFile(import_path.default.join(process.cwd(), "public", "privacy.html"));
  });
  app.get("/api/domain/web-loader.html", (req, res) => {
    const cfg = readTelegramConfig();
    const customDomain = String(req.query.domain || cfg.customDomain || "\u0432\u0430\u0448-\u0434\u043E\u043C\u0435\u043D").trim();
    const backendUrl = activeDirectTunnelUrl || cfg.directTunnelUrl || "https://ais-pre-vfmvc5thvz3oa4jztgpvwc-295761084674.europe-west1.run.app";
    const htmlContent = `<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover" />
  <title>Rentch \u2014 \u0421\u0432\u0430\u0439\u043F-\u043F\u043B\u0430\u0442\u0444\u043E\u0440\u043C\u0430 \u0430\u0440\u0435\u043D\u0434\u044B \u043A\u0432\u0430\u0440\u0442\u0438\u0440 \u0432 \u0422\u0431\u0438\u043B\u0438\u0441\u0438, \u0415\u0440\u0435\u0432\u0430\u043D\u0435 \u0438 \u0411\u0435\u043B\u0433\u0440\u0430\u0434\u0435</title>
  <meta name="description" content="\u0412\u0435\u0431-\u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435 \u043F\u043E\u0438\u0441\u043A\u0430 \u043A\u0432\u0430\u0440\u0442\u0438\u0440 \u0438 \u0441\u043E\u0441\u0435\u0434\u0435\u0439 50/50 (Double Rentch!) \u0432 \u0444\u043E\u0440\u043C\u0430\u0442\u0435 \u0441\u0432\u0430\u0439\u043F\u043E\u0432, \u0438\u043D\u0442\u0435\u0440\u0430\u043A\u0442\u0438\u0432\u043D\u043E\u0439 \u043A\u0430\u0440\u0442\u044B \u0438 \u043E\u043D\u043B\u0430\u0439\u043D-\u0437\u0430\u043F\u0438\u0441\u0438 \u043D\u0430 \u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440." />
  <meta name="theme-color" content="#f43f5e" />
  <script src="https://telegram.org/js/telegram-web-app.js"></script>
  <style>
    html, body {
      margin: 0;
      padding: 0;
      width: 100%;
      height: 100%;
      overflow: hidden;
      background: #fafaf9;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    }
    #rentch-webapp-frame {
      width: 100%;
      height: 100%;
      border: 0;
      display: block;
    }
  </style>
</head>
<body>
  <!-- \u041F\u043E\u043B\u043D\u0430\u044F Web-\u0432\u0435\u0440\u0441\u0438\u044F \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u044F Rentch \u043D\u0430 \u0434\u043E\u043C\u0435\u043D\u0435 ${escapeHtml(customDomain)} -->
  <iframe
    id="rentch-webapp-frame"
    src="${escapeHtml(backendUrl)}/?web=1"
    allow="geolocation; clipboard-write; web-share"
    allowfullscreen
  ></iframe>
  <script>
    (function() {
      try {
        if (window.Telegram && window.Telegram.WebApp) {
          window.Telegram.WebApp.ready();
          window.Telegram.WebApp.expand();
        }
        var frame = document.getElementById('rentch-webapp-frame');
        var search = window.location.search || '';
        var hash = window.location.hash || '';
        if (frame && (search || hash)) {
          var base = "${escapeHtml(backendUrl)}/";
          var sep = search ? search + '&web=1' : '?web=1';
          frame.src = base + sep + hash;
        }
      } catch (e) {}
    })();
  </script>
</body>
</html>`;
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.setHeader("Content-Disposition", 'attachment; filename="index.html"');
    res.send(htmlContent);
  });
  async function pollTelegramBotUpdates() {
    const cfg = readTelegramConfig();
    const token = (cfg.botToken || process.env.TELEGRAM_BOT_TOKEN || "").trim();
    if (!token) return;
    activeBotPollingToken = token;
    const savedUrl = (cfg.customDomain || cfg.webAppUrl || "").trim();
    const isAiStudioProxy = !savedUrl || savedUrl.includes("ais-pre-") || savedUrl.includes("ais-dev-");
    const webAppUrl = isAiStudioProxy && (activeDirectTunnelUrl || cfg.directTunnelUrl) ? activeDirectTunnelUrl || cfg.directTunnelUrl : savedUrl.replace("://ais-dev-", "://ais-pre-") || activeDirectTunnelUrl || "https://ais-pre-vfmvc5thvz3oa4jztgpvwc-295761084674.europe-west1.run.app";
    const buttonText = (cfg.buttonText || "\u{1F3E0} \u0421\u0432\u0430\u0439\u043F\u0430\u0442\u044C \u043A\u0432\u0430\u0440\u0442\u0438\u0440\u044B").trim();
    try {
      const res = await fetch(
        `https://api.telegram.org/bot${token}/getUpdates?offset=${lastTelegramUpdateId + 1}&timeout=0&allowed_updates=%5B%22message%22%5D`
      );
      if (!res.ok) return;
      const data = await res.json();
      if (!data?.ok || !Array.isArray(data.result)) return;
      for (const update of data.result) {
        if (update.update_id > lastTelegramUpdateId) {
          lastTelegramUpdateId = update.update_id;
        }
        const msg = update.message;
        if (msg?.chat?.id) {
          const chatIdStr = String(msg.chat.id);
          const text = typeof msg.text === "string" ? msg.text.trim() : "";
          const startArg = text.startsWith("/start ") ? text.slice(7).trim() : "";
          const linkedOfferId = startArg.startsWith("notify_") ? startArg.replace(/^notify_/, "").trim() : void 0;
          const sub = upsertTelegramSubscriber({
            chatId: chatIdStr,
            username: msg.from?.username,
            firstName: msg.from?.first_name,
            lastName: msg.from?.last_name,
            phone: msg.contact?.phone_number,
            offerId: linkedOfferId
          });
          const allNotifs = readDoubleRentchNotifications();
          let notifsUpdated = false;
          for (const n of allNotifs) {
            if (n.deliveredViaTelegram) continue;
            const nHandle = normalizeTgHandle(n.recipientTelegram);
            const subHandle = normalizeTgHandle(sub.username);
            const isMatch = linkedOfferId && n.offerId === linkedOfferId || nHandle && subHandle && nHandle === subHandle || sub.fullName && n.recipientName.trim().toLowerCase() === sub.fullName.trim().toLowerCase();
            if (isMatch) {
              const sent = await dispatchTelegramDoubleRentchNotification(n, [chatIdStr]);
              if (sent) {
                n.deliveredViaTelegram = true;
                n.deliveredAt = (/* @__PURE__ */ new Date()).toISOString();
                notifsUpdated = true;
              }
            }
          }
          if (notifsUpdated) {
            writeDoubleRentchNotifications(allNotifs);
          }
          if (linkedOfferId) {
            await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                chat_id: msg.chat.id,
                text: `\u{1F514} \u041E\u043F\u043E\u0432\u0435\u0449\u0435\u043D\u0438\u044F Double Rentch! (\u0421\u043E\u0441\u0435\u0434\u0438 50/50) \u0443\u0441\u043F\u0435\u0448\u043D\u043E \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u044B!

\u041A\u0430\u043A \u0442\u043E\u043B\u044C\u043A\u043E \u043A\u0442\u043E-\u0442\u043E \u043E\u0442\u043F\u0440\u0430\u0432\u0438\u0442 \u0437\u0430\u044F\u0432\u043A\u0443 \u043D\u0430 \u0432\u0430\u0448\u0443 \u0430\u043D\u043A\u0435\u0442\u0443 \u0441\u043E\u0441\u0435\u0434\u0430, \u0432\u0430\u043C \u043C\u0433\u043D\u043E\u0432\u0435\u043D\u043D\u043E \u043F\u0440\u0438\u0434\u0451\u0442 \u0441\u044E\u0434\u0430 \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u0435 \u0441 \u0438\u043C\u0435\u043D\u0435\u043C, \u0442\u0435\u043B\u0435\u0444\u043E\u043D\u043E\u043C \u0438 Telegram \u043A\u0430\u043D\u0434\u0438\u0434\u0430\u0442\u0430.`,
                reply_markup: {
                  inline_keyboard: [
                    [
                      {
                        text: buttonText,
                        web_app: { url: webAppUrl }
                      }
                    ]
                  ]
                }
              })
            }).catch(() => {
            });
          } else if (text.startsWith("/start") || text.toLowerCase().includes("\u043A\u0432\u0430\u0440\u0442\u0438\u0440")) {
            await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                chat_id: msg.chat.id,
                text: `\u0414\u043E\u0431\u0440\u043E \u043F\u043E\u0436\u0430\u043B\u043E\u0432\u0430\u0442\u044C \u0432 Rentch \u{1F1EC}\u{1F1EA} \u2014 \u0441\u0435\u0440\u0432\u0438\u0441 \u043F\u043E\u0434\u0431\u043E\u0440\u0430 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0445 \u043A\u0432\u0430\u0440\u0442\u0438\u0440 \u0438 \u0441\u043E\u0441\u0435\u0434\u0435\u0439 50/50 (Double Rentch!) \u0432 \u0422\u0431\u0438\u043B\u0438\u0441\u0438, \u0415\u0440\u0435\u0432\u0430\u043D\u0435 \u0438 \u0411\u0435\u043B\u0433\u0440\u0430\u0434\u0435!

\u{1F514} \u0412\u044B \u0442\u0430\u043A\u0436\u0435 \u043F\u043E\u0434\u043F\u0438\u0441\u0430\u043D\u044B \u043D\u0430 \u043C\u0433\u043D\u043E\u0432\u0435\u043D\u043D\u044B\u0435 \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u044F \u043E \u0437\u0430\u044F\u0432\u043A\u0430\u0445 Double Rentch!
\u{1F447} \u041D\u0430\u0436\u043C\u0438\u0442\u0435 \u043A\u043D\u043E\u043F\u043A\u0443 \u043D\u0438\u0436\u0435, \u0447\u0442\u043E\u0431\u044B \u043E\u0442\u043A\u0440\u044B\u0442\u044C \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435:`,
                reply_markup: {
                  inline_keyboard: [
                    [
                      {
                        text: buttonText,
                        web_app: { url: webAppUrl }
                      }
                    ],
                    [
                      {
                        text: "\u{1F310} \u041E\u0442\u043A\u0440\u044B\u0442\u044C Web-\u0432\u0435\u0440\u0441\u0438\u044E \u0432 \u0431\u0440\u0430\u0443\u0437\u0435\u0440\u0435",
                        url: webAppUrl
                      }
                    ]
                  ]
                }
              })
            }).catch(() => {
            });
          }
        }
      }
    } catch {
    }
  }
  setInterval(() => {
    pollTelegramBotUpdates().catch(() => {
    });
  }, 4e3);
  app.post("/api/telegram/setup-webapp", async (req, res) => {
    try {
      const savedCfg = readTelegramConfig();
      const token = String(req.body?.botToken || savedCfg.botToken || process.env.TELEGRAM_BOT_TOKEN || "").trim();
      let webAppUrl = String(
        req.body?.webAppUrl || activeDirectTunnelUrl || savedCfg.directTunnelUrl || savedCfg.webAppUrl || "https://ais-pre-vfmvc5thvz3oa4jztgpvwc-295761084674.europe-west1.run.app"
      ).trim();
      if ((webAppUrl.includes("ais-pre-") || webAppUrl.includes("ais-dev-")) && (activeDirectTunnelUrl || savedCfg.directTunnelUrl)) {
        webAppUrl = activeDirectTunnelUrl || savedCfg.directTunnelUrl;
      } else {
        webAppUrl = webAppUrl.replace("://ais-dev-", "://ais-pre-");
      }
      if (!webAppUrl.startsWith("https://")) {
        webAppUrl = "https://" + webAppUrl.replace(/^http:\/\//i, "");
      }
      const buttonText = String(req.body?.buttonText || savedCfg.buttonText || "\u{1F3E0} \u0421\u0432\u0430\u0439\u043F\u0430\u0442\u044C \u043A\u0432\u0430\u0440\u0442\u0438\u0440\u044B").trim();
      if (!token) {
        return res.status(400).json({ error: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0442\u043E\u043A\u0435\u043D \u0431\u043E\u0442\u0430 \u0438\u0437 @BotFather" });
      }
      const meRes = await fetch(`https://api.telegram.org/bot${token}/getMe`);
      const meJson = await meRes.json();
      if (!meJson?.ok) {
        return res.status(400).json({
          error: meJson?.description || "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0442\u043E\u043A\u0435\u043D \u0431\u043E\u0442\u0430 Telegram"
        });
      }
      await fetch(`https://api.telegram.org/bot${token}/deleteWebhook`).catch(() => {
      });
      const menuRes = await fetch(`https://api.telegram.org/bot${token}/setChatMenuButton`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          menu_button: {
            type: "web_app",
            text: buttonText,
            web_app: {
              url: webAppUrl
            }
          }
        })
      });
      const menuJson = await menuRes.json();
      if (!menuJson?.ok) {
        return res.status(400).json({
          error: menuJson?.description || "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u043A\u043D\u043E\u043F\u043A\u0443 \u043C\u0435\u043D\u044E \u0432 Telegram"
        });
      }
      const botUsername = meJson.result?.username || "rentch_date_bot";
      writeTelegramConfig({
        botToken: token,
        webAppUrl,
        buttonText,
        botUsername,
        directTunnelUrl: activeDirectTunnelUrl || savedCfg.directTunnelUrl
      });
      res.json({
        ok: true,
        botUsername,
        webAppUrl,
        buttonText
      });
    } catch (err) {
      res.status(500).json({ error: err?.message || "\u041E\u0448\u0438\u0431\u043A\u0430 \u0441\u043E\u0435\u0434\u0438\u043D\u0435\u043D\u0438\u044F \u0441 Telegram API" });
    }
  });
  app.get("/api/crm/leads", (_req, res) => {
    const currentLeads = readCrmLeads();
    const currentChats = readChats();
    const currentApts = readApartments();
    const { leads: reconciled, changed } = reconcileChatsIntoLeads(
      currentChats,
      currentLeads,
      currentApts
    );
    if (changed) {
      writeCrmLeads(reconciled);
    }
    res.json(reconciled);
  });
  const isAuthorizedAdminReq = (req) => {
    const token = String(req.headers["x-admin-token"] || "").trim();
    if (token) {
      const sessions = readAdminSessions();
      const session = sessions[token];
      if (session && session.expiresAt > Date.now()) {
        return true;
      }
    }
    const header = String(req.headers["x-admin-auth"] || "").trim();
    const expectedHeader = `${ADMIN_EMAIL}:${ADMIN_PASSWORD}`;
    return timingSafeMatch(header, expectedHeader);
  };
  app.post("/api/admin/login", (req, res) => {
    const ip = getClientIp(req);
    const now = Date.now();
    const rate = loginRateLimiter.get(ip);
    if (rate && rate.lockUntil > now) {
      const waitMin = Math.ceil((rate.lockUntil - now) / 6e4);
      appendAdminAudit(req, {
        event: "blocked_brute_force",
        email: String(req.body?.email || ""),
        details: `\u0417\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D\u0430 \u043F\u043E\u043F\u044B\u0442\u043A\u0430 \u043F\u0435\u0440\u0435\u0431\u043E\u0440\u0430 \u043F\u0430\u0440\u043E\u043B\u044F (\u043F\u0440\u0435\u0432\u044B\u0448\u0435\u043D \u043B\u0438\u043C\u0438\u0442 5 \u043F\u043E\u043F\u044B\u0442\u043E\u043A). \u0411\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u043A\u0430 IP \u0435\u0449\u0451 \u043D\u0430 ${waitMin} \u043C\u0438\u043D.`,
        status: "danger"
      });
      return res.status(429).json({
        ok: false,
        error: `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u043C\u043D\u043E\u0433\u043E \u043D\u0435\u0443\u0434\u0430\u0447\u043D\u044B\u0445 \u043F\u043E\u043F\u044B\u0442\u043E\u043A \u0432\u0445\u043E\u0434\u0430. \u041F\u043E\u0434\u043E\u0436\u0434\u0438\u0442\u0435 ${waitMin} \u043C\u0438\u043D.`
      });
    }
    const email = String(req.body?.email || "").trim().toLowerCase();
    const password = String(req.body?.password || "").trim();
    const emailOk = timingSafeMatch(email, ADMIN_EMAIL);
    const passOk = timingSafeMatch(password, ADMIN_PASSWORD);
    if (!emailOk || !passOk) {
      const prevCount = rate ? rate.count : 0;
      const nextCount = prevCount + 1;
      const lockUntil = nextCount >= 5 ? now + 15 * 60 * 1e3 : 0;
      loginRateLimiter.set(ip, { count: nextCount, lockUntil });
      appendAdminAudit(req, {
        event: "login_failed",
        email: email || "\u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D",
        details: `\u041D\u0435\u0443\u0434\u0430\u0447\u043D\u0430\u044F \u043F\u043E\u043F\u044B\u0442\u043A\u0430 \u0432\u0445\u043E\u0434\u0430 \u0432 \u0430\u0434\u043C\u0438\u043D-\u043F\u0430\u043D\u0435\u043B\u044C (\u043F\u043E\u043F\u044B\u0442\u043A\u0430 ${nextCount} \u0438\u0437 5).`,
        status: "warning"
      });
      return res.status(401).json({
        ok: false,
        error: "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u043B\u043E\u0433\u0438\u043D \u0438\u043B\u0438 \u043F\u0430\u0440\u043E\u043B\u044C \u0430\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u043E\u0440\u0430"
      });
    }
    loginRateLimiter.delete(ip);
    const token = import_crypto.default.randomBytes(32).toString("hex");
    const sessions = readAdminSessions();
    for (const [k, v] of Object.entries(sessions)) {
      if (!v || v.expiresAt < now) delete sessions[k];
    }
    const ua = String(req.headers["user-agent"] || "");
    sessions[token] = {
      token,
      ip,
      deviceSummary: summarizeUserAgent(ua),
      createdAt: now,
      expiresAt: now + 7 * 24 * 60 * 60 * 1e3
      // 7 days
    };
    writeAdminSessions(sessions);
    appendAdminAudit(req, {
      event: "login_success",
      email: ADMIN_EMAIL,
      details: "\u0423\u0441\u043F\u0435\u0448\u043D\u044B\u0439 \u0432\u0445\u043E\u0434 \u0432\u043B\u0430\u0434\u0435\u043B\u044C\u0446\u0430 (ai9292@mail.ru) \u0432 \u043F\u0430\u043D\u0435\u043B\u044C \u0430\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u043E\u0440\u0430.",
      status: "success"
    });
    res.json({ ok: true, token });
  });
  app.post("/api/admin/logout", (req, res) => {
    const token = String(req.headers["x-admin-token"] || "").trim();
    if (token) {
      const sessions = readAdminSessions();
      if (sessions[token]) {
        delete sessions[token];
        writeAdminSessions(sessions);
      }
    }
    res.json({ ok: true });
  });
  app.get("/api/admin/audit", (req, res) => {
    if (!isAuthorizedAdminReq(req)) {
      return res.status(403).json({ error: "\u0414\u043E\u0441\u0442\u0443\u043F \u0440\u0430\u0437\u0440\u0435\u0448\u0451\u043D \u0442\u043E\u043B\u044C\u043A\u043E \u0430\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u043E\u0440\u0443" });
    }
    const audit = readAdminAudit();
    const sessions = readAdminSessions();
    const now = Date.now();
    const activeSessions = Object.values(sessions).filter((s) => s && s.expiresAt > now).map((s) => ({
      ip: s.ip,
      deviceSummary: s.deviceSummary,
      createdAt: new Date(s.createdAt).toLocaleString("ru-RU")
    }));
    const hasBackup = import_fs.default.existsSync(CRM_LEADS_BACKUP_FILE);
    res.json({
      ok: true,
      audit,
      activeSessions,
      hasBackup
    });
  });
  app.post("/api/admin/restore-backup", (req, res) => {
    if (!isAuthorizedAdminReq(req)) {
      return res.status(403).json({ error: "\u0414\u043E\u0441\u0442\u0443\u043F \u0440\u0430\u0437\u0440\u0435\u0448\u0451\u043D \u0442\u043E\u043B\u044C\u043A\u043E \u0430\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u043E\u0440\u0443" });
    }
    let restoredLeads = [];
    if (import_fs.default.existsSync(CRM_LEADS_BACKUP_FILE)) {
      try {
        restoredLeads = JSON.parse(import_fs.default.readFileSync(CRM_LEADS_BACKUP_FILE, "utf-8"));
      } catch {
      }
    }
    if (import_fs.default.existsSync(CHATS_BACKUP_FILE)) {
      try {
        const backupChats = JSON.parse(import_fs.default.readFileSync(CHATS_BACKUP_FILE, "utf-8"));
        const mergedChats = mergeChatsData(readChats(), backupChats);
        writeChats(mergedChats);
      } catch {
      }
    }
    const currentLeads = readCrmLeads();
    const mergedLeads = mergeLeadsData(currentLeads, restoredLeads, false);
    const { leads: reconciled } = reconcileChatsIntoLeads(
      readChats(),
      mergedLeads,
      readApartments()
    );
    writeCrmLeads(reconciled);
    appendAdminAudit(req, {
      event: "restore_backup",
      email: ADMIN_EMAIL,
      details: `\u0412\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u044B \u043B\u0438\u0434\u044B \u0438 \u0441\u0432\u0430\u0439\u043F\u044B \u0432\u043F\u0440\u0430\u0432\u043E \u0438\u0437 \u0440\u0435\u0437\u0435\u0440\u0432\u043D\u043E\u0439 \u043A\u043E\u043F\u0438\u0438 (\u0432\u0441\u0435\u0433\u043E \u043B\u0438\u0434\u043E\u0432: ${reconciled.length}).`,
      status: "info"
    });
    res.json({ ok: true, leads: reconciled, chats: readChats() });
  });
  app.post("/api/crm/leads", (req, res) => {
    const { leads, isAdminUpdate, replace } = req.body;
    if (!Array.isArray(leads)) {
      return res.status(400).json({ error: "leads array is required" });
    }
    const adminVerified = Boolean(isAdminUpdate) && isAuthorizedAdminReq(req);
    if (replace === true && adminVerified) {
      writeCrmLeads(leads);
      return res.json({ success: true, leads });
    }
    const existing = readCrmLeads();
    const merged = mergeLeadsData(existing, leads, adminVerified);
    const currentChats = readChats();
    const currentApts = readApartments();
    const { leads: reconciled } = reconcileChatsIntoLeads(currentChats, merged, currentApts);
    writeCrmLeads(reconciled);
    res.json({ success: true, leads: reconciled });
  });
  app.delete("/api/crm/leads/:id", (req, res) => {
    if (!isAuthorizedAdminReq(req)) {
      appendAdminAudit(req, {
        event: "login_failed",
        details: `\u0417\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D\u0430 \u043D\u0435\u0441\u0430\u043D\u043A\u0446\u0438\u043E\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u0430\u044F \u043F\u043E\u043F\u044B\u0442\u043A\u0430 \u0443\u0434\u0430\u043B\u0435\u043D\u0438\u044F \u043B\u0438\u0434\u0430 ${req.params.id}.`,
        status: "danger"
      });
      return res.status(403).json({ error: "\u0414\u043E\u0441\u0442\u0443\u043F \u0440\u0430\u0437\u0440\u0435\u0448\u0451\u043D \u0442\u043E\u043B\u044C\u043A\u043E \u0430\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u043E\u0440\u0443 (ai9292@mail.ru)" });
    }
    const leadId = req.params.id;
    const existing = readCrmLeads();
    const target = existing.find((l) => l && l.id === leadId);
    const filtered = existing.filter((l) => l && l.id !== leadId);
    writeCrmLeads(filtered);
    appendAdminAudit(req, {
      event: "delete_lead",
      email: ADMIN_EMAIL,
      details: `\u0410\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u043E\u0440 \u0443\u0434\u0430\u043B\u0438\u043B \u043B\u0438\u0434 \xAB${target?.clientName || leadId}\xBB (${target?.apartmentTitle || ""}).`,
      status: "info"
    });
    const aptId = target?.apartmentId || (leadId.startsWith("crm-chat-") ? leadId.replace("crm-chat-", "") : null);
    if (aptId) {
      const currentChats = readChats();
      if (currentChats[aptId]) {
        delete currentChats[aptId];
        writeChats(currentChats);
      }
    }
    res.json({ success: true, leads: filtered });
  });
  app.delete("/api/crm/leads", (req, res) => {
    if (!isAuthorizedAdminReq(req)) {
      appendAdminAudit(req, {
        event: "login_failed",
        details: "\u0417\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D\u0430 \u043D\u0435\u0441\u0430\u043D\u043A\u0446\u0438\u043E\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u0430\u044F \u043F\u043E\u043F\u044B\u0442\u043A\u0430 \u043E\u0447\u0438\u0441\u0442\u043A\u0438 \u0432\u0441\u0435\u0445 \u043B\u0438\u0434\u043E\u0432 CRM.",
        status: "danger"
      });
      return res.status(403).json({ error: "\u0414\u043E\u0441\u0442\u0443\u043F \u0440\u0430\u0437\u0440\u0435\u0448\u0451\u043D \u0442\u043E\u043B\u044C\u043A\u043E \u0430\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u043E\u0440\u0443 (ai9292@mail.ru)" });
    }
    writeCrmLeads([]);
    writeChats({});
    appendAdminAudit(req, {
      event: "clear_all_leads",
      email: ADMIN_EMAIL,
      details: "\u0410\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u043E\u0440 \u043E\u0447\u0438\u0441\u0442\u0438\u043B \u0432\u0441\u0435 \u043B\u0438\u0434\u044B CRM.",
      status: "warning"
    });
    res.json({ success: true, leads: [] });
  });
  app.get("/api/chats", (_req, res) => {
    res.json(readChats());
  });
  app.get("/api/roommates", (_req, res) => {
    try {
      if (import_fs.default.existsSync(ROOMMATES_FILE)) {
        const parsed = JSON.parse(import_fs.default.readFileSync(ROOMMATES_FILE, "utf-8"));
        if (Array.isArray(parsed)) return res.json(parsed);
      }
    } catch (e) {
    }
    res.json([]);
  });
  app.post("/api/roommates", (req, res) => {
    try {
      const offer = req.body;
      if (!offer || !offer.id || !offer.apartmentId) {
        return res.status(400).json({ error: "Invalid roommate offer" });
      }
      let existing = [];
      if (import_fs.default.existsSync(ROOMMATES_FILE)) {
        const parsed = JSON.parse(import_fs.default.readFileSync(ROOMMATES_FILE, "utf-8"));
        if (Array.isArray(parsed)) existing = parsed;
      }
      const updated = [offer, ...existing.filter((o) => o && o.id !== offer.id)];
      import_fs.default.writeFileSync(ROOMMATES_FILE, JSON.stringify(updated, null, 2), "utf-8");
      res.json({ ok: true, offers: updated });
    } catch (e) {
      res.status(500).json({ error: e?.message || "Error saving roommate offer" });
    }
  });
  app.post("/api/chats", (req, res) => {
    const { chats } = req.body;
    if (!chats || typeof chats !== "object") {
      return res.status(400).json({ error: "chats object is required" });
    }
    const existingChats = readChats();
    const mergedChats = mergeChatsData(existingChats, chats);
    writeChats(mergedChats);
    const existingLeads = readCrmLeads();
    const currentApts = readApartments();
    const { leads: reconciledLeads, changed } = reconcileChatsIntoLeads(
      mergedChats,
      existingLeads,
      currentApts
    );
    if (changed) {
      writeCrmLeads(reconciledLeads);
    }
    res.json({ success: true, chats: mergedChats, leads: reconciledLeads });
  });
  app.post("/api/user/delete-data", (req, res) => {
    const { phone, clientName, visitorId } = req.body || {};
    try {
      const currentLeads = readCrmLeads();
      const filteredLeads = currentLeads.filter((lead) => {
        if (phone && lead.clientPhone && lead.clientPhone.replace(/\D/g, "") === String(phone).replace(/\D/g, "")) {
          return false;
        }
        if (clientName && lead.clientName && lead.clientName.trim().toLowerCase() === String(clientName).trim().toLowerCase()) {
          return false;
        }
        return true;
      });
      writeCrmLeads(filteredLeads);
      appendAdminAudit(req, {
        event: "user_data_deleted",
        email: "system",
        details: `\u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C \u0437\u0430\u043F\u0440\u043E\u0441\u0438\u043B \u0443\u0434\u0430\u043B\u0435\u043D\u0438\u0435 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445 (${clientName || phone || visitorId || "anonymous"}). \u0414\u0430\u043D\u043D\u044B\u0435 \u043E\u0447\u0438\u0449\u0435\u043D\u044B \u0432 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u0438 \u0441 Google Play User Data Policy.`,
        status: "info"
      });
      res.json({ success: true, message: "\u0412\u0441\u0435 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u0438 \u0438\u0441\u0442\u043E\u0440\u0438\u044F \u0443\u0441\u043F\u0435\u0448\u043D\u043E \u0443\u0434\u0430\u043B\u0435\u043D\u044B." });
    } catch (err) {
      res.status(500).json({ error: "\u041E\u0448\u0438\u0431\u043A\u0430 \u0443\u0434\u0430\u043B\u0435\u043D\u0438\u044F \u0434\u0430\u043D\u043D\u044B\u0445: " + err.message });
    }
  });
  app.get("/api/apartments", (_req, res) => {
    const apts = readApartments();
    res.json(apts);
  });
  app.post("/api/apartments", async (req, res) => {
    let payload = req.body;
    if (!payload) {
      return res.status(400).json({ error: "Payload is required" });
    }
    let batchToProcess = [];
    if (payload.rawNextData || payload.statement || payload.props && payload.props.pageProps || payload.queries) {
      try {
        const raw = payload.rawNextData ? payload.rawNextData : JSON.stringify(payload);
        batchToProcess = parseMyHomeBatch(raw, DEFAULT_AGENT_PHONE);
      } catch (parseErr) {
        return res.status(400).json({ error: "\u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u0430\u0440\u0441\u0438\u043D\u0433\u0430 MyHome \u0434\u0430\u043D\u043D\u044B\u0445: " + parseErr.message });
      }
    } else if (Array.isArray(payload)) {
      batchToProcess = payload;
    } else if (payload && payload.id) {
      batchToProcess = [payload];
    }
    if (!batchToProcess || batchToProcess.length === 0) {
      return res.status(400).json({ error: "\u041D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u044B \u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0435 \u043E\u0431\u044A\u0435\u043A\u0442\u044B \u043A\u0432\u0430\u0440\u0442\u0438\u0440" });
    }
    const processedList = [];
    for (let apt of batchToProcess) {
      if (!apt || !apt.id) continue;
      try {
        apt = await translateApartmentToRussian(apt);
      } catch (tErr) {
        console.warn("Auto-translate error:", tErr);
      }
      apt.district = getAccurateApartmentDistrict(apt);
      const coords = getAccurateApartmentCoordinates(apt);
      apt.lat = coords.lat;
      apt.lng = coords.lng;
      if (!apt.landlord) {
        apt.landlord = {
          id: `landlord-${apt.id}`,
          name: "\u0421\u043E\u0431\u0441\u0442\u0432\u0435\u043D\u043D\u0438\u043A (Rentch)",
          avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80",
          phone: DEFAULT_AGENT_PHONE,
          verified: true,
          responseTime: "\u0434\u043E 15 \u043C\u0438\u043D\u0443\u0442",
          rating: 4.9
        };
      } else {
        apt.landlord.phone = DEFAULT_AGENT_PHONE;
      }
      processedList.push(apt);
    }
    const current = readApartments();
    const existingMap = /* @__PURE__ */ new Map();
    current.forEach((a) => existingMap.set(a.id, a));
    processedList.forEach((a) => existingMap.set(a.id, a));
    const updated = [
      ...processedList,
      ...current.filter((c) => !processedList.some((p) => p.id === c.id))
    ];
    writeApartments(updated);
    res.json({
      success: true,
      importedCount: processedList.length,
      totalCount: updated.length,
      apartment: processedList[0],
      apartments: processedList
    });
  });
  app.post("/api/import/post-form", async (req, res) => {
    try {
      const raw = req.body.rawNextData;
      if (!raw) {
        return res.status(400).send("<h3>\u041E\u0448\u0438\u0431\u043A\u0430: \u043D\u0435 \u043F\u0435\u0440\u0435\u0434\u0430\u043D\u044B \u0434\u0430\u043D\u043D\u044B\u0435 \u043A\u0432\u0430\u0440\u0442\u0438\u0440\u044B</h3>");
      }
      try {
        import_fs.default.writeFileSync(import_path.default.join(DATA_DIR, "last_myhome_raw.json"), typeof raw === "string" ? raw : JSON.stringify(raw, null, 2), "utf-8");
      } catch (e) {
        console.error("Failed to save debug raw:", e);
      }
      const batch = parseMyHomeBatch(raw, DEFAULT_AGENT_PHONE);
      if (batch.length === 0) {
        return res.status(400).send('<h3>\u041E\u0431\u044A\u044F\u0432\u043B\u0435\u043D\u0438\u044F \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u044B \u043D\u0430 \u043F\u0435\u0440\u0435\u0434\u0430\u043D\u043D\u043E\u0439 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435</h3><p><a href="/">\u0412\u0435\u0440\u043D\u0443\u0442\u044C\u0441\u044F \u0432 Rentch</a></p>');
      }
      const processedList = [];
      for (let apt of batch) {
        try {
          apt = await translateApartmentToRussian(apt);
        } catch (tErr) {
          console.warn("Auto-translate error on bookmarklet import:", tErr);
        }
        apt.district = getAccurateApartmentDistrict(apt);
        if (!apt.landlord) {
          apt.landlord = {
            id: `landlord-${apt.id}`,
            name: "\u0421\u043E\u0431\u0441\u0442\u0432\u0435\u043D\u043D\u0438\u043A (Rentch)",
            avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80",
            phone: DEFAULT_AGENT_PHONE,
            verified: true,
            responseTime: "\u0434\u043E 15 \u043C\u0438\u043D\u0443\u0442",
            rating: 4.9
          };
        } else {
          apt.landlord.phone = DEFAULT_AGENT_PHONE;
        }
        processedList.push(apt);
      }
      const current = readApartments();
      const updated = [
        ...processedList,
        ...current.filter((c) => !processedList.some((p) => p.id === c.id))
      ];
      writeApartments(updated);
      const firstApt = processedList[0];
      const isBatch = processedList.length > 1;
      res.send(`
        <!DOCTYPE html>
        <html lang="ru">
        <head>
          <meta charset="utf-8">
          <title>${isBatch ? `\u0418\u043C\u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043E ${processedList.length} \u043A\u0432\u0430\u0440\u0442\u0438\u0440` : "\u041A\u0432\u0430\u0440\u0442\u0438\u0440\u0430 \u0434\u043E\u0431\u0430\u0432\u043B\u0435\u043D\u0430"} \u0432 Rentch</title>
          <style>
            body {
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
              display: flex;
              align-items: center;
              justify-content: center;
              min-height: 100vh;
              margin: 0;
              background-color: #f5f5f4;
              color: #1c1917;
            }
            .card {
              background: white;
              padding: 36px 32px;
              border-radius: 28px;
              box-shadow: 0 20px 40px rgba(0,0,0,0.08);
              max-width: 520px;
              text-align: center;
              border: 1px solid #e7e5e4;
            }
            .badge {
              display: inline-block;
              background: #dcfce7;
              color: #15803d;
              font-weight: 800;
              font-size: 13px;
              padding: 6px 16px;
              border-radius: 9999px;
              margin-bottom: 18px;
              letter-spacing: 0.03em;
            }
            h2 { margin: 0 0 10px; font-size: 22px; font-weight: 800; color: #1c1917; }
            .phone-badge {
              background: #fff1f2;
              border: 1px solid #fecdd3;
              color: #e11d48;
              padding: 10px 14px;
              border-radius: 16px;
              font-size: 13px;
              font-weight: 700;
              margin: 16px 0 20px;
              display: inline-block;
            }
            p { margin: 0 0 20px; font-size: 14px; color: #78716c; line-height: 1.5; }
            .btn {
              display: inline-block;
              background: linear-gradient(135deg, #f43f5e, #e11d48);
              color: white;
              text-decoration: none;
              font-weight: 700;
              font-size: 14px;
              padding: 14px 32px;
              border-radius: 18px;
              box-shadow: 0 6px 18px rgba(244,63,94,0.35);
              transition: transform 0.15s, box-shadow 0.15s;
            }
            .btn:hover { transform: scale(1.02); }
          </style>
        </head>
        <body>
          <div class="card">
            <div class="badge">\u2713 \u0423\u0421\u041F\u0415\u0428\u041D\u041E \u041E\u041F\u0423\u0411\u041B\u0418\u041A\u041E\u0412\u0410\u041D\u041E</div>
            <h2>${isBatch ? `\u0418\u043C\u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043E ${processedList.length} \u043A\u0432\u0430\u0440\u0442\u0438\u0440 \u0441\u043E \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B \u043A\u0430\u0442\u0430\u043B\u043E\u0433\u0430!` : escapeHtml(firstApt.title)}</h2>
            <div class="phone-badge">
              \u{1F4DE} \u0412\u0430\u0448 \u043A\u043E\u043D\u0442\u0430\u043A\u0442 \u0434\u043B\u044F \u0441\u0432\u044F\u0437\u0438: ${escapeHtml(DEFAULT_AGENT_PHONE)}
            </div>
            <p>
              ${isBatch ? `\u0412\u0441\u0435 ${processedList.length} \u043A\u0430\u0440\u0442\u043E\u0447\u0435\u043A \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u044B \u0432 Rentch, \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u044F \u043E\u0447\u0438\u0449\u0435\u043D\u044B \u043E\u0442 \u0441\u0442\u043E\u0440\u043E\u043D\u043D\u0438\u0445 \u043D\u043E\u043C\u0435\u0440\u043E\u0432 \u0438 \u043F\u0435\u0440\u0435\u0432\u0435\u0434\u0435\u043D\u044B \u043D\u0430 \u0440\u0443\u0441\u0441\u043A\u0438\u0439 \u044F\u0437\u044B\u043A.` : `${escapeHtml(firstApt.address)} \u2022 $${Number(firstApt.priceUsd) || 0} / \u043C\u0435\u0441<br>\u0412\u0441\u0435 ${firstApt.images.length} \u0444\u043E\u0442\u043E \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u044B \u0432 Rentch.`}
            </p>
            <a href="/" class="btn">\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0432 Rentch</a>
            <script>
              try {
                var bc = new BroadcastChannel('rentch_catalog');
                bc.postMessage({ action: 'apartment_added', count: ${processedList.length} });
              } catch(e) {}
              setTimeout(function() {
                window.location.href = '/?tab=catalog&admin=1';
              }, 1600);
            </script>
          </div>
        </body>
        </html>
      `);
    } catch (err) {
      console.error("Error importing post-form:", err);
      res.status(500).send(`<h3>\u041E\u0448\u0438\u0431\u043A\u0430 \u0440\u0430\u0441\u043F\u043E\u0437\u043D\u0430\u0432\u0430\u043D\u0438\u044F: ${escapeHtml(err.message)}</h3><p><a href="/">\u0412\u0435\u0440\u043D\u0443\u0442\u044C\u0441\u044F</a></p>`);
    }
  });
  app.post("/api/apartments/sync", (req, res) => {
    const incoming = req.body.apartments;
    if (!Array.isArray(incoming)) {
      return res.status(400).json({ error: "Expected apartments array" });
    }
    const current = readApartments();
    const map = /* @__PURE__ */ new Map();
    current.forEach((a) => {
      if (!isFake(a)) map.set(a.id, a);
    });
    incoming.forEach((a) => {
      if (a && a.id && !isFake(a)) {
        map.set(a.id, a);
      }
    });
    const merged = Array.from(map.values());
    writeApartments(merged);
    res.json({ success: true, count: merged.length, apartments: merged });
  });
  async function fetchMyHomeDeepNewApartments(targetLimit = 200, startPage = 1, existingIds = /* @__PURE__ */ new Set()) {
    const clampedLimit = Math.min(Math.max(targetLimit, 1), 200);
    const newApartments = [];
    const fallbackExistingApartments = [];
    const seenIds = /* @__PURE__ */ new Set();
    const maxPagesToScan = 24;
    const batchSize = 4;
    let pagesScanned = 0;
    for (let offset = 0; offset < maxPagesToScan && newApartments.length < clampedLimit; offset += batchSize) {
      const pageNumbers = Array.from({ length: batchSize }, (_, i) => startPage + offset + i);
      const pageResults = await Promise.all(
        pageNumbers.map(async (pageNum) => {
          try {
            const upstream = await fetch(
              `https://api-statements.tnet.ge/v1/statements?deal_types=2&real_estate_types=1&cities=1&currency_id=1&locale=ru&page=${pageNum}`,
              {
                headers: {
                  "X-Website-Key": "myhome",
                  "Accept-Language": "ru-RU,ru;q=0.9",
                  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
                  "Referer": "https://www.myhome.ge/"
                }
              }
            );
            if (!upstream.ok) return [];
            const apiData = await upstream.json();
            return apiData?.data?.data || apiData?.data?.statements || [];
          } catch (err) {
            console.warn(`Error fetching MyHome page ${pageNum}:`, err);
            return [];
          }
        })
      );
      let anyStatementsInChunk = false;
      for (const rawStatements of pageResults) {
        pagesScanned++;
        if (!Array.isArray(rawStatements) || rawStatements.length === 0) continue;
        anyStatementsInChunk = true;
        for (const raw of rawStatements) {
          if (newApartments.length >= clampedLimit) break;
          try {
            let apt = convertRawStatementToApartment(raw, DEFAULT_AGENT_PHONE);
            if (!apt || !apt.id || seenIds.has(apt.id)) continue;
            seenIds.add(apt.id);
            apt = translateApartmentFast(apt);
            apt.district = getAccurateApartmentDistrict(apt);
            const coords = getAccurateApartmentCoordinates(apt);
            apt.lat = coords.lat;
            apt.lng = coords.lng;
            apt = sanitizeApartmentPhones(apt);
            if (!existingIds.has(apt.id)) {
              newApartments.push(apt);
            } else {
              fallbackExistingApartments.push(apt);
            }
          } catch (convErr) {
            console.warn("Failed to convert statement:", convErr);
          }
        }
      }
      if (!anyStatementsInChunk) break;
    }
    const resultList = newApartments.length === 0 && fallbackExistingApartments.length > 0 ? fallbackExistingApartments.slice(0, clampedLimit) : newApartments.slice(0, clampedLimit);
    const gpsBatchSize = 25;
    for (let i = 0; i < resultList.length; i += gpsBatchSize) {
      const batch = resultList.slice(i, i + gpsBatchSize);
      await Promise.all(
        batch.map(async (apt) => {
          const m = String(apt.id).match(/^myhome-(\d+)$/);
          if (!m) return;
          try {
            const detailRes = await fetch(`https://api-statements.tnet.ge/v1/statements/${m[1]}?locale=ru`, {
              headers: { "X-Website-Key": "myhome", "User-Agent": "Mozilla/5.0" }
            });
            if (!detailRes.ok) return;
            const detailJson = await detailRes.json();
            const st = detailJson?.data?.statement;
            if (!st) return;
            const lat = Number(st.lat);
            const lng = Number(st.lng);
            if (!isNaN(lat) && !isNaN(lng) && lat > 41.6 && lat < 41.88 && lng > 44.65 && lng < 44.98) {
              apt.lat = lat;
              apt.lng = lng;
            }
            if (st.urban_name) {
              apt.district = getAccurateApartmentDistrict({
                ...apt,
                description: `${st.urban_name} ${apt.description || ""}`
              });
            }
            const ruSlug = st.href_lang?.ru || st.dynamic_slug;
            if (ruSlug) {
              const cleanSlug = ruSlug.endsWith(`-${m[1]}`) ? ruSlug : `${ruSlug}-${m[1]}`;
              apt.sourceUrl = `https://www.myhome.ge/ru/nedvizhimost/${cleanSlug}/`;
            }
          } catch {
          }
        })
      );
    }
    return {
      newApartments: resultList,
      pagesScanned
    };
  }
  app.post("/api/apartments/seed-myhome", async (req, res) => {
    try {
      const requestedLimit = Math.min(Math.max(Number(req.body?.limit) || 200, 1), 200);
      const startPage = Math.max(Number(req.body?.startPage) || 1, 1);
      const current = readApartments();
      const existingIds = new Set(current.map((a) => a.id));
      console.log(`Fetching up to ${requestedLimit} new apartments from MyHome API (starting at page ${startPage})...`);
      const { newApartments, pagesScanned } = await fetchMyHomeDeepNewApartments(
        requestedLimit,
        startPage,
        existingIds
      );
      const listToSave = newApartments.length > 0 ? newApartments : SEED_MYHOME_APARTMENTS.map((a) => sanitizeApartmentPhones(a));
      const map = /* @__PURE__ */ new Map();
      listToSave.forEach((a) => {
        map.set(a.id, a);
      });
      current.forEach((a) => {
        if (!isFake(a) && !map.has(a.id)) {
          map.set(a.id, sanitizeApartmentPhones(a));
        }
      });
      const updated = Array.from(map.values());
      writeApartments(updated);
      console.log(`Parsed ${listToSave.length} new apartments across ${pagesScanned} pages. Total in DB: ${updated.length}.`);
      res.json({
        success: true,
        count: listToSave.length,
        pagesScanned,
        total: updated.length,
        apartments: updated,
        newApartments: listToSave
      });
    } catch (err) {
      console.error("Error in seed-myhome:", err);
      res.status(500).json({ error: "Failed to seed apartments: " + err.message });
    }
  });
  app.delete("/api/apartments/:id", (req, res) => {
    if (!isAuthorizedAdminReq(req)) {
      appendAdminAudit(req, {
        event: "login_failed",
        details: `\u0417\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D\u0430 \u043D\u0435\u0441\u0430\u043D\u043A\u0446\u0438\u043E\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u0430\u044F \u043F\u043E\u043F\u044B\u0442\u043A\u0430 \u0443\u0434\u0430\u043B\u0435\u043D\u0438\u044F \u043A\u0432\u0430\u0440\u0442\u0438\u0440\u044B ${req.params.id}.`,
        status: "danger"
      });
      return res.status(403).json({ error: "\u0414\u043E\u0441\u0442\u0443\u043F \u0440\u0430\u0437\u0440\u0435\u0448\u0451\u043D \u0442\u043E\u043B\u044C\u043A\u043E \u0430\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u043E\u0440\u0443" });
    }
    const { id } = req.params;
    const current = readApartments();
    const target = current.find((a) => a.id === id);
    const updated = current.filter((a) => a.id !== id);
    writeApartments(updated);
    appendAdminAudit(req, {
      event: "delete_apartment",
      email: ADMIN_EMAIL,
      details: `\u0410\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u043E\u0440 \u0443\u0434\u0430\u043B\u0438\u043B \u043E\u0431\u044A\u0435\u043A\u0442 \xAB${target?.title || id}\xBB.`,
      status: "info"
    });
    res.json({ success: true, count: updated.length });
  });
  app.delete("/api/apartments", (req, res) => {
    if (!isAuthorizedAdminReq(req)) {
      appendAdminAudit(req, {
        event: "login_failed",
        details: "\u0417\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D\u0430 \u043D\u0435\u0441\u0430\u043D\u043A\u0446\u0438\u043E\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u0430\u044F \u043F\u043E\u043F\u044B\u0442\u043A\u0430 \u0443\u0434\u0430\u043B\u0435\u043D\u0438\u044F \u0432\u0441\u0435\u0433\u043E \u043A\u0430\u0442\u0430\u043B\u043E\u0433\u0430 \u043A\u0432\u0430\u0440\u0442\u0438\u0440.",
        status: "danger"
      });
      return res.status(403).json({ error: "\u0414\u043E\u0441\u0442\u0443\u043F \u0440\u0430\u0437\u0440\u0435\u0448\u0451\u043D \u0442\u043E\u043B\u044C\u043A\u043E \u0430\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u043E\u0440\u0443" });
    }
    writeApartments([]);
    appendAdminAudit(req, {
      event: "clear_all_apartments",
      email: ADMIN_EMAIL,
      details: "\u0410\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u043E\u0440 \u043E\u0447\u0438\u0441\u0442\u0438\u043B \u0432\u0435\u0441\u044C \u043A\u0430\u0442\u0430\u043B\u043E\u0433 \u043A\u0432\u0430\u0440\u0442\u0438\u0440.",
      status: "warning"
    });
    res.json({ success: true, count: 0 });
  });
  app.post("/api/apartments/translate-all", async (_req, res) => {
    const current = readApartments();
    const updated = [];
    let translatedCount = 0;
    for (const apt of current) {
      try {
        const translated = await translateApartmentToRussian(apt);
        updated.push(translated);
        if (translated.title !== apt.title || translated.address !== apt.address || translated.description !== apt.description) {
          translatedCount++;
        }
      } catch (err) {
        console.warn(`Translation error for ${apt.id}:`, err);
        updated.push(apt);
      }
    }
    writeApartments(updated);
    res.json({ success: true, total: updated.length, translatedCount, apartments: updated });
  });
  app.post("/api/import/myhome-url", async (req, res) => {
    const { url } = req.body;
    if (!url || typeof url !== "string") {
      return res.status(400).json({ error: "\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440 url \u0438\u043B\u0438 ID \u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u0435\u043D" });
    }
    const trimmed = url.trim();
    const idMatch = trimmed.match(/(?:statements?\/|statementId=|id=|-)(\d{7,9})(?:\/|\?|$)|^\s*(\d{7,9})\s*$/i);
    const singleId = idMatch ? idMatch[1] || idMatch[2] : null;
    try {
      if (singleId) {
        console.log(`Fetching MyHome listing ID ${singleId} via official API...`);
        const upstream = await fetch(`https://api-statements.tnet.ge/v1/statements/${singleId}?locale=ru`, {
          headers: {
            "X-Website-Key": "myhome",
            "Accept-Language": "ru-RU,ru;q=0.9"
          }
        });
        if (!upstream.ok) {
          return res.status(upstream.status).json({
            error: `MyHome API \u0432\u0435\u0440\u043D\u0443\u043B \u0441\u0442\u0430\u0442\u0443\u0441 ${upstream.status} \u0434\u043B\u044F \u043E\u0431\u044A\u044F\u0432\u043B\u0435\u043D\u0438\u044F ${singleId}`
          });
        }
        const data = await upstream.json();
        const rawStatement = data?.data?.statement;
        if (!rawStatement) {
          return res.status(404).json({ error: `\u041E\u0431\u044A\u044F\u0432\u043B\u0435\u043D\u0438\u0435 \u0441 \u043D\u043E\u043C\u0435\u0440\u043E\u043C ${singleId} \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E \u043D\u0430 MyHome` });
        }
        let apt = convertRawStatementToApartment(rawStatement, DEFAULT_AGENT_PHONE);
        try {
          apt = await translateApartmentToRussian(apt);
        } catch (tErr) {
          console.warn("Translate error on single import:", tErr);
        }
        apt.district = getAccurateApartmentDistrict(apt);
        const coords = getAccurateApartmentCoordinates(apt);
        apt.lat = coords.lat;
        apt.lng = coords.lng;
        apt = sanitizeApartmentPhones(apt);
        return res.json({
          success: true,
          count: 1,
          apartment: apt,
          apartments: [apt]
        });
      }
      const requestedLimit = Math.min(Math.max(Number(req.body?.limit) || 200, 1), 200);
      let startPage = 1;
      const pageMatch = trimmed.match(/page=(\d+)/);
      if (pageMatch) startPage = parseInt(pageMatch[1], 10) || 1;
      const current = readApartments();
      const existingIds = new Set(current.map((a) => a.id));
      console.log(`Fetching up to ${requestedLimit} new MyHome catalog apartments starting from page ${startPage}...`);
      const { newApartments, pagesScanned } = await fetchMyHomeDeepNewApartments(
        requestedLimit,
        startPage,
        existingIds
      );
      if (newApartments.length === 0) {
        return res.status(404).json({ error: "\u041D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0430\u0445 \u043A\u0430\u0442\u0430\u043B\u043E\u0433\u0430 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E \u043D\u043E\u0432\u044B\u0445 \u0430\u043A\u0442\u0438\u0432\u043D\u044B\u0445 \u043E\u0431\u044A\u044F\u0432\u043B\u0435\u043D\u0438\u0439" });
      }
      return res.json({
        success: true,
        count: newApartments.length,
        pagesScanned,
        apartment: newApartments[0],
        apartments: newApartments
      });
    } catch (err) {
      console.error("Error fetching MyHome by URL/API:", err);
      res.status(500).json({ error: err.message || "\u041E\u0448\u0438\u0431\u043A\u0430 \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438 \u0441 MyHome" });
    }
  });
  async function fetchHaloOglasiHtml(targetUrl) {
    const cleanTarget = targetUrl.startsWith("http") ? targetUrl : `https://www.halooglasi.com${targetUrl.startsWith("/") ? "" : "/"}${targetUrl}`;
    try {
      const jinaRes = await fetch(`https://r.jina.ai/${cleanTarget}`, {
        headers: {
          "X-Return-Format": "html"
        }
      });
      if (jinaRes.ok) {
        const html = await jinaRes.text();
        if (html && (html.includes("QuidditaEnvironment") || html.includes("product-item"))) {
          return html;
        }
      }
    } catch (err) {
      console.warn("Jina HTML proxy error for HaloOglasi:", err);
    }
    const directRes = await fetch(cleanTarget, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
        "Accept-Language": "sr-RS,sr;q=0.9,en;q=0.8"
      }
    });
    if (!directRes.ok) {
      throw new Error(`HaloOglasi \u0432\u0435\u0440\u043D\u0443\u043B \u0441\u0442\u0430\u0442\u0443\u0441 ${directRes.status}`);
    }
    return await directRes.text();
  }
  async function fetchHaloOglasiDeepApartments(catalogUrl = DEFAULT_HALO_OGLASI_URL, targetLimit = 20, startPage = 1, existingIds = /* @__PURE__ */ new Set()) {
    const clampedLimit = Math.min(Math.max(targetLimit, 1), 120);
    const collectedCandidates = [];
    const seenAdIds = /* @__PURE__ */ new Set();
    const maxPages = Math.min(Math.ceil(clampedLimit / 18) + 2, 10);
    let pagesScanned = 0;
    for (let offset = 0; offset < maxPages && collectedCandidates.length < clampedLimit; offset++) {
      const pageNum = startPage + offset;
      let pageUrl = catalogUrl;
      if (pageUrl.includes("page=")) {
        pageUrl = pageUrl.replace(/page=\d+/i, `page=${pageNum}`);
      } else if (pageNum > 1) {
        pageUrl += (pageUrl.includes("?") ? "&" : "?") + `page=${pageNum}`;
      }
      try {
        const html = await fetchHaloOglasiHtml(pageUrl);
        pagesScanned++;
        const parsedFromPage = parseHaloOglasiBatch(html, DEFAULT_AGENT_PHONE);
        if (parsedFromPage.length === 0) break;
        for (const apt of parsedFromPage) {
          if (collectedCandidates.length >= clampedLimit) break;
          if (!apt || !apt.id || seenAdIds.has(apt.id)) continue;
          seenAdIds.add(apt.id);
          collectedCandidates.push(apt);
        }
      } catch (err) {
        console.warn(`Error fetching HaloOglasi catalog page ${pageNum}:`, err);
        break;
      }
    }
    const enriched = [];
    const maxDetailEnrich = Math.min(collectedCandidates.length, 12);
    const detailBatchSize = 4;
    for (let i = 0; i < maxDetailEnrich; i += detailBatchSize) {
      const chunk = collectedCandidates.slice(i, i + detailBatchSize);
      const chunkResults = await Promise.all(
        chunk.map(async (candidate) => {
          if (!candidate.sourceUrl) return candidate;
          try {
            const controller = new AbortController();
            const timer = setTimeout(() => controller.abort(), 4500);
            const jinaRes = await fetch(`https://r.jina.ai/${candidate.sourceUrl}`, {
              headers: {
                "X-Return-Format": "html"
              },
              signal: controller.signal
            });
            clearTimeout(timer);
            if (jinaRes.ok) {
              const detailHtml = await jinaRes.text();
              const detailParsed = parseHaloOglasiBatch(detailHtml, DEFAULT_AGENT_PHONE);
              if (detailParsed.length > 0 && detailParsed[0].images.length > 0) {
                return detailParsed[0];
              }
            }
          } catch {
          }
          return candidate;
        })
      );
      enriched.push(...chunkResults);
    }
    if (collectedCandidates.length > maxDetailEnrich) {
      enriched.push(...collectedCandidates.slice(maxDetailEnrich));
    }
    const newOnly = enriched.filter((a) => !existingIds.has(a.id));
    return {
      newApartments: newOnly.length > 0 ? newOnly : enriched,
      pagesScanned
    };
  }
  app.post("/api/apartments/seed-halooglasi", async (req, res) => {
    try {
      const requestedLimit = Math.min(Math.max(Number(req.body?.limit) || 20, 1), 120);
      const startPage = Math.max(Number(req.body?.startPage) || 1, 1);
      const customUrl = String(req.body?.url || DEFAULT_HALO_OGLASI_URL).trim();
      const current = readApartments();
      const existingIds = new Set(current.map((a) => a.id));
      console.log(
        `Fetching up to ${requestedLimit} Belgrade apartments from HaloOglasi (starting at page ${startPage})...`
      );
      const { newApartments, pagesScanned } = await fetchHaloOglasiDeepApartments(
        customUrl,
        requestedLimit,
        startPage,
        existingIds
      );
      if (newApartments.length === 0) {
        return res.status(404).json({
          error: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u043E\u043B\u0443\u0447\u0438\u0442\u044C \u043E\u0431\u044A\u044F\u0432\u043B\u0435\u043D\u0438\u044F \u0441 HaloOglasi.com. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437."
        });
      }
      const map = /* @__PURE__ */ new Map();
      newApartments.forEach((a) => {
        map.set(a.id, sanitizeApartmentPhones(a));
      });
      current.forEach((a) => {
        if (!isFake(a) && !map.has(a.id)) {
          map.set(a.id, sanitizeApartmentPhones(a));
        }
      });
      const updated = Array.from(map.values());
      writeApartments(updated);
      res.json({
        success: true,
        count: newApartments.length,
        pagesScanned,
        total: updated.length,
        apartments: updated,
        newApartments
      });
    } catch (err) {
      console.error("Error in seed-halooglasi:", err);
      res.status(500).json({ error: "\u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u0430\u0440\u0441\u0438\u043D\u0433\u0430 HaloOglasi: " + err.message });
    }
  });
  app.post("/api/import/halooglasi-url", async (req, res) => {
    const { url } = req.body;
    if (!url || typeof url !== "string") {
      return res.status(400).json({ error: "\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440 url \u0438\u043B\u0438 ID \u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u0435\u043D" });
    }
    const trimmed = url.trim();
    const requestedLimit = Math.min(Math.max(Number(req.body?.limit) || 20, 1), 120);
    const startPage = Math.max(Number(req.body?.startPage) || 1, 1);
    try {
      const isSingleAd = /\/(\d{10,15})(?:\?|$|\/)/.test(trimmed);
      if (isSingleAd) {
        const html = await fetchHaloOglasiHtml(trimmed);
        const batch = parseHaloOglasiBatch(html, DEFAULT_AGENT_PHONE);
        if (batch.length === 0) {
          return res.status(404).json({ error: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0440\u0430\u0441\u043F\u043E\u0437\u043D\u0430\u0442\u044C \u043E\u0431\u044A\u044F\u0432\u043B\u0435\u043D\u0438\u0435 HaloOglasi \u043F\u043E \u0441\u0441\u044B\u043B\u043A\u0435" });
        }
        return res.json({
          success: true,
          count: 1,
          pagesScanned: 1,
          apartment: batch[0],
          apartments: [batch[0]]
        });
      }
      const current = readApartments();
      const existingIds = new Set(current.map((a) => a.id));
      const { newApartments, pagesScanned } = await fetchHaloOglasiDeepApartments(
        trimmed,
        requestedLimit,
        startPage,
        existingIds
      );
      if (newApartments.length === 0) {
        return res.status(404).json({ error: "\u041D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 \u043A\u0430\u0442\u0430\u043B\u043E\u0433\u0430 HaloOglasi \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E \u0430\u043A\u0442\u0438\u0432\u043D\u044B\u0445 \u043E\u0431\u044A\u044F\u0432\u043B\u0435\u043D\u0438\u0439" });
      }
      return res.json({
        success: true,
        count: newApartments.length,
        pagesScanned,
        apartment: newApartments[0],
        apartments: newApartments
      });
    } catch (err) {
      console.error("Error importing from HaloOglasi URL:", err);
      res.status(500).json({ error: err.message || "\u041E\u0448\u0438\u0431\u043A\u0430 \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438 \u0441 HaloOglasi" });
    }
  });
  app.get("/api/download-photo", async (req, res) => {
    const photoUrl = req.query.url;
    const name = req.query.name || "apartment-photo";
    if (!photoUrl || !isSafeExternalUrl(photoUrl)) {
      return res.status(400).send("Invalid or disallowed photo URL");
    }
    try {
      const upstream = await fetch(photoUrl, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }
      });
      if (!upstream.ok) {
        return res.status(upstream.status).send("Failed to fetch image");
      }
      const contentType = upstream.headers.get("content-type") || "image/jpeg";
      let extension = "jpg";
      if (contentType.includes("webp")) extension = "webp";
      else if (contentType.includes("png")) extension = "png";
      const filename = `${name.replace(/[^a-zA-Z0-9_\u0400-\u04FF-]/g, "_")}.${extension}`;
      res.setHeader("Content-Type", contentType);
      res.setHeader("Content-Disposition", `attachment; filename="${encodeURIComponent(filename)}"`);
      const buffer = Buffer.from(await upstream.arrayBuffer());
      res.send(buffer);
    } catch (err) {
      console.error("Error proxying photo download:", err);
      res.status(500).send("Error downloading image: " + err.message);
    }
  });
  app.post("/api/download-zip", async (req, res) => {
    const { title, images } = req.body;
    if (!Array.isArray(images) || images.length === 0) {
      return res.status(400).json({ error: "Images array is required" });
    }
    try {
      const zip = new import_jszip.default();
      const folderName = (title || "apartment-photos").replace(/[^a-zA-Z0-9_\u0400-\u04FF-]/g, "_").slice(0, 50);
      const folder = zip.folder(folderName) || zip;
      const downloadPromises = images.slice(0, 30).map(async (imgUrl, idx) => {
        try {
          if (!imgUrl || !isSafeExternalUrl(imgUrl)) return;
          const resp = await fetch(imgUrl, {
            headers: {
              "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            }
          });
          if (!resp.ok) return;
          const contentType = resp.headers.get("content-type") || "";
          let ext = "jpg";
          if (contentType.includes("webp") || imgUrl.endsWith(".webp")) ext = "webp";
          else if (contentType.includes("png") || imgUrl.endsWith(".png")) ext = "png";
          const arrayBuffer = await resp.arrayBuffer();
          const fileName = `photo_${String(idx + 1).padStart(2, "0")}.${ext}`;
          folder.file(fileName, Buffer.from(arrayBuffer));
        } catch (downloadErr) {
          console.error(`Failed to download image ${idx}:`, downloadErr);
        }
      });
      await Promise.all(downloadPromises);
      const zipBuffer = await zip.generateAsync({
        type: "nodebuffer",
        compression: "DEFLATE",
        compressionOptions: { level: 6 }
      });
      const zipFilename = `${folderName}.zip`;
      res.setHeader("Content-Type", "application/zip");
      res.setHeader("Content-Disposition", `attachment; filename="${encodeURIComponent(zipFilename)}"`);
      res.send(zipBuffer);
    } catch (err) {
      console.error("Error generating zip:", err);
      res.status(500).json({ error: "Failed to generate zip: " + err.message });
    }
  });
  app.get("/googlea365e33b25cefe4a.html", (_req, res) => {
    res.type("text/html").send("google-site-verification: googlea365e33b25cefe4a.html");
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("/assets/*", (_req, res) => {
      res.status(404).end();
    });
    app.get("*", (_req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Rentch server running on http://0.0.0.0:${PORT}`);
  });
}
startServer().catch((err) => {
  console.error("Fatal server startup error:", err);
  process.exit(1);
});
//# sourceMappingURL=server.cjs.map
